﻿<#
.SYNOPSIS
    Bulk toegang verlenen voor ALLE sites uit CSV lijst

.DESCRIPTION
    Admin script om een gebruiker toegang te geven tot alle SharePoint sites
    die in het CSV bestand staan (zowel gewone project-sites als Sharedwithcustomer-sites).

    Gebruikt PnP.PowerShell - vereist GEEN Team member rechten!
    Alleen SharePoint site permissions nodig.

.PARAMETER UserEmail
    Email adres van de gebruiker die toegang moet krijgen

.PARAMETER ProjectListCsv
    Pad naar CSV bestand met alle projecten (SharePoint-Projecten-VOLLEDIG.csv)

.PARAMETER PermissionLevel
    Toegangsniveau: 'Read', 'Contribute', of 'Full Control'
    Default: 'Read'

.EXAMPLE
    # Geef Jasper toegang tot alle sites
    .\Admin-Grant-SharedSites-From-CSV.ps1 -UserEmail "Jasper@esc.be"

.EXAMPLE
    # Test mode: toon welke sites gevonden worden zonder wijzigingen
    .\Admin-Grant-SharedSites-From-CSV.ps1 -UserEmail "Jasper@esc.be" -WhatIf

.NOTES
    Vereisten:
    - SharePoint Admin rechten
    - PnP.PowerShell module: Install-Module PnP.PowerShell -Scope CurrentUser

    Voordelen van deze aanpak:
    - Geen Team.ReadBasic.All of TeamMember.ReadWrite.All nodig!
    - Werkt direct op SharePoint site niveau
    - Verwerkt alle sites uit CSV bestand (inclusief Sharedwithcustomer)
#>

[CmdletBinding(SupportsShouldProcess)]
param(
    [Parameter(Mandatory=$true)]
    [string]$UserEmail,
    
    [Parameter()]
    [string]$ProjectListCsv = ".\SharePoint-Projecten-VOLLEDIG.csv",
    
    [Parameter()]
    [ValidateSet('Read', 'Contribute', 'Full Control')]
    [string]$PermissionLevel = 'Read',

    [Parameter()]
    [string]$ClientId = '31359c7f-bd7e-475c-86db-fdb8c937548e'
)

Write-Host "`n╔════════════════════════════════════════════════════════════╗" -ForegroundColor Cyan
Write-Host "║  BULK ACCESS: ALLE SITES (CSV Import)                    ║" -ForegroundColor Cyan
Write-Host "╚════════════════════════════════════════════════════════════╝`n" -ForegroundColor Cyan

# Stap 1: Check PnP.PowerShell
Write-Host "[1/5] PnP.PowerShell module controleren..." -ForegroundColor Yellow

if (-not (Get-Module -ListAvailable -Name PnP.PowerShell)) {
    Write-Host "  ✗ PnP.PowerShell niet geïnstalleerd!" -ForegroundColor Red
    Write-Host "`n  Installeer met:" -ForegroundColor Yellow
    Write-Host "  Install-Module PnP.PowerShell -Scope CurrentUser`n" -ForegroundColor White
    exit 1
}

Import-Module PnP.PowerShell -WarningAction SilentlyContinue
Write-Host "  ✓ Module geladen`n" -ForegroundColor Green

# Stap 2: CSV laden
Write-Host "[2/5] CSV project lijst laden..." -ForegroundColor Yellow

if (-not (Test-Path $ProjectListCsv)) {
    Write-Host "  ✗ Bestand niet gevonden: $ProjectListCsv`n" -ForegroundColor Red
    exit 1
}

$allSites = Import-Csv -Path $ProjectListCsv -Encoding UTF8
Write-Host "  ✓ $($allSites.Count) sites geladen" -ForegroundColor Green

$sharedSites = $allSites

Write-Host "  → $($sharedSites.Count) sites gevonden`n" -ForegroundColor Cyan

if ($sharedSites.Count -eq 0) {
    Write-Host "⚠ Geen shared sites in CSV!`n" -ForegroundColor Yellow
    exit 0
}

# Eerste 5 tonen als voorbeeld
Write-Host "  Eerste 5 sites (van $($sharedSites.Count) totaal):" -ForegroundColor Gray
$sharedSites | Select-Object -First 5 | ForEach-Object {
    Write-Host "    • $($_.Title)" -ForegroundColor DarkGray
}
if ($sharedSites.Count -gt 5) {
    Write-Host "    ... en $($sharedSites.Count - 5) andere" -ForegroundColor DarkGray
}
Write-Host ""

# Stap 3: SharePoint Admin connectie
Write-Host "[3/5] Connecteren als SharePoint Admin..." -ForegroundColor Yellow

try {
    # Bepaal tenant URL
    $firstUrl = $sharedSites[0].Url
    if ($firstUrl -match 'https://([^.]+)\.sharepoint\.com') {
        $tenantName = $Matches[1]
        $adminUrl = "https://$tenantName-admin.sharepoint.com"
        $tenantUrl = "https://$tenantName.sharepoint.com"
        Write-Host "  → Tenant: $tenantUrl" -ForegroundColor Gray
    } else {
        throw "Kan tenant URL niet bepalen uit: $firstUrl"
    }
    
    # Connecteer met admin rechten
    Write-Host "  → Browser window opent voor authenticatie..." -ForegroundColor Gray
    $adminConnection = Connect-PnPOnline -Url $adminUrl -ClientId $ClientId -Tenant "$tenantName.onmicrosoft.com" -Interactive -ReturnConnection
    
    Write-Host "  ✓ Verbonden als SharePoint Admin`n" -ForegroundColor Green
    
} catch {
    Write-Host "  ✗ Connectie mislukt: $($_.Exception.Message)`n" -ForegroundColor Red
    exit 1
}

# Stap 4: Gebruiker toevoegen
Write-Host "[4/5] Toegang verlenen..." -ForegroundColor Yellow
Write-Host "  → Gebruiker: $UserEmail" -ForegroundColor Cyan
Write-Host "  → Permissie: $PermissionLevel" -ForegroundColor Cyan
Write-Host "  → Sites: $($sharedSites.Count)`n" -ForegroundColor Cyan

$results = @{
    Success = @()
    AlreadyAccess = @()
    SiteNotFound = @()
    Failed = @()
}

$processed = 0
$startTime = Get-Date

foreach ($site in $sharedSites) {
    $processed++

    # Progress elke 5 sites
    if ($processed % 5 -eq 0 -or $processed -eq 1) {
        $pct = [Math]::Round(($processed / $sharedSites.Count) * 100, 1)
        $elapsed = (Get-Date) - $startTime
        if ($processed -gt 1) {
            $avgPerSite = $elapsed.TotalSeconds / $processed
            $remaining = $avgPerSite * ($sharedSites.Count - $processed)
            Write-Host "  -> $processed/$($sharedSites.Count) ($pct%) - ~$([Math]::Round($remaining/60, 1)) min..." -ForegroundColor Cyan
        }
    }

    $siteUrl = $site.Url

    try {
        # Check of site bestaat via admin connection
        try {
            $siteInfo = Get-PnPTenantSite -Url $siteUrl -Connection $adminConnection -ErrorAction Stop
        } catch {
            $results.SiteNotFound += [PSCustomObject]@{
                Title  = $site.Title
                Url    = $siteUrl
                Reason = "Site niet gevonden: $($_.Exception.Message)"
            }
            continue
        }

        # Verbind met de specifieke site via de admin-connectie
        $siteConnection = Connect-PnPOnline -Url $siteUrl -Connection $adminConnection -ReturnConnection -ErrorAction Stop

        # Haal Members-groep op
        $groups = Get-PnPGroup -Connection $siteConnection
        $membersGroup = $groups | Where-Object { $_.Title -like "*Members*" -or $_.Title -like "*Leden*" } | Select-Object -First 1

        if ($membersGroup) {
            # Check of gebruiker al lid is
            $existingMembers = Get-PnPGroupMember -Group $membersGroup.Id -Connection $siteConnection -ErrorAction SilentlyContinue
            if ($existingMembers | Where-Object { $_.LoginName -like "*$UserEmail*" -or $_.Email -eq $UserEmail }) {
                $results.AlreadyAccess += $site
                continue
            }
            # Voeg toe aan Members-groep
            Add-PnPGroupMember -Group $membersGroup.Id -LoginName $UserEmail -Connection $siteConnection -ErrorAction Stop
        } else {
            # Fallback: voeg toe als site collection admin via tenant
            Set-PnPTenantSite -Url $siteUrl -Owners @($UserEmail) -Connection $adminConnection -ErrorAction Stop
        }

        $results.Success += $site

    } catch {
        $results.Failed += [PSCustomObject]@{
            Site  = $site
            Error = $_.Exception.Message
        }
    }
}
# Stap 5: Resultaten
Write-Host "[5/5] Resultaten`n" -ForegroundColor Yellow

Write-Host "╔════════════════════════════════════════════════════════════╗" -ForegroundColor Green
Write-Host "║  TOEGANG VERLEEND                                         ║" -ForegroundColor Green
Write-Host "╚════════════════════════════════════════════════════════════╝`n" -ForegroundColor Green

Write-Host "Gebruiker:       $UserEmail" -ForegroundColor White
Write-Host "Permissie:       $PermissionLevel`n" -ForegroundColor White

Write-Host "✓ Toegang verleend:    $($results.Success.Count)" -ForegroundColor Green
Write-Host "→ Had al toegang:      $($results.AlreadyAccess.Count)" -ForegroundColor Gray
Write-Host "⚠ Site niet gevonden:  $($results.SiteNotFound.Count)" -ForegroundColor Yellow
Write-Host "✗ Mislukt:             $($results.Failed.Count)" -ForegroundColor $(if ($results.Failed.Count -gt 0) {"Red"} else {"Gray"})
Write-Host ""

# Toon details bij failures
if ($results.Failed.Count -gt 0) {
    Write-Host "Mislukte sites:" -ForegroundColor Red
    $results.Failed | ForEach-Object {
        Write-Host "  ✗ $($_.Site.Title)" -ForegroundColor DarkRed
        Write-Host "    → $($_.Error.Substring(0, [Math]::Min(100, $_.Error.Length)))" -ForegroundColor DarkGray
    }
    Write-Host ""
}

if ($results.SiteNotFound.Count -gt 0 -and $results.SiteNotFound.Count -le 10) {
    Write-Host "Sites niet gevonden:" -ForegroundColor Yellow
    $results.SiteNotFound | ForEach-Object {
        Write-Host "  ⚠ $($_.Title)" -ForegroundColor DarkYellow
    }
    Write-Host ""
}

# Export resultaat
$timestamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$exportPath = ".\SharedSites-Access-Grant-$timestamp.csv"

$allResults = @()
$allResults += $results.Success | Select-Object @{N='Status';E={'Toegevoegd'}}, Title, Url
$allResults += $results.AlreadyAccess | Select-Object @{N='Status';E={'Al toegang'}}, Title, Url
$allResults += $results.SiteNotFound | Select-Object @{N='Status';E={'Niet gevonden'}}, Title, Url, Reason
$allResults += $results.Failed | ForEach-Object { 
    [PSCustomObject]@{
        Status = 'Mislukt'
        Title = $_.Site.Title
        Url = $_.Site.Url
        Reason = $_.Error
    }
}

$allResults | Export-Csv -Path $exportPath -NoTypeInformation -Encoding UTF8
Write-Host "✓ Resultaten: $exportPath`n" -ForegroundColor Cyan

Disconnect-PnPOnline

Write-Host "═══ KLAAR ═══`n" -ForegroundColor Green

$totalAccess = $results.Success.Count + $results.AlreadyAccess.Count
Write-Host "$UserEmail heeft nu toegang tot $totalAccess sites!`n" -ForegroundColor White
