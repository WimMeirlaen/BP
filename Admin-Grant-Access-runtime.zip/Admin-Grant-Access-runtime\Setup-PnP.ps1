#Requires -RunAsAdministrator
<#
.SYNOPSIS
    Installeert de PnP.PowerShell module die nodig is voor Admin-Grant-SharedSites-From-CSV.ps1

.NOTES
    Voer dit script éénmalig uit als administrator, vóór het gebruik van het hoofdscript.
#>

Write-Host "`n╔════════════════════════════════════════════════════════════╗" -ForegroundColor Cyan
Write-Host "║  SETUP: PnP.PowerShell module installeren                ║" -ForegroundColor Cyan
Write-Host "╚════════════════════════════════════════════════════════════╝`n" -ForegroundColor Cyan

# Controleer of module al geïnstalleerd is
if (Get-Module -ListAvailable -Name PnP.PowerShell) {
    $installed = (Get-Module -ListAvailable -Name PnP.PowerShell | Sort-Object Version -Descending | Select-Object -First 1).Version
    Write-Host "✓ PnP.PowerShell is al geïnstalleerd (versie $installed)" -ForegroundColor Green
} else {
    Write-Host "→ PnP.PowerShell installeren..." -ForegroundColor Yellow
    try {
        Install-Module PnP.PowerShell -Scope CurrentUser -Force -AllowClobber -ErrorAction Stop
        Write-Host "✓ PnP.PowerShell succesvol geïnstalleerd" -ForegroundColor Green
    } catch {
        Write-Host "✗ Installatie mislukt: $($_.Exception.Message)" -ForegroundColor Red
        exit 1
    }
}

# Execution policy controleren
$policy = Get-ExecutionPolicy -Scope CurrentUser
if ($policy -eq 'Restricted' -or $policy -eq 'AllSigned') {
    Write-Host "→ Execution policy instellen op RemoteSigned..." -ForegroundColor Yellow
    Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser -Force
    Write-Host "✓ Execution policy ingesteld" -ForegroundColor Green
} else {
    Write-Host "✓ Execution policy OK ($policy)" -ForegroundColor Green
}

# Script unblockeren
Write-Host "→ Scripts unblockeren..." -ForegroundColor Yellow
Get-ChildItem $PSScriptRoot -Filter "*.ps1" | Unblock-File
Write-Host "✓ Scripts gedeblokkeerd" -ForegroundColor Green

Write-Host "`n═══ SETUP KLAAR ═══" -ForegroundColor Green
Write-Host "Je kan nu het hoofdscript uitvoeren:" -ForegroundColor White
Write-Host "  .\Admin-Grant-SharedSites-From-CSV.ps1 -UserEmail `"jasper@esc.be`"`n" -ForegroundColor Cyan
