╔════════════════════════════════════════════════════════════╗
║  BULK ACCESS VERLENEN - SHAREPOINT SITES                  ║
╚════════════════════════════════════════════════════════════╝

Doel: Geeft een gebruiker Read-toegang op alle SharePoint project-sites
      zodat hij/zij OneNote notebooks kan ophalen via het export-script.

VEREISTEN
─────────
- SharePoint Admin rechten
- PowerShell 7 (pwsh.exe) - aanbevolen
- Internetverbinding (verbinding met Microsoft 365)

STAP 1 - ÉÉNMALIGE SETUP (als administrator)
─────────────────────────────────────────────
Open PowerShell als administrator en voer uit:

  .\Setup-PnP.ps1

Dit installeert de PnP.PowerShell module en past de execution policy aan.

STAP 2 - TOEGANG VERLENEN
──────────────────────────
Open PowerShell en voer uit:

  .\Admin-Grant-SharedSites-From-CSV.ps1 -UserEmail "jasper@esc.be"

Er opent een browservenster voor authenticatie als SharePoint Admin.
Na aanmelden verwerkt het script alle sites automatisch.

OPTIES
──────
  -PermissionLevel "Read"          Alleen lezen (standaard)
  -PermissionLevel "Contribute"    Lezen + bewerken
  -WhatIf                          Testmodus: toont wat er zou gebeuren zonder wijzigingen

VOORBEELD MET TESTMODUS
────────────────────────
  .\Admin-Grant-SharedSites-From-CSV.ps1 -UserEmail "jasper@esc.be" -WhatIf

BESTANDEN
─────────
  Admin-Grant-SharedSites-From-CSV.ps1   Hoofdscript
  SharePoint-Projecten-VOLLEDIG.csv      Lijst van alle project-sites
  Setup-PnP.ps1                          Éénmalige setup (PnP module installeren)
  README-runtime.txt                     Deze handleiding
