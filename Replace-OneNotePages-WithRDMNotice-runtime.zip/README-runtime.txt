Runtime package for Replace-OneNotePages-WithRDMNotice.ps1

Included files:
- Replace-OneNotePages-WithRDMNotice.ps1
- SharePoint-Projecten-VOLLEDIG.csv

External prerequisites (not included in zip):
- PowerShell 7+ or Windows PowerShell 5.1
- Microsoft.Graph.Authentication module
- Graph delegated permissions: Sites.Read.All + Notes.ReadWrite (or Notes.ReadWrite.All)
- Valid access to target SharePoint/OneNote notebooks

Run from this folder:
  .\Replace-OneNotePages-WithRDMNotice.ps1

Optional parameters:
  .\Replace-OneNotePages-WithRDMNotice.ps1 -CustomersRootFolder "C:\Temp"
  .\Replace-OneNotePages-WithRDMNotice.ps1 -CsvPath ".\SharePoint-Projecten-VOLLEDIG.csv"
