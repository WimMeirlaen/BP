<#
.SYNOPSIS
Vervangt OneNote pagina-inhoud door "Deze informatie zit nu in RDM" voor gekozen notebooks.

.DESCRIPTION
- Vraagt klantnaam
- Leest sites uit SharePoint-Projecten-VOLLEDIG.csv
- Toont beschikbare notebooks over alle gevonden klant-sites
- Laat selectie van één of meerdere notebooks toe
- Vervangt de inhoud van ALLE pagina's in die notebooks

BELANGRIJK
Dit script wijzigt OneNote pagina's en vereist Notes.ReadWrite.All.

.EXAMPLE
.\Replace-OneNotePages-WithRDMNotice.ps1

.EXAMPLE
.\Replace-OneNotePages-WithRDMNotice.ps1 -SearchTerm "Dematra"
#>

[CmdletBinding()]
param(
    [string]$SearchTerm,
    [string]$CsvPath = ".\SharePoint-Projecten-VOLLEDIG.csv",
    [string]$CustomersRootFolder = "C:\Temp",
    [string]$ReplacementMessage = "Deze informatie zit nu in RDM.",
    [string]$TenantId = "8e426d61-a69d-4927-8a3f-ef2f62da7f57",
    [string]$ClientId = "3eb5d070-b60e-4d2b-97a9-1f775f2ea594"
)

$ErrorActionPreference = "Stop"
$script:SelectedSitesFileName  = "onenote-selected-sites.json"
$script:ThrottleHits           = 0
$script:ThrottleCooldownMins   = 30
$script:ThrottleCooldownTrigger = 5   # hard cooldown na dit aantal opeenvolgende 429's

try { Add-Type -AssemblyName System.Windows.Forms -ErrorAction Stop } catch {}

function Get-AllSitesForCustomer {
    param(
        [Parameter(Mandatory)][string]$CustomerSearchTerm,
        [Parameter(Mandatory)][string]$CsvFilePath
    )

    if (-not (Test-Path $CsvFilePath)) {
        throw "CSV bestand niet gevonden: $CsvFilePath"
    }

    $csv = Import-Csv $CsvFilePath
    $matchingSites = $csv | Where-Object {
        $_.Title -match [regex]::Escape($CustomerSearchTerm) -or
        $_.Url -match [regex]::Escape($CustomerSearchTerm)
    }

    if (-not $matchingSites -or $matchingSites.Count -eq 0) {
        throw "Geen sites gevonden voor '$CustomerSearchTerm'"
    }

    return $matchingSites
}

function Parse-NotebookSelection {
    param(
        [Parameter(Mandatory)][string]$InputText,
        [Parameter(Mandatory)][int]$MaxIndex
    )

    $text = $InputText.Trim().ToLowerInvariant()
    if ($text -eq "all" -or $text -eq "*") {
        return @(1..$MaxIndex)
    }

    $selected = New-Object System.Collections.Generic.List[int]
    $parts = $text -split ','

    foreach ($part in $parts) {
        $token = $part.Trim()
        if ([string]::IsNullOrWhiteSpace($token)) { continue }

        if ($token -match '^(\d+)-(\d+)$') {
            $start = [int]$Matches[1]
            $end = [int]$Matches[2]
            if ($start -gt $end) {
                $tmp = $start
                $start = $end
                $end = $tmp
            }
            for ($i = $start; $i -le $end; $i++) {
                if ($i -ge 1 -and $i -le $MaxIndex) {
                    if (-not $selected.Contains($i)) { [void]$selected.Add($i) }
                }
            }
            continue
        }

        if ($token -match '^\d+$') {
            $i = [int]$token
            if ($i -ge 1 -and $i -le $MaxIndex) {
                if (-not $selected.Contains($i)) { [void]$selected.Add($i) }
            }
            continue
        }
    }

    $result = $selected.ToArray() | Sort-Object
    if (-not $result -or $result.Count -eq 0) {
        throw "Geen geldige selectie. Gebruik bv. 1,3,5-7 of all"
    }

    return $result
}

function Get-CustomerNameFromExportRoot {
    param([Parameter(Mandatory)][string]$Path)

    $leaf = Split-Path $Path -Leaf
    $name = $leaf -replace '(?i)([-_ ]?full|[-_ ]?export|[-_ ]?html|[-_ ]?onenote)$',''
    $name = $name.Trim(' ','-','_')
    if ([string]::IsNullOrWhiteSpace($name)) { $name = $leaf }
    return $name
}

function Select-MultipleFromList {
    param(
        [Parameter(Mandatory)]$Items,
        [Parameter(Mandatory)][string]$Title,
        [string]$DisplayProperty = "Name",
        [string]$IdentityProperty = "FullName"
    )

    if (-not $Items -or $Items.Count -eq 0) { return @() }

    if (Get-Command Out-GridView -ErrorAction SilentlyContinue) {
        $gridItems = @()
        for ($i = 0; $i -lt $Items.Count; $i++) {
            $gridItems += [pscustomobject]@{
                Index = $i
                Name  = [string]$Items[$i].$DisplayProperty
                Path  = [string]$Items[$i].$IdentityProperty
            }
        }

        $picked = $gridItems | Out-GridView -PassThru -Title $Title
        if (-not $picked) { return @() }

        $selected = @()
        foreach ($p in @($picked)) {
            $match = $Items | Where-Object { [string]$_.$IdentityProperty -eq [string]$p.Path } | Select-Object -First 1
            if ($match) { $selected += $match }
        }
        return @($selected)
    }

    Write-Host "`n$Title" -ForegroundColor Cyan
    for ($i = 0; $i -lt $Items.Count; $i++) {
        Write-Host ("[{0}] {1}" -f $i, ($Items[$i].$DisplayProperty))
    }
    $raw = Read-Host "Kies indexen (komma-gescheiden, bv. 0,2,5)"
    if ([string]::IsNullOrWhiteSpace($raw)) { return @() }

    $selected = @()
    $parts = $raw -split ',' | ForEach-Object { $_.Trim() } | Where-Object { $_ -match '^\d+$' }
    foreach ($part in $parts) {
        $idx = [int]$part
        if ($idx -ge 0 -and $idx -lt $Items.Count) {
            $selected += $Items[$idx]
        }
    }

    return @($selected)
}

function Parse-SelectionIndices {
    param(
        [Parameter(Mandatory)][string]$InputText,
        [Parameter(Mandatory)][int]$MaxCount,
        [switch]$AllowAll
    )

    $text = $InputText.Trim()
    if ($AllowAll -and ($text -eq 'alle' -or $text -eq 'all')) {
        return @(0..($MaxCount - 1))
    }

    $selected = New-Object System.Collections.Generic.List[int]
    $seen = @{}

    foreach ($rawPart in ($text -split ',')) {
        $part = $rawPart.Trim()
        if ([string]::IsNullOrWhiteSpace($part)) { continue }

        if ($part -match '^(\d+)\s*-\s*(\d+)$') {
            $start = [int]$matches[1]
            $end = [int]$matches[2]
            if ($start -gt $end) {
                $tmp = $start
                $start = $end
                $end = $tmp
            }

            for ($i = $start; $i -le $end; $i++) {
                if ($i -lt 0 -or $i -ge $MaxCount) {
                    throw "Index buiten bereik: $i (geldig: 0-$($MaxCount - 1))"
                }
                if (-not $seen.ContainsKey($i)) {
                    $seen[$i] = $true
                    $selected.Add($i)
                }
            }
            continue
        }

        if ($part -match '^\d+$') {
            $i = [int]$part
            if ($i -lt 0 -or $i -ge $MaxCount) {
                throw "Index buiten bereik: $i (geldig: 0-$($MaxCount - 1))"
            }
            if (-not $seen.ContainsKey($i)) {
                $seen[$i] = $true
                $selected.Add($i)
            }
            continue
        }

        throw "Ongeldig selectie-element: '$part'"
    }

    return @($selected)
}

function Find-SearchTermInCsv {
    param(
        [Parameter(Mandatory)][string]$VaultName,
        [string]$CsvPath = ".\SharePoint-Projecten-VOLLEDIG.csv"
    )

    if (-not (Test-Path $CsvPath)) {
        Write-Warning "CSV niet gevonden: $CsvPath"
        return @()
    }

    try {
        $csv = @(Import-Csv $CsvPath -Encoding UTF8)
        if ($csv.Count -eq 0) { return @() }
    } catch {
        Write-Warning "Fout bij laden CSV: $_"
        return @()
    }

    $allFragments = @($VaultName -split '[\s\-_\(\)]+' | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
    $numericFragments = @($allFragments | Where-Object { $_ -match '^\d{6,}$' })

    $noisePattern = '^(nv|ltd|bv|sa|sprl|org|com|net|it|group|shared|with|customer|mw|documentation|doc|site|project)$'
    $textFragments = @($allFragments | Where-Object { $_.Length -gt 2 -and $_ -notmatch $noisePattern -and $_ -notmatch '^\d+$' } | Select-Object -Unique)

    if ($textFragments.Count -eq 0 -and $numericFragments.Count -eq 0) { return @() }

    $scores = @()
    foreach ($row in $csv) {
        $title = [string]($row.Title ?? "")
        $url = [string]($row.Url ?? "")

        $titleMatches = ($textFragments | Where-Object { $title -match [regex]::Escape($_) }).Count
        $titleScore = $titleMatches * 120

        $urlMatches = ($textFragments | Where-Object { $url -match [regex]::Escape($_) }).Count
        $urlScore = $urlMatches * 40

        $numberMatches = ($numericFragments | Where-Object { $title -match [regex]::Escape($_) -or $url -match [regex]::Escape($_) }).Count
        $numberScore = $numberMatches * 500

        $totalScore = $titleScore + $urlScore + $numberScore
        $includeRow = ($numberMatches -gt 0) -or ($titleMatches -ge 2) -or (($textFragments.Count -le 1) -and ($titleMatches -ge 1))

        if ($totalScore -gt 0 -and $includeRow) {
            $scores += [pscustomobject]@{
                Row = $row
                Title = $title
                Url = $url
                Score = $totalScore
                TitleMatches = $titleMatches
                UrlMatches = $urlMatches
                NumberMatches = $numberMatches
            }
        }
    }

    if ($scores.Count -eq 0) { return @() }

    if ($numericFragments.Count -gt 0) {
        $numericScores = @($scores | Where-Object { $_.NumberMatches -gt 0 })
        if ($numericScores.Count -gt 0) {
            $strongTextScores = @($scores | Where-Object { $_.NumberMatches -eq 0 -and $_.TitleMatches -ge 2 })
            $scores = @($numericScores) + @($strongTextScores)
        }
    }

    $sorted = @($scores | Sort-Object Score -Descending)
    $bestScore = $sorted[0].Score
    $threshold = [Math]::Max(120, $bestScore - 250)
    $filtered = @($sorted | Where-Object { $_.Score -ge $threshold })

    $belowThresholdStrongMatches = @($sorted | Where-Object { $_.Score -lt $threshold -and $_.TitleMatches -ge 2 })
    if ($belowThresholdStrongMatches.Count -gt 0) {
        $filtered = @($filtered) + @($belowThresholdStrongMatches)
    }

    if ($filtered.Count -eq 0) {
        $filtered = @($sorted | Select-Object -First 20)
    }

    if ($filtered.Count -gt 25) {
        $filtered = @($filtered | Select-Object -First 25)
    }

    return $filtered
}

function Show-MultiSelectSites {
    param(
        [Parameter(Mandatory)][object[]]$Sites
    )

    if (-not $Sites -or $Sites.Count -eq 0) { return @() }

    $displaySites = $Sites
    $displayLimit = 15
    if ($Sites.Count -gt $displayLimit) {
        $displaySites = @($Sites | Select-Object -First $displayLimit)
        Write-Host "  (Toon top $displayLimit van $($Sites.Count) matches - verfijnd op relevantie)" -ForegroundColor DarkGray
    }

    for ($i = 0; $i -lt $displaySites.Count; $i++) {
        Write-Host "  [$i] $($displaySites[$i].Title) (Score: $($displaySites[$i].Score))" -ForegroundColor White
        Write-Host "      $($displaySites[$i].Url)" -ForegroundColor DarkGray
    }

    Write-Host ""
    Write-Host "Siteselectie:" -ForegroundColor Cyan
    Write-Host "  • Getallen: '0' of '0,2,4' om specifieke sites te kiezen" -ForegroundColor DarkGray
    Write-Host "  • Ranges: '0-5' voor sites 0 tot en met 5" -ForegroundColor DarkGray
    Write-Host "  • Alles: 'alle' of Enter om alle vermelde sites te selecteren" -ForegroundColor DarkGray
    Write-Host "  • Skip: 's' om deze klant OVER TE SLAAN (gaat door naar volgende klant)" -ForegroundColor Yellow
    Write-Host ""
    $selectionInput = Read-Host "Jouw keuze"

    if ([string]::IsNullOrWhiteSpace($selectionInput)) {
        return @($displaySites)  # Enter = select all
    }

    if ($selectionInput.Trim() -ieq 's') {
        return @()  # 's' = skip this customer, continue to next
    }

    try {
        $indices = Parse-SelectionIndices -InputText $selectionInput -MaxCount $displaySites.Count -AllowAll
        $selected = @()
        foreach ($index in $indices) {
            if ($index -ge 0 -and $index -lt $displaySites.Count) {
                $selected += $displaySites[$index]
            }
        }
        return @($selected)
    } catch {
        Write-Warning "Ongeldige selectie, fallback naar beste match"
        return @($displaySites[0])
    }
}

function Load-SelectedSitesFromFolder {
    param(
        [Parameter(Mandatory)][string]$FolderPath
    )

    if ([string]::IsNullOrWhiteSpace($FolderPath)) { return @() }

    $candidates = @(
        (Join-Path $FolderPath $script:SelectedSitesFileName),
        (Join-Path $FolderPath 'selected-sites.json')
    )

    $manifestPath = $candidates | Where-Object { Test-Path $_ } | Select-Object -First 1
    if (-not $manifestPath) { return @() }

    try {
        $raw = Get-Content -Path $manifestPath -Raw -Encoding UTF8
        if ([string]::IsNullOrWhiteSpace($raw)) { return @() }

        $json = $raw | ConvertFrom-Json
        $sites = @($json.SelectedSites)
        $validSites = @()

        foreach ($site in $sites) {
            if (-not $site) { continue }
            $title = [string]($site.Title ?? '')
            $url = [string]($site.Url ?? '')
            if ([string]::IsNullOrWhiteSpace($title) -or [string]::IsNullOrWhiteSpace($url)) { continue }

            $validSites += [pscustomobject]@{
                Title = $title
                Url = $url
                Score = if ($site.PSObject.Properties.Name -contains 'Score') { $site.Score } else { $null }
            }
        }

        if ($validSites.Count -gt 0) {
            Write-Host "  ✓ Site-selectie geladen uit bestand: $manifestPath" -ForegroundColor Green
        }

        return @($validSites)
    } catch {
        Write-Warning "Kon site-selectiebestand niet lezen ($manifestPath): $($_.Exception.Message)"
        return @()
    }
}

function Invoke-HardCooldown {
    $script:ThrottleHits = 0
    $resume = (Get-Date).AddMinutes($script:ThrottleCooldownMins)
    Write-Host ""
    Write-Host ("  *** HARD COOLDOWN: te veel 429-fouten. Pauzeren {0} minuten tot {1} ***" -f `
        $script:ThrottleCooldownMins, $resume.ToString('HH:mm:ss')) -ForegroundColor Yellow
    Start-Sleep -Seconds ($script:ThrottleCooldownMins * 60)
    Write-Host "  *** Cooldown voorbij, verwerking hervat. ***" -ForegroundColor Green
    Write-Host ""
}

function Update-OneNotePageContentWithRetry {
    param(
        [Parameter(Mandatory)][string]$SiteId,
        [Parameter(Mandatory)][string]$SectionId,
        [Parameter(Mandatory)][string]$PageId,
        [string]$PageTitle,
        [Parameter(Mandatory)][string]$Message,
        [int]$MaxAttempts = 6
    )

    $titleSafe   = if ([string]::IsNullOrWhiteSpace($PageTitle)) { '(onbekende titel)' } else { $PageTitle }
    $safeMessage = [System.Net.WebUtility]::HtmlEncode($Message)
    $contentUri  = "https://graph.microsoft.com/v1.0/sites/$SiteId/onenote/pages/$PageId/content"
    $patchBody   = ConvertTo-Json -Compress -InputObject @(
        @{ target = 'body'; action = 'replace'; content = "<div><p>$safeMessage</p></div>" }
    )

    # Phase 1: PATCH (behoudt positie en hiërarchie)
    $patchOk = $false
    for ($attempt = 1; $attempt -le $MaxAttempts; $attempt++) {
        try {
            Invoke-MgGraphRequest -Uri $contentUri -Method PATCH -Body $patchBody -ContentType "application/json" -ErrorAction Stop | Out-Null
            $script:ThrottleHits = 0
            $patchOk = $true
            break
        } catch {
            $errMsg = $_.Exception.Message
            $isThrottle   = $errMsg -match '429|TooManyRequests|throttle|too many requests'
            $isNotFound   = $errMsg -match '404|NotFound|Not Found'
            $isPermission = $errMsg -match '403|Forbidden|insufficient privileges|Authorization_RequestDenied|access denied|does not have permission'

            if ($isThrottle -and $attempt -lt $MaxAttempts) {
                if (Get-Command Governor-OnThrottle -ErrorAction SilentlyContinue) { Governor-OnThrottle }
                $script:ThrottleHits++
                if ($script:ThrottleHits -ge $script:ThrottleCooldownTrigger) { Invoke-HardCooldown }
                $sleepSec = [Math]::Min(120, 8 * $attempt)
                Write-Warning ("      429/throttle op pagina '{0}' (poging {1}/{2}), wachten {3}s..." -f $titleSafe, $attempt, $MaxAttempts, $sleepSec)
                Start-Sleep -Seconds $sleepSec
                continue
            }
            if ($isNotFound) {
                Write-Warning ("      Mislukt op pagina '{0}': pagina niet (meer) gevonden." -f $titleSafe)
                return $false
            }
            if ($isPermission) {
                Write-Warning "      Onvoldoende Graph write-permissie. Vereist: Notes.ReadWrite of Notes.ReadWrite.All."
            }
            Write-Warning ("      Mislukt op pagina '{0}': {1}" -f $titleSafe, $errMsg)
            return $false
        }
    }
    if (-not $patchOk) { return $false }

    # Phase 2: verificeer of PATCH effectief was (OneNote verwerkt asynchroon)
    Start-Sleep -Milliseconds 2000
    $patchVerified = $false
    try {
        $html = Invoke-MgGraphRequest -Uri $contentUri -Method GET -OutputType String -ErrorAction Stop
        if ($html -match [regex]::Escape($Message)) { $patchVerified = $true }
    } catch { }

    if ($patchVerified) {
        if (Get-Command Governor-OnSuccess -ErrorAction SilentlyContinue) { Governor-OnSuccess }
        return $true
    }

    # Phase 3: fallback DELETE + CREATE voor orphaned subpagina's waarbij PATCH niet doorkomt
    Write-Warning ("      PATCH niet bevestigd voor '{0}' - fallback DELETE+CREATE (positie verandert)..." -f $titleSafe)

    $safeTitle  = [System.Net.WebUtility]::HtmlEncode($titleSafe)
    $createHtml = "<!DOCTYPE html><html><head><title>$safeTitle</title></head><body><p>$safeMessage</p></body></html>"

    for ($attempt = 1; $attempt -le $MaxAttempts; $attempt++) {
        try {
            Invoke-MgGraphRequest -Uri "https://graph.microsoft.com/v1.0/sites/$SiteId/onenote/pages/$PageId" `
                                  -Method DELETE -ErrorAction Stop | Out-Null
            Invoke-MgGraphRequest -Uri "https://graph.microsoft.com/v1.0/sites/$SiteId/onenote/sections/$SectionId/pages" `
                                  -Method POST -Body $createHtml -ContentType "text/html" -ErrorAction Stop | Out-Null
            $script:ThrottleHits = 0
            if (Get-Command Governor-OnSuccess -ErrorAction SilentlyContinue) { Governor-OnSuccess }
            return $true
        } catch {
            $errMsg = $_.Exception.Message
            $isThrottle = $errMsg -match '429|TooManyRequests|throttle|too many requests'
            if ($isThrottle -and $attempt -lt $MaxAttempts) {
                $script:ThrottleHits++
                if ($script:ThrottleHits -ge $script:ThrottleCooldownTrigger) { Invoke-HardCooldown }
                $sleepSec = [Math]::Min(120, 8 * $attempt)
                Write-Warning ("      429/throttle fallback '{0}' (poging {1}/{2}), wachten {3}s..." -f $titleSafe, $attempt, $MaxAttempts, $sleepSec)
                Start-Sleep -Seconds $sleepSec
                continue
            }
            Write-Warning ("      Fallback DELETE+CREATE mislukt voor '{0}': {1}" -f $titleSafe, $errMsg)
            return $false
        }
    }
    return $false
}

function Invoke-GraphJson {
    param(
        [Parameter(Mandatory)][string]$Uri
    )

    $response = Invoke-MgGraphRequest -Uri $Uri -Method GET -OutputType HttpResponseMessage -SkipHttpErrorCheck -ErrorAction Stop
    try {
        $statusCode = [int]$response.StatusCode
        if ($statusCode -lt 200 -or $statusCode -ge 300) {
            $bodyText = $response.Content.ReadAsStringAsync().GetAwaiter().GetResult()
            throw ("Graph request failed ({0}) for {1}: {2}" -f $statusCode, $Uri, $bodyText)
        }

        $contentText = $response.Content.ReadAsStringAsync().GetAwaiter().GetResult()
        if ([string]::IsNullOrWhiteSpace($contentText)) { return $null }
        return $contentText | ConvertFrom-Json
    } finally {
        $response.Dispose()
    }
}

function Get-AllNotebookSections {
    param(
        [Parameter(Mandatory)][string]$ResolvedSiteId,
        [Parameter(Mandatory)][string]$NotebookId,
        [string]$SectionGroupId = $null
    )

    $allSections = @()

    if ($SectionGroupId) {
        $uri = "https://graph.microsoft.com/v1.0/sites/$ResolvedSiteId/onenote/sectionGroups/$SectionGroupId/sections"
    } else {
        $uri = "https://graph.microsoft.com/v1.0/sites/$ResolvedSiteId/onenote/notebooks/$NotebookId/sections"
    }

    try {
        $resp = Invoke-GraphJson -Uri $uri
        if ($resp -and $resp.value) {
            $allSections += $resp.value
        }
    } catch {
        Write-Warning "  Could not fetch sections ($uri): $($_.Exception.Message)"
    }

    if (-not $SectionGroupId) {
        $originalCount = $allSections.Count
        Write-Host "  Get-AllNotebookSections: Building nested section ID list..." -ForegroundColor Magenta

        $groupsUri = "https://graph.microsoft.com/v1.0/sites/$ResolvedSiteId/onenote/notebooks/$NotebookId/sectionGroups"
        $nestedSectionIds = @{}

        try {
            $grResp = Invoke-GraphJson -Uri $groupsUri
            if ($grResp -and $grResp.value) {
                foreach ($grp in $grResp.value) {
                    $grpSectionsUri = "https://graph.microsoft.com/v1.0/sites/$ResolvedSiteId/onenote/sectionGroups/$($grp.id)/sections"
                    try {
                        $grpSectResp = Invoke-GraphJson -Uri $grpSectionsUri
                        if ($grpSectResp -and $grpSectResp.value) {
                            foreach ($nestedSec in $grpSectResp.value) {
                                $nestedSectionIds[$nestedSec.id] = $nestedSec.displayName
                            }
                        }
                    } catch {
                        Write-Warning "Could not fetch sections for group '$($grp.displayName)': $($_.Exception.Message)"
                    }
                }
            }
        } catch {
            Write-Warning "Could not fetch section groups: $($_.Exception.Message)"
        }

        Write-Host "  Found $($nestedSectionIds.Count) nested section(s)" -ForegroundColor Yellow
        $allSections = @($allSections | Where-Object { -not $nestedSectionIds.ContainsKey($_.id) })
        Write-Host "  ✓ Filtered $($originalCount - $allSections.Count) nested sections, keeping $($allSections.Count)" -ForegroundColor Green
    }

    if ($SectionGroupId) {
        $groupsUri = "https://graph.microsoft.com/v1.0/sites/$ResolvedSiteId/onenote/sectionGroups/$SectionGroupId/sectionGroups"
    } else {
        $groupsUri = "https://graph.microsoft.com/v1.0/sites/$ResolvedSiteId/onenote/notebooks/$NotebookId/sectionGroups"
    }

    try {
        $grResp = Invoke-GraphJson -Uri $groupsUri
        if ($grResp -and $grResp.value) {
            foreach ($grp in $grResp.value) {
                $nested = Get-AllNotebookSections -ResolvedSiteId $ResolvedSiteId -NotebookId $NotebookId -SectionGroupId $grp.id
                $allSections += $nested
            }
        }
    } catch {
        Write-Warning "Could not fetch section groups ($groupsUri): $($_.Exception.Message)"
    }

    return $allSections
}

function Get-SectionPagesRobust {
    param(
        [Parameter(Mandatory)][string]$ResolvedSiteId,
        [Parameter(Mandatory)][string]$SectionId
    )

    $all = @()
    $skip = 0
    $base = "https://graph.microsoft.com/v1.0/sites/$ResolvedSiteId/onenote/sections/$SectionId/pages?pagelevel=true&`$select=id,title,level,order,lastModifiedDateTime&`$orderby=order&`$top=100"

    $next = $base
    while ($true) {
        $resp = $null
        $lastError = $null
        for ($attempt = 1; $attempt -le 6; $attempt++) {
            try {
                $resp = Invoke-GraphJson -Uri $next
                $lastError = $null
                break
            } catch {
                $lastError = $_.Exception.Message
                $sleepSec = [Math]::Min(180, (12 * $attempt))
                Write-Warning ("Section pages throttle/herstel poging {0}/{1}. Wachten {2}s..." -f $attempt, 6, $sleepSec)
                Start-Sleep -Seconds $sleepSec
            }
        }

        if (-not $resp) {
            throw "Get-SectionPagesRobust failed after 6 herstelpogingen for $next :: $lastError"
        }

        $batch = @()
        if ($resp -and $resp.value) { $batch = $resp.value }
        $all += $batch

        if ($resp.'@odata.nextLink') { $next = $resp.'@odata.nextLink'; continue }

        if ($batch.Count -ge 100) {
            $skip += $batch.Count
            $next = $base + "&`$skip=$skip"
            continue
        }
        break
    }

    $sortedPages = @($all | Sort-Object { try { [int]$_.order } catch { 0 } })
    $parentStack = @{}

    foreach ($page in $sortedPages) {
        $pageLevel = 0
        try { $pageLevel = [int]$page.level } catch { $pageLevel = 0 }

        $parentPageId = $null
        if ($pageLevel -gt 0 -and $parentStack.ContainsKey($pageLevel - 1)) {
            $parentPageId = $parentStack[$pageLevel - 1]
        }

        if ($page.PSObject.Properties.Name -contains 'ParentPageId') {
            $page.ParentPageId = $parentPageId
        } else {
            $page | Add-Member -NotePropertyName ParentPageId -NotePropertyValue $parentPageId -Force
        }

        $parentStack[$pageLevel] = $page.id
        foreach ($key in @($parentStack.Keys | Where-Object { $_ -gt $pageLevel })) {
            $null = $parentStack.Remove($key)
        }
    }

    return $sortedPages
}

# Logging
$script:LogDir  = Join-Path $PSScriptRoot "logs"
if (-not (Test-Path $script:LogDir)) { New-Item -ItemType Directory -Path $script:LogDir | Out-Null }
$script:LogFile = Join-Path $script:LogDir ("Replace-OneNotePages-WithRDMNotice-{0}.log" -f (Get-Date -Format 'yyyyMMdd_HHmmss'))
Start-Transcript -Path $script:LogFile -Append | Out-Null
Write-Host "Log: $script:LogFile" -ForegroundColor DarkGray

# Banner
Write-Host "`n╔══════════════════════════════════════════════════════════════╗" -ForegroundColor Cyan
Write-Host "║  ONENOTE PAGINA'S VERVANGEN MET RDM MELDING                ║" -ForegroundColor Cyan
Write-Host "╚══════════════════════════════════════════════════════════════╝`n" -ForegroundColor Cyan

# Klantselectie: bulk via basismap met klantfolders
$selectedCustomerFolders = @()

if ([string]::IsNullOrWhiteSpace($SearchTerm)) {
    Write-Host "Kies een basismap met klantfolders (zoals Bulk-Import)" -ForegroundColor Yellow

    if (([System.Management.Automation.PSTypeName]'System.Windows.Forms.FolderBrowserDialog').Type) {
        $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
        $dialog.Description = "Kies BASISMAP met klantfolders"
        $dialog.SelectedPath = $CustomersRootFolder
        $dialog.ShowNewFolderButton = $false

        $owner = New-Object System.Windows.Forms.Form
        $owner.TopMost = $true
        $owner.WindowState = [System.Windows.Forms.FormWindowState]::Minimized
        $owner.Show()
        [void]$owner.Focus()
        $dialogResult = $dialog.ShowDialog($owner)
        $owner.Dispose()

        if ($dialogResult -ne [System.Windows.Forms.DialogResult]::OK) {
            Write-Host "Geannuleerd door gebruiker." -ForegroundColor Yellow
            exit 0
        }

        $CustomersRootFolder = $dialog.SelectedPath
    } else {
        $entered = Read-Host "Pad van basismap met klantfolders (default: $CustomersRootFolder)"
        if (-not [string]::IsNullOrWhiteSpace($entered)) { $CustomersRootFolder = $entered }
    }

    if (-not (Test-Path $CustomersRootFolder)) {
        throw "Basismap bestaat niet: $CustomersRootFolder"
    }

    $candidateFolders = @(Get-ChildItem -Path $CustomersRootFolder -Directory | Sort-Object Name)
    if ($candidateFolders.Count -eq 0) {
        throw "Geen klantfolders gevonden in: $CustomersRootFolder"
    }

    $selectedCustomerFolders = Select-MultipleFromList -Items $candidateFolders `
                                                      -Title "Selecteer één of meerdere klantfolders" `
                                                      -DisplayProperty "Name" `
                                                      -IdentityProperty "FullName"

    if (-not $selectedCustomerFolders -or $selectedCustomerFolders.Count -eq 0) {
        throw "Geen klantfolders geselecteerd."
    }
} else {
    # Backward-compatible single-search mode
    $selectedCustomerFolders = @([pscustomobject]@{ FullName = $SearchTerm; Name = $SearchTerm })
}

$customerSelections = New-Object System.Collections.Generic.List[object]
foreach ($folder in $selectedCustomerFolders) {
    $customerName = if ([string]::IsNullOrWhiteSpace($SearchTerm)) {
        Get-CustomerNameFromExportRoot -Path $folder.FullName
    } else {
        [string]$SearchTerm
    }

    $selectedSites = @()
    $sitesLoadedFromManifest = $false
    if (-not [string]::IsNullOrWhiteSpace($folder.FullName)) {
        $selectedSites = Load-SelectedSitesFromFolder -FolderPath $folder.FullName
        if ($selectedSites.Count -gt 0) {
            $sitesLoadedFromManifest = $true
            Write-Host "  Manuele controle: kies welke sites uit het site-selectiebestand mogen worden verwerkt." -ForegroundColor Cyan
            Write-Host ""
            $selectedSites = Show-MultiSelectSites -Sites $selectedSites
            if ($selectedSites.Count -eq 0) {
                Write-Warning "  Geen sites gekozen uit site-selectiebestand voor '$customerName'"
            }
        }
    }

    if (-not $sitesLoadedFromManifest -and $selectedSites.Count -eq 0) {
        Write-Host "Zoeken naar matching sites in CSV voor '$customerName'..." -ForegroundColor Yellow
        $allMatches = Find-SearchTermInCsv -VaultName $customerName -CsvPath $CsvPath

        if ($allMatches -and $allMatches.Count -gt 0) {
            # Always show sites to user, even if only 1 match - allow manual confirmation/override
            Write-Host "  Gevonden $($allMatches.Count) matching site(s):" -ForegroundColor Cyan
            Write-Host ""
            $selectedSites = Show-MultiSelectSites -Sites $allMatches
            if ($selectedSites.Count -eq 0) {
                Write-Warning "  Geen sites geselecteerd voor '$customerName'"
            }
        } else {
            Write-Warning "  Geen CSV matches voor '$customerName'"
            $keepSearching = $true
            while ($keepSearching) {
                $manualSearchTerm = Read-Host "  Zoekterm voor CSV (of Enter om over te slaan)"
                if ([string]::IsNullOrWhiteSpace($manualSearchTerm)) {
                    $keepSearching = $false
                } else {
                    $manualMatches = Find-SearchTermInCsv -VaultName $manualSearchTerm -CsvPath $CsvPath
                    if ($manualMatches -and $manualMatches.Count -gt 0) {
                        Write-Host "  Gevonden $($manualMatches.Count) site(s) voor '$manualSearchTerm':" -ForegroundColor Cyan
                        Write-Host ""
                        $selectedSites = Show-MultiSelectSites -Sites $manualMatches
                        $keepSearching = $false
                    } else {
                        Write-Warning "  Geen resultaten voor '$manualSearchTerm' - probeer andere zoekterm"
                    }
                }
            }
        }
    }

    if ($selectedSites.Count -gt 0) {
        $customerSelections.Add([pscustomobject]@{
            CustomerName = $customerName
            FolderPath = if ([string]::IsNullOrWhiteSpace($SearchTerm)) { $folder.FullName } else { '' }
            Sites = @($selectedSites)
        }) | Out-Null
        Write-Host "  ✓ Sites geselecteerd: $($selectedSites.Count)" -ForegroundColor Green
    } else {
        Write-Warning "Klant '$customerName' wordt overgeslagen (geen site-selectie)."
    }
}

if ($customerSelections.Count -eq 0) {
    throw "Geen sites gevonden voor de geselecteerde klantfolders."
}

# Graph connect (zelfde methode als Export-OneNote-Deduplicated.ps1)
Write-Host "Verbinden met Microsoft Graph..." -ForegroundColor Yellow

$context = Get-MgContext
$hasCorrectApp = $context -and $context.ClientId -eq $ClientId
$hasWriteScope = $context -and (($context.Scopes -contains "Notes.ReadWrite") -or ($context.Scopes -contains "Notes.ReadWrite.All"))
$hasCorrectScopes = $context -and ($context.Scopes -contains "Sites.Read.All") -and $hasWriteScope

if ($hasCorrectApp -and $hasCorrectScopes) {
    Write-Host "✓ Reeds ingelogd als: $($context.Account)" -ForegroundColor Green
    Write-Host "  App: onenote-bulk-export" -ForegroundColor DarkGray
    Write-Host "  Scopes: Sites.Read.All, Notes.ReadWrite/Notes.ReadWrite.All" -ForegroundColor DarkGray
} else {
    if ($context) {
        Write-Host "⚠️  Verkeerde app of scopes gedetecteerd - disconnecting..." -ForegroundColor Yellow
        Disconnect-MgGraph | Out-Null
        Start-Sleep -Seconds 2
    }

    Write-Host "`nInloggen met custom Entra app (onenote-bulk-export)..." -ForegroundColor Yellow
    Write-Host "👉 Je krijgt een device code - kopieer deze naar https://microsoft.com/devicelogin`n" -ForegroundColor Cyan

    try {
        Connect-MgGraph -ClientId $ClientId `
                         -TenantId $TenantId `
                         -Scopes "Sites.Read.All","Notes.ReadWrite" `
                         -UseDeviceCode `
                         -ContextScope Process `
                         -NoWelcome `
                         -ErrorAction Stop

        $newContext = Get-MgContext
        if (-not $newContext -or $newContext.ClientId -ne $ClientId) {
            throw "Connectie mislukt - verkeerde app"
        }

        Write-Host "`n✓ Succesvol ingelogd als: $($newContext.Account)" -ForegroundColor Green
    } catch {
        Write-Error "Kan niet verbinden met Microsoft Graph: $($_.Exception.Message)"
        Write-Host "`nOpmerking:" -ForegroundColor Yellow
        Write-Host "  Voor dit script is WRITE-scope nodig: Notes.ReadWrite (of Notes.ReadWrite.All)." -ForegroundColor Cyan
        Write-Host "  Als je nog steeds 'Approval required' krijgt, ontbreekt admin consent voor de gevraagde write-scope op app onenote-bulk-export.`n" -ForegroundColor Cyan
        exit 1
    }
}
Write-Host ""

# Discover notebooks
$notebooks = New-Object System.Collections.Generic.List[object]
$index = 0

foreach ($customer in $customerSelections) {
    foreach ($site in @($customer.Sites)) {
        try {
            $siteUri = [Uri]$site.Url
            $siteIdentifier = "{0}:{1}" -f $siteUri.Host, $siteUri.AbsolutePath
            $siteInfo = Invoke-GraphJson -Uri "https://graph.microsoft.com/v1.0/sites/$siteIdentifier"
            if (-not $siteInfo -or -not $siteInfo.id) {
                Write-Warning "Site niet resolvebaar: $($site.Title)"
                continue
            }

            $siteId = $siteInfo.id
            $nbResp = Invoke-GraphJson -Uri "https://graph.microsoft.com/v1.0/sites/$siteId/onenote/notebooks"
            $siteNotebooks = @()
            if ($nbResp -and $nbResp.value) { $siteNotebooks = $nbResp.value }

            foreach ($nb in $siteNotebooks) {
                $index++
                $notebooks.Add([PSCustomObject]@{
                    Index = $index
                    CustomerName = $customer.CustomerName
                    SiteTitle = $site.Title
                    SiteUrl = $site.Url
                    SiteId = $siteId
                    NotebookId = $nb.id
                    NotebookName = $nb.displayName
                }) | Out-Null
            }
        } catch {
            Write-Warning "Fout bij site '$($site.Title)' (klant '$($customer.CustomerName)'): $($_.Exception.Message)"
        }
    }
}

if ($notebooks.Count -eq 0) {
    throw "Geen notebooks gevonden voor de geselecteerde klantfolders."
}

Write-Host "`nBeschikbare notebooks:" -ForegroundColor Cyan
$notebooks | ForEach-Object {
    Write-Host ("  [{0}] {1}  |  Klant: {2}  |  Site: {3}" -f $_.Index, $_.NotebookName, $_.CustomerName, $_.SiteTitle) -ForegroundColor Gray
}

$selectionInput = Read-Host "`nKies notebook(s) (bv. 1,3,5-7 of all)"
$selectedIndices = Parse-NotebookSelection -InputText $selectionInput -MaxIndex $notebooks.Count
$selectedNotebooks = $notebooks | Where-Object { $selectedIndices -contains $_.Index }

Write-Host "`nGeselecteerd:" -ForegroundColor Yellow
$selectedNotebooks | ForEach-Object {
    Write-Host ("  • {0}  |  Klant: {1}  |  {2}" -f $_.NotebookName, $_.CustomerName, $_.SiteTitle) -ForegroundColor Gray
}

Write-Host "`nLET OP: Dit zal pagina-inhoud vervangen door:" -ForegroundColor Yellow
Write-Host ("  '{0}'" -f $ReplacementMessage) -ForegroundColor White
$confirm = Read-Host "Typ JA om door te gaan"
if ($confirm -ne "JA") {
    Write-Host "Geannuleerd." -ForegroundColor Yellow
    exit 0
}

# Execute replacement
$totalPages = 0
$updatedPages = 0
$failedPages = 0

foreach ($nb in $selectedNotebooks) {
    Write-Host "`n📓 $($nb.NotebookName)  |  $($nb.SiteTitle)" -ForegroundColor Cyan

    try {
        $sections = @(Get-AllNotebookSections -ResolvedSiteId $nb.SiteId -NotebookId $nb.NotebookId)
        if (-not $sections -or $sections.Count -eq 0) {
            Write-Host "  Geen secties gevonden." -ForegroundColor DarkGray
            continue
        }

        foreach ($section in $sections) {
            try {
                $pages = @(Get-SectionPagesRobust -ResolvedSiteId $nb.SiteId -SectionId $section.id)
                if (-not $pages -or $pages.Count -eq 0) { continue }

                Write-Host ("  • {0}: {1} pagina('s)" -f $section.displayName, $pages.Count) -ForegroundColor Gray

                foreach ($page in $pages) {
                    try {
                        $totalPages++
                        $pageTitle = if ([string]::IsNullOrWhiteSpace($page.title)) { '' } else { [string]$page.title }
                        $ok = Update-OneNotePageContentWithRetry -SiteId $nb.SiteId -SectionId $section.id -PageId $page.id -PageTitle $pageTitle -Message $ReplacementMessage
                        if ($ok) {
                            $updatedPages++
                        } else {
                            $failedPages++
                        }
                    } catch {
                        $failedPages++
                        Write-Warning ("    Pagina overgeslagen ({0}): {1}" -f ([string]::IsNullOrWhiteSpace($page.title) ? '<ONBEKENDE TITEL>' : $page.title), $_.Exception.Message)
                    }
                    Start-Sleep -Milliseconds 250
                }
            } catch {
                Write-Warning "  Sectie overgeslagen ($($section.displayName)): $($_.Exception.Message)"
            }
        }
    } catch {
        Write-Warning "  Notebook overgeslagen: $($_.Exception.Message)"
    }
}

Write-Host "`n═══════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host "VERVANGING VOLTOOID" -ForegroundColor Cyan
Write-Host "═══════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host ("Totaal pagina's gevonden:  {0}" -f $totalPages) -ForegroundColor White
Write-Host ("Succesvol vervangen:       {0}" -f $updatedPages) -ForegroundColor Green
Write-Host ("Mislukt:                   {0}" -f $failedPages) -ForegroundColor Yellow

if ($failedPages -gt 0) {
    Write-Warning "Niet alle pagina's konden vervangen worden. Draai het script opnieuw voor herstel van throttled items."
}

Write-Host "`nLog opgeslagen: $script:LogFile" -ForegroundColor DarkGray
Stop-Transcript | Out-Null
