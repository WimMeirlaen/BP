﻿<#
.SYNOPSIS
Imports analyzed OneNote content into Remote Desktop Manager (RDM).

.DESCRIPTION
Takes analyzed/categorized OneNote export data and creates entries in RDM.
Designed for HTML self-contained (page.rdm.html) + attachments as loose files.

.NOTES
Requires: Devolutions.PowerShell module
This script is intended to be dot-sourced.
#>

# Safe logging helper â€” delegates to Write-Log if defined by caller (Import-Client-ToRDM2 / Bulk-Import-Client-ToRDM2)
function Write-ImportLog {
    param([string]$Message, [string]$Level = 'INFO')
    if (Get-Command Write-Log -ErrorAction SilentlyContinue) {
        Write-Log $Message $Level
    }
}

function Test-IsRDMAttachmentSizeLimitError {
    param([string]$Message)

    if ([string]::IsNullOrWhiteSpace($Message)) { return $false }

    return (
        $Message -match '(?i)25\s*MB' -or
        $Message -match '(?i)26214400' -or
        $Message -match '(?i)(exceed|exceeds|exceeded).*(max|maximum|limit)' -or
        $Message -match '(?i)too\s+large' -or
        $Message -match '(?i)groter\s+dan' -or
        $Message -match '(?i)(size|grootte).*(limit|limiet|max)'
    )
}

function Write-AttachmentImportWarning {
    param(
        [string]$FilePath,
        [string]$ErrorMessage,
        [string]$Prefix = '    '
    )

    $pathValue = [string]$FilePath
    if ([string]::IsNullOrWhiteSpace($pathValue)) { $pathValue = '<unknown path>' }

    $msg = if (Test-IsRDMAttachmentSizeLimitError -Message $ErrorMessage) {
        "Attachment te groot voor RDM (vermoedelijke 25MB-limiet): $pathValue | Error: $ErrorMessage"
    } else {
        "Attachment toevoegen mislukt: $pathValue | Error: $ErrorMessage"
    }

    Write-Warning "$Prefix$msg"
    Write-ImportLog $msg 'WARN'
}


# -------------------------
# RDM connect helpers
# -------------------------
function Connect-ToRDMDataSource {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$DataSourceName,
        [Parameter(Mandatory)][string]$VaultName,
        [switch]$CreateIfMissing
    )

    Write-Host "Connecting to RDM data source: $DataSourceName" -ForegroundColor Cyan

    $ds = Get-RDMDataSource -Name $DataSourceName -ErrorAction Stop
    if (-not $ds) { throw "Data source '$DataSourceName' not found" }

    Set-RDMCurrentDataSource -DataSource $ds | Out-Null
    Write-Host "Connected to data source: $DataSourceName" -ForegroundColor Green

    $vault = Get-RDMRepository | Where-Object { $_.Name -eq $VaultName } | Select-Object -First 1

    if (-not $vault -and $CreateIfMissing) {
        Write-Host "Creating new vault: $VaultName" -ForegroundColor Yellow
        $vault = New-RDMRepository -Name $VaultName -IsAllowedOffline $true -SetRepository
        Write-Host "Vault created successfully" -ForegroundColor Green
        Start-Sleep -Milliseconds 1500
        try { Update-RDMUI | Out-Null } catch {}
    }
    elseif (-not $vault) {
        throw "Vault '$VaultName' not found and CreateIfMissing not specified"
    }

    Set-RDMCurrentRepository -Repository $vault | Out-Null
    Write-Host "Using vault: $VaultName" -ForegroundColor Green

    # Folder cache reset bij datasource/vault wissel
    $script:RDMFolderCache = @{}
    $script:RDMFolderCacheInitialized = $false
    $script:RDMRootParentAliases = @{}

    # wait a bit for repository context
    for ($i=0; $i -lt 30; $i++) {
        try {
            $null = Get-RDMEntry -Type Group -ErrorAction Stop | Select-Object -First 1
            break
        } catch { Start-Sleep -Milliseconds 200 }
    }

    return $vault
}

function New-RDMFolderCacheKey {
    [CmdletBinding()]
    param(
        [string]$ParentPath,
        [Parameter(Mandatory)][string]$Name
    )

    $parent = Normalize-RDMGroupPath -Path $ParentPath
    return "$parent|||$Name"
}

function Normalize-RDMGroupPath {
    [CmdletBinding()]
    param([string]$Path)

    if ([string]::IsNullOrWhiteSpace($Path)) { return '' }

    $value = [string]$Path
    $value = $value.Trim()
    $value = $value -replace '/', '\'

    $parts = @($value -split '[\\]+' | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
    if ($parts.Count -eq 0) { return '' }

    return ($parts -join '\')
}

function Test-RDMParentPathMatch {
    [CmdletBinding()]
    param(
        [string]$EntryGroup,
        [string]$ParentPath
    )

    $left = Normalize-RDMGroupPath -Path $EntryGroup
    $right = Normalize-RDMGroupPath -Path $ParentPath
    if ($left -eq $right) { return $true }

    # Compatibility: some RDM setups store child folders of a top-level root under empty Group,
    # while the root itself is stored with Group equal to its own Name.
    if ([string]::IsNullOrWhiteSpace($left) -and -not [string]::IsNullOrWhiteSpace($right) -and $right -notlike '*\*') {
        if ($script:RDMRootParentAliases -and $script:RDMRootParentAliases.ContainsKey($right)) {
            return $true
        }
    }

    return $false
}

function Test-RDMFolderPathMatch {
    [CmdletBinding()]
    param(
        [string]$EntryName,
        [string]$EntryGroup,
        [string]$ParentPath
    )

    $name = Normalize-RDMGroupPath -Path $EntryName
    $group = Normalize-RDMGroupPath -Path $EntryGroup
    $parent = Normalize-RDMGroupPath -Path $ParentPath

    if ([string]::IsNullOrWhiteSpace($name)) { return $false }

    if (Test-RDMParentPathMatch -EntryGroup $group -ParentPath $parent) {
        # Ambiguous case: non-root folders where Group already looks like full path incl. own name
        # (e.g. Name=Netwerk, Group=OneNote Export\Netwerk). Do not accept as parent-style match.
        $selfStyleSignature = ($group -eq $name) -or $group.EndsWith(("\" + $name), [System.StringComparison]::OrdinalIgnoreCase)
        if (-not ([string]::IsNullOrWhiteSpace($parent)) -and $selfStyleSignature) {
            # fall through to explicit full-path compatibility check below
        } else {
            return $true
        }
    }

    # Compatibility: some RDM environments store folder.Group as full folder path including own name.
    $expectedFull = if ([string]::IsNullOrWhiteSpace($parent)) { $name } else { "$parent\$name" }
    if ($group -eq $expectedFull) {
        return $true
    }

    return $false
}

function Initialize-RDMFolderCache {
    [CmdletBinding()]
    param()

    if (-not $script:RDMFolderCache) { $script:RDMFolderCache = @{} }
    if (-not $script:RDMRootParentAliases) { $script:RDMRootParentAliases = @{} }
    if ($script:RDMFolderCacheInitialized) { return }

    try {
        $groups = @(Get-RDMEntry -Type Group -ErrorAction Stop)
    } catch {
        Write-Verbose "Could not initialize folder cache from RDM groups: $($_.Exception.Message)"
        $groups = @()
    }

    foreach ($grp in $groups) {
        if ([string]::IsNullOrWhiteSpace($grp.Name)) { continue }
        $parentPath = Normalize-RDMGroupPath -Path ([string]$grp.Group)
        $namePath = Normalize-RDMGroupPath -Path ([string]$grp.Name)

        if (-not [string]::IsNullOrWhiteSpace($namePath) -and $namePath -notlike '*\*' -and $parentPath -eq $namePath) {
            $script:RDMRootParentAliases[$namePath] = $true
        }

        $key = New-RDMFolderCacheKey -ParentPath $parentPath -Name ([string]$grp.Name)
        $script:RDMFolderCache[$key] = $true

        # Compatibility cache key when group is stored as full path incl. own name.
        $suffix = "\$namePath"
        if ($parentPath -eq $namePath) {
            $compatParent = ''
            $compatKey = New-RDMFolderCacheKey -ParentPath $compatParent -Name ([string]$grp.Name)
            $script:RDMFolderCache[$compatKey] = $true
        }
        elseif ($parentPath.EndsWith($suffix, [System.StringComparison]::OrdinalIgnoreCase)) {
            $compatParent = $parentPath.Substring(0, $parentPath.Length - $suffix.Length)
            $compatKey = New-RDMFolderCacheKey -ParentPath $compatParent -Name ([string]$grp.Name)
            $script:RDMFolderCache[$compatKey] = $true
        }
    }

    $script:RDMFolderCacheInitialized = $true
    Write-Verbose "Initialized folder cache with $($script:RDMFolderCache.Count) group entries."
}

function Find-RDMGroupEntry {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Name,
        [string]$ParentPath,
        [string]$ParentEntryId
    )

    $groups = @(Get-RDMEntry -Type Group -ErrorAction SilentlyContinue)
    if ($groups.Count -eq 0) { return $null }

    if (-not [string]::IsNullOrWhiteSpace($ParentEntryId)) {
        $byParentId = $groups | Where-Object {
            $_.Name -eq $Name -and ($_.PSObject.Properties.Name -contains 'ParentID') -and ([string]$_.ParentID -eq [string]$ParentEntryId)
        } | Select-Object -First 1
        if ($byParentId) { return $byParentId }
    }

    return ($groups | Where-Object {
        $_.Name -eq $Name -and (Test-RDMFolderPathMatch -EntryName ([string]$_.Name) -EntryGroup ([string]$_.Group) -ParentPath $ParentPath)
    } | Select-Object -First 1)
}

function Get-RDMFolderEntryByPath {
    [CmdletBinding()]
    param([Parameter(Mandatory)][string]$FolderPath)

    $normalized = Normalize-RDMGroupPath -Path $FolderPath
    if ([string]::IsNullOrWhiteSpace($normalized)) { return $null }

    $parts = @($normalized -split '\\' | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
    if ($parts.Count -eq 0) { return $null }

    $currentPath = ''
    $parentEntry = $null

    foreach ($name in $parts) {
        $parentPath = $currentPath
        $parentEntryId = ''
        if ($parentEntry) {
            if ($parentEntry.PSObject.Properties.Name -contains 'ID') { $parentEntryId = [string]$parentEntry.ID }
            elseif ($parentEntry.PSObject.Properties.Name -contains 'Id') { $parentEntryId = [string]$parentEntry.Id }
        }

        $found = Find-RDMGroupEntry -Name $name -ParentPath $parentPath -ParentEntryId $parentEntryId
        if (-not $found) { return $null }

        $parentEntry = $found
        if ([string]::IsNullOrWhiteSpace($currentPath)) { $currentPath = $name }
        else { $currentPath = "$currentPath\$name" }
    }

    return $parentEntry
}

# -------------------------
# Path-based folder creation/lookup
# In RDM: Group property for folder entries is the *parent* path; top-level => ""/$null.
# Returns FULL folder path string (what child entries use in Entry.Group)
# -------------------------
function Get-RDMTargetFolderByName {
    [CmdletBinding()]
    param([Parameter(Mandatory)][string]$FolderPath)

    Initialize-RDMFolderCache

    $parts = $FolderPath -split '\\'
    $currentPath = ""
    $parentEntry = $null

    foreach ($name in $parts) {
        if ([string]::IsNullOrWhiteSpace($name)) { continue }
        $aliasedToParent = $false
        $parentPath = $currentPath
        $parentEntryId = ''
        if ($parentEntry) {
            if ($parentEntry.PSObject.Properties.Name -contains 'ID') { $parentEntryId = [string]$parentEntry.ID }
            elseif ($parentEntry.PSObject.Properties.Name -contains 'Id') { $parentEntryId = [string]$parentEntry.Id }
        }
        $cacheKey = New-RDMFolderCacheKey -ParentPath $parentPath -Name $name

        if ($script:RDMFolderCache.ContainsKey($cacheKey)) {
            $existingFromCache = Find-RDMGroupEntry -Name $name -ParentPath $parentPath -ParentEntryId $parentEntryId

            if ($existingFromCache) {
                $parentEntry = $existingFromCache
                if ([string]::IsNullOrWhiteSpace($currentPath)) { $currentPath = $name }
                else { $currentPath = "$currentPath\$name" }
                continue
            }

            # Stale/ambiguous cache hit: remove and resolve/create via normal flow.
            $script:RDMFolderCache.Remove($cacheKey) | Out-Null
        }

        $existing = Find-RDMGroupEntry -Name $name -ParentPath $parentPath -ParentEntryId $parentEntryId

        if (-not $existing) {
            Write-Host "      Folder '$name' niet gevonden, wordt aangemaakt..." -ForegroundColor DarkGray

            $newEntry = New-RDMEntry -Type Group -Name $name
            $newEntry.Group = $parentPath
            if (-not [string]::IsNullOrWhiteSpace($parentEntryId) -and ($newEntry.PSObject.Properties.Name -contains 'ParentID')) {
                $newEntry.ParentID = $parentEntryId
            }

            $createdEntry = $null
            $alreadyExistsHint = $false
            try {
                $createdEntry = Set-RDMEntry -InputObject $newEntry -Refresh -ErrorAction Stop
            } catch {
                $isAlreadyExists = $_.Exception.Message -like "*already exists*" -or
                                   $_.Exception.Message -like "*bestaat al*"
                if (-not $isAlreadyExists) { throw }
                $alreadyExistsHint = $true
            }

            # Retry loop to ensure folder is fully committed before continuing
            Start-Sleep -Milliseconds 250
            
            for ($retry = 0; $retry -lt 5; $retry++) {
                if ($retry -gt 0) {
                    Start-Sleep -Milliseconds (250 * $retry)
                }
                
                $existing = Find-RDMGroupEntry -Name $name -ParentPath $parentPath -ParentEntryId $parentEntryId

                if ($existing) { break }
            }

            if (-not $existing -and [string]::IsNullOrWhiteSpace($parentPath)) {
                # Root-level compatibility: sommige RDM versies slaan top-level Group op als naam i.p.v. leeg.
                $existing = Get-RDMEntry -Type Group | Where-Object {
                    if ($_.Name -ne $name) { return $false }
                    $grp = Normalize-RDMGroupPath -Path ([string]$_.Group)
                    return ([string]::IsNullOrWhiteSpace($grp) -or $grp -eq $name)
                } | Select-Object -First 1

                if ($existing) {
                    $script:RDMRootParentAliases[(Normalize-RDMGroupPath -Path $name)] = $true
                    Write-Host "      Root folder '$name' gevonden via compatibiliteitsmatch" -ForegroundColor DarkGray
                }
            }

            $createdId = $null
            if ($createdEntry) {
                if ($createdEntry.PSObject.Properties.Name -contains 'ID') { $createdId = $createdEntry.ID }
                elseif ($createdEntry.PSObject.Properties.Name -contains 'Id') { $createdId = $createdEntry.Id }
            }

            if (-not $existing -and $createdEntry) {
                $existing = $createdEntry
            }

            if (-not $existing -and $alreadyExistsHint) {
                # Sommige RDM-omgevingen staan geen child-folder toe met exact dezelfde naam als de parent.
                # Voor paden zoals ...\Netwerk\Netwerk aliasen we dan naar de bestaande parent-map.
                # Gebruik -ceq (case-sensitief) om te voorkomen dat "Archief" en "ARCHIEF" foutief
                # als dezelfde naam worden beschouwd — PowerShell's -eq is case-insensitief.
                if ($parentEntry -and [string]$parentEntry.Name -ceq $name) {
                    Write-Host "      RDM-limiet: '$name' kan niet als child onder zichzelf; alias naar bestaande parent-map" -ForegroundColor DarkYellow
                    $existing = $parentEntry
                    $aliasedToParent = $true
                }

                # RDM kan "already exists" geven terwijl directe enum tijdelijk niets teruggeeft.
                # In plaats van door te gaan met een onbevestigde map, doen we extra strict retries.
                if (-not $existing) {
                    try { Update-RDMUI | Out-Null } catch {}
                    for ($retry = 0; $retry -lt 8; $retry++) {
                        Start-Sleep -Milliseconds (300 + (150 * $retry))
                        $existing = Find-RDMGroupEntry -Name $name -ParentPath $parentPath -ParentEntryId $parentEntryId
                        if ($existing) { break }
                    }
                }

                if (-not $existing -and [string]::IsNullOrWhiteSpace($parentPath)) {
                    $existing = Get-RDMEntry -Type Group | Where-Object {
                        if ($_.Name -ne $name) { return $false }
                        $grp = Normalize-RDMGroupPath -Path ([string]$_.Group)
                        return ([string]::IsNullOrWhiteSpace($grp) -or $grp -eq $name)
                    } | Select-Object -First 1
                }
            }

            if (-not $existing) {
                throw "Failed to create or find folder '$name' under parent '$parentPath' (strict path match)."
            }
        }

        # Update cache na gevonden/nieuw aangemaakte folder
        $script:RDMFolderCache[$cacheKey] = $true
        $parentEntry = $existing

        if (-not $aliasedToParent) {
            if ([string]::IsNullOrWhiteSpace($currentPath)) { $currentPath = $name }
            else { $currentPath = "$currentPath\$name" }
        }
    }

    return $currentPath
}

function Get-SearchableTextFromHtmlFile {
    [CmdletBinding()]
    param(
        [string]$HtmlPath,
        [int]$MaxChars = 15000
    )

    if ([string]::IsNullOrWhiteSpace($HtmlPath)) { return $null }
    if (-not (Test-Path $HtmlPath)) { return $null }

    try {
        $html = Get-Content -LiteralPath $HtmlPath -Raw -Encoding UTF8
        if ([string]::IsNullOrWhiteSpace($html)) { return $null }

        $text = $html -replace '(?is)<script\b[^>]*>.*?</script>', ' '
        $text = $text -replace '(?is)<style\b[^>]*>.*?</style>', ' '
        $text = $text -replace '(?is)<[^>]+>', ' '
        $text = [System.Net.WebUtility]::HtmlDecode($text)
        $text = $text -replace '\s+', ' '
        $text = $text.Trim()

        if ([string]::IsNullOrWhiteSpace($text)) { return $null }
        if ($text.Length -gt $MaxChars) {
            $text = $text.Substring(0, $MaxChars)
        }

        return $text
    } catch {
        Write-Verbose "Could not build search text from HTML '$HtmlPath': $($_.Exception.Message)"
        return $null
    }
}

function Get-RDMCollapsedDuplicatePath {
    [CmdletBinding()]
    param([string]$Path)

    $normalized = Normalize-RDMGroupPath -Path $Path
    if ([string]::IsNullOrWhiteSpace($normalized)) {
        return [pscustomobject]@{ Path = $normalized; Changed = $false }
    }

    $parts = @($normalized -split '\\' | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
    if ($parts.Count -le 1) {
        return [pscustomobject]@{ Path = $normalized; Changed = $false }
    }

    $collapsed = New-Object System.Collections.Generic.List[string]
    foreach ($segment in $parts) {
        if ($collapsed.Count -gt 0 -and $collapsed[$collapsed.Count - 1].Equals($segment, [System.StringComparison]::OrdinalIgnoreCase)) {
            continue
        }
        $collapsed.Add($segment)
    }

    $candidate = ($collapsed -join '\')
    return [pscustomobject]@{ Path = $candidate; Changed = ($candidate -ne $normalized) }
}

function Get-RDMEntryFullPath {
    [CmdletBinding()]
    param(
        [object]$Entry,
        [string]$FallbackPath
    )

    $fallback = Normalize-RDMGroupPath -Path $FallbackPath
    if (-not $Entry) { return $fallback }

    $entryName = ''
    if ($Entry.PSObject.Properties.Name -contains 'Name') {
        $entryName = Normalize-RDMGroupPath -Path ([string]$Entry.Name)
    }

    $entryGroup = ''
    if ($Entry.PSObject.Properties.Name -contains 'Group') {
        $entryGroup = Normalize-RDMGroupPath -Path ([string]$Entry.Group)
    }

    if ([string]::IsNullOrWhiteSpace($entryName)) {
        return $(if ([string]::IsNullOrWhiteSpace($entryGroup)) { $fallback } else { $entryGroup })
    }

    $result = ''

    if ([string]::IsNullOrWhiteSpace($entryGroup)) {
        $result = $entryName
    }
    elseif ($entryGroup -eq $entryName) {
        $result = $entryName
    }
    elseif ($entryGroup.EndsWith(("\\" + $entryName), [System.StringComparison]::OrdinalIgnoreCase)) {
        $result = $entryGroup
    }
    else {
        $result = "$entryGroup\\$entryName"
    }

    $collapsed = Get-RDMCollapsedDuplicatePath -Path $result
    return (Normalize-RDMGroupPath -Path $collapsed.Path)
}

function Build-DocumentationDescription {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][object]$ItemData,
        [int]$MaxSearchChars = 15000
    )

    $descParts = @()
    if ($ItemData.Summary) { $descParts += $ItemData.Summary }
    if ($ItemData.SourceNotebook) { $descParts += "`nOneNote: $($ItemData.SourceNotebook)" }
    if ($ItemData.SourceSection) { $descParts += "Sectie: $($ItemData.SourceSection)" }
    if ($ItemData.PageLevel -and $ItemData.PageLevel -gt 0) { $descParts += "Level: $($ItemData.PageLevel) (subpagina)" }

    $description = ($descParts -join "`n")
    $searchText = Get-SearchableTextFromHtmlFile -HtmlPath $ItemData.HTMLFilePath -MaxChars $MaxSearchChars
    if (-not [string]::IsNullOrWhiteSpace($searchText)) {
        if (-not [string]::IsNullOrWhiteSpace($description)) {
            $description += "`n`n"
        }
        $description += "[SEARCH-INDEX]`n$searchText"
    }

    return $description
}

function Compress-HtmlBase64Images {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Html,
        [int]$MaxWidth = 1200,
        [int]$Quality = 70
    )

    try {
        Add-Type -AssemblyName System.Drawing -ErrorAction Stop
    } catch {
        Write-Verbose "System.Drawing niet beschikbaar - afbeeldingen niet gecomprimeerd: $($_.Exception.Message)"
        return $Html
    }

    $imagePattern = '(?<prefix><img[^>]+src=")(?<data>data:image/[^;]+;base64,[^"]+)(?<suffix>")'
    $imgMatches = [regex]::Matches($Html, $imagePattern)
    if ($imgMatches.Count -eq 0) { return $Html }

    $result = $Html
    $compressed = 0
    foreach ($m in $imgMatches) {
        $dataUri = $m.Groups['data'].Value
        $base64Data = $dataUri -replace '^data:image/[^;]+;base64,', ''
        $originalBytes = $null
        $newBytes = $null
        $ms = $null
        $outStream = $null
        $original = $null
        $bmp = $null
        $gfx = $null
        try {
            $originalBytes = [Convert]::FromBase64String($base64Data)
            $ms = New-Object System.IO.MemoryStream($originalBytes, 0, $originalBytes.Length)
            $original = [System.Drawing.Image]::FromStream($ms, $true)

            $newWidth  = if ($original.Width -gt $MaxWidth) { $MaxWidth } else { $original.Width }
            $newHeight = [int]($original.Height * ($newWidth / $original.Width))

            $bmp = New-Object System.Drawing.Bitmap($newWidth, $newHeight)
            $gfx = [System.Drawing.Graphics]::FromImage($bmp)
            $gfx.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
            $gfx.DrawImage($original, 0, 0, $newWidth, $newHeight)

            $outStream = New-Object System.IO.MemoryStream
            $jpegCodec = [System.Drawing.Imaging.ImageCodecInfo]::GetImageEncoders() |
                         Where-Object { $_.MimeType -eq 'image/jpeg' }
            $encParams = New-Object System.Drawing.Imaging.EncoderParameters(1)
            $encParams.Param[0] = New-Object System.Drawing.Imaging.EncoderParameter(
                [System.Drawing.Imaging.Encoder]::Quality, [long]$Quality)
            $bmp.Save($outStream, $jpegCodec, $encParams)

            $newBytes = $outStream.ToArray()

            # Alleen vervangen als de nieuwe afbeelding daadwerkelijk kleiner is.
            if ($newBytes.Length -lt $originalBytes.Length) {
                $newBase64 = [Convert]::ToBase64String($newBytes)
                $newDataUri = "data:image/jpeg;base64,$newBase64"
                $result = $result.Replace($dataUri, $newDataUri)
                $compressed++
            }
        } catch {
            Write-Verbose "Afbeelding compressie mislukt: $($_.Exception.Message)"
        } finally {
            if ($gfx) { $gfx.Dispose() }
            if ($bmp) { $bmp.Dispose() }
            if ($original) { $original.Dispose() }
            if ($ms) { $ms.Dispose() }
            if ($outStream) { $outStream.Dispose() }
        }
    }
    Write-Verbose "Compress-HtmlBase64Images: $compressed/$($imgMatches.Count) afbeeldingen gecomprimeerd"
    return $result
}

function Get-DocumentationEditableHtmlFromFile {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$HtmlPath,
        [int]$MaxHtmlChars = 10485760
    )

    if ([string]::IsNullOrWhiteSpace($HtmlPath)) { return $null }
    if (-not (Test-Path $HtmlPath)) { return $null }

    try {
        $rawHtml = Get-Content -LiteralPath $HtmlPath -Raw -Encoding UTF8
        if ([string]::IsNullOrWhiteSpace($rawHtml)) { return $null }

        $cleanHtml = $rawHtml -replace '(?is)<script\b[^>]*>.*?</script>', ''

        $styleMatches = [regex]::Matches($cleanHtml, '(?is)<style\b[^>]*>.*?</style>')
        $styleBlocks = @($styleMatches | ForEach-Object { $_.Value })
        $styleHtml = if ($styleBlocks.Count -gt 0) { ($styleBlocks -join "`n") } else { '' }
        $styleHtml = $styleHtml -replace '(?i)position\s*:\s*absolute', 'position: static'

        $bodyMatch = [regex]::Match($cleanHtml, '(?is)<body\b[^>]*>(?<body>.*)</body>')
        $bodyHtml = if ($bodyMatch.Success) { $bodyMatch.Groups['body'].Value } else { $cleanHtml }
        $bodyHtml = $bodyHtml -replace '(?is)</?(html|head|body)\b[^>]*>', ''
        $bodyHtml = $bodyHtml -replace '(?i)position\s*:\s*absolute', 'position: static'
        $bodyHtml = $bodyHtml.Trim()

        if ([string]::IsNullOrWhiteSpace($bodyHtml)) { return $null }

        $parts = @(
            '<div style="clear: both; display: block; margin-top: 8px;">',
            '<p><em>Geïmporteerd vanuit OneNote. Voor volledige bron en losse bestanden: gebruik de attachments.</em></p>',
            $styleHtml,
            ('<div style="clear: both; display: block; position: static;">{0}</div>' -f $bodyHtml),
            '</div>'
        )
        $composed = ($parts -join "`n")

        $compressedOnDisk = $false

        if ($composed.Length -gt $MaxHtmlChars) {
            Write-ImportLog "HTML te groot voor inline weergave: $(Split-Path $HtmlPath -Leaf) ($([math]::Round($composed.Length/1MB,1)) MB > 10 MB) - compressie stap 1: schalen naar max. 1200px..." 'WARN'
            $composed = Compress-HtmlBase64Images -Html $composed -MaxWidth 1200 -Quality 70
            $compressedOnDisk = $true
            Write-Verbose "Na compressie stap 1: $($composed.Length) tekens"
        }

        if ($composed.Length -gt $MaxHtmlChars) {
            Write-ImportLog "HTML nog steeds te groot na stap 1: $(Split-Path $HtmlPath -Leaf) ($([math]::Round($composed.Length/1MB,1)) MB) - compressie stap 2: schalen naar max. 600px..." 'WARN'
            $composed = Compress-HtmlBase64Images -Html $composed -MaxWidth 600 -Quality 70
            Write-Verbose "Na compressie stap 2: $($composed.Length) tekens"
        }

        if ($composed.Length -gt $MaxHtmlChars) {
            Write-ImportLog "HTML nog steeds te groot na compressie: $(Split-Path $HtmlPath -Leaf) ($([math]::Round($composed.Length/1MB,1)) MB > 10 MB) - inline view uitgeschakeld, bijlage behouden" 'WARN'
            return $null
        }

        # Gecomprimeerde HTML terugschrijven naar schijf om ruimte te besparen
        if ($compressedOnDisk) {
            try {
                $composed | Set-Content -LiteralPath $HtmlPath -Encoding UTF8 -Force
                Write-ImportLog "page.rdm.html gecomprimeerd op schijf: $(Split-Path $HtmlPath -Leaf) ($([math]::Round($composed.Length/1MB,1)) MB)" 'INFO'
            } catch {
                Write-Verbose "Kon gecomprimeerde HTML niet terugschrijven naar '$HtmlPath': $($_.Exception.Message)"
            }
        }

        return $composed
    } catch {
        Write-Verbose "Could not build editable documentation HTML from '$HtmlPath': $($_.Exception.Message)"
        return $null
    }
}

function Get-NormalizedAttachmentPaths {
    [CmdletBinding()]
    param([object]$AttachmentPaths)

    $normalized = New-Object System.Collections.Generic.List[string]
    if ($null -eq $AttachmentPaths) { return @() }

    if ($AttachmentPaths -is [string]) {
        if (-not [string]::IsNullOrWhiteSpace($AttachmentPaths)) {
            $normalized.Add([string]$AttachmentPaths)
        }
        return @($normalized)
    }

    if ($AttachmentPaths -is [System.Collections.IEnumerable]) {
        foreach ($item in $AttachmentPaths) {
            if ($item -is [string]) {
                if (-not [string]::IsNullOrWhiteSpace($item)) {
                    $normalized.Add([string]$item)
                }
            } elseif ($null -ne $item) {
                $text = [string]$item
                if (-not [string]::IsNullOrWhiteSpace($text)) {
                    $normalized.Add($text)
                }
            }
        }
        return @($normalized)
    }

    $single = [string]$AttachmentPaths
    if (-not [string]::IsNullOrWhiteSpace($single)) {
        $normalized.Add($single)
    }
    return @($normalized)
}
function Build-DocumentationAttachmentListHtml {
    [CmdletBinding()]
    param([Parameter(Mandatory)][object]$ItemData)

    $rowItems = New-Object System.Collections.Generic.List[object]
    $seen = @{}
    $sourceBadgeStyle = 'display:inline-block;padding:2px 8px;border-radius:10px;background:#e8f5e9;color:#1b5e20;font-weight:600;'
    $attachmentBadgeStyle = 'display:inline-block;padding:2px 8px;border-radius:10px;background:#f1f3f4;color:#4a4a4a;font-weight:600;'

    $htmlFullPath = $null
    if ($ItemData.HTMLFilePath -and (Test-Path -LiteralPath $ItemData.HTMLFilePath)) {
        $resolvedHtml = Resolve-Path -LiteralPath $ItemData.HTMLFilePath -ErrorAction SilentlyContinue | Select-Object -First 1
        if ($resolvedHtml) {
            $htmlFullPath = $resolvedHtml.Path
        } else {
            $htmlFullPath = $ItemData.HTMLFilePath
        }
    }

    $allPaths = New-Object System.Collections.Generic.List[string]
    if ($ItemData.HTMLFilePath -and -not [string]::IsNullOrWhiteSpace($ItemData.HTMLFilePath)) {
        $allPaths.Add([string]$ItemData.HTMLFilePath)
    }
    $attachmentPaths = @(Get-NormalizedAttachmentPaths -AttachmentPaths $ItemData.AttachmentPaths)
    if ($attachmentPaths.Count -gt 0) {
        foreach ($path in $attachmentPaths) {
            if (-not [string]::IsNullOrWhiteSpace($path)) {
                $allPaths.Add([string]$path)
            }
        }
    }

    foreach ($path in $allPaths) {
        if (-not (Test-Path -LiteralPath $path)) { continue }

        $fullPath = (Resolve-Path -LiteralPath $path -ErrorAction SilentlyContinue | Select-Object -First 1).Path
        if ([string]::IsNullOrWhiteSpace($fullPath)) { $fullPath = $path }

        $key = $fullPath.ToLowerInvariant()
        if ($seen.ContainsKey($key)) { continue }
        $seen[$key] = $true

        $fileName = [System.IO.Path]::GetFileName($fullPath)
        if ([string]::IsNullOrWhiteSpace($fileName)) { $fileName = $fullPath }

        $isSourceHtml = $false
        if (-not [string]::IsNullOrWhiteSpace($htmlFullPath)) {
            $isSourceHtml = ($fullPath.ToLowerInvariant() -eq $htmlFullPath.ToLowerInvariant())
        }

        $typeLabel = if ($isSourceHtml) { 'Bron-HTML' } else { 'Bijlage' }

        $safeName = [System.Net.WebUtility]::HtmlEncode($fileName)
        $safeTypeLabel = [System.Net.WebUtility]::HtmlEncode($typeLabel)
        $badgeStyle = if ($isSourceHtml) { $sourceBadgeStyle } else { $attachmentBadgeStyle }
        $safeBadgeStyle = [System.Net.WebUtility]::HtmlEncode($badgeStyle)
        $rowHtml = ('<li><span style="{0}">{1}</span> {2}</li>' -f $safeBadgeStyle, $safeTypeLabel, $safeName)

        [void]$rowItems.Add([pscustomobject]@{
            IsSourceHtml = $isSourceHtml
            FileName     = $fileName
            RowHtml      = $rowHtml
        })
    }

    if ($rowItems.Count -eq 0) {
        return "<p><em>Geen bijlagen gevonden voor deze import.</em></p>"
    }

    $sortedRows = $rowItems |
        Sort-Object @{ Expression = { if ($_.IsSourceHtml) { 0 } else { 1 } } },
                    @{ Expression = { $_.FileName.ToLowerInvariant() } } |
        ForEach-Object { $_.RowHtml }

    $safeSourceBadgeStyle = [System.Net.WebUtility]::HtmlEncode($sourceBadgeStyle)
    $safeAttachmentBadgeStyle = [System.Net.WebUtility]::HtmlEncode($attachmentBadgeStyle)

    return @"
<h3>Bijlagen</h3>
<p><em>Open bestanden via de tab Attachments op deze entry.</em></p>
<p><span style="$safeSourceBadgeStyle">Bron-HTML</span> = originele OneNote HTML-pagina &nbsp; <span style="$safeAttachmentBadgeStyle">Bijlage</span> = extra bestand</p>
<ul>
$($sortedRows -join "`n")
</ul>
"@
}

function Build-DocumentationBodyHtml {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][object]$ItemData,
        [int]$MaxBodyChars = 30000
    )

    $attachmentListHtml = Build-DocumentationAttachmentListHtml -ItemData $ItemData

    $editableHtml = Get-DocumentationEditableHtmlFromFile -HtmlPath $ItemData.HTMLFilePath
    if (-not [string]::IsNullOrWhiteSpace($editableHtml)) {
        $script:LastInlineHtmlSuccess = $true
        return (
            '<div style="position: relative; z-index: 2; background: #fff; padding-bottom: 10px;">' + "`n" +
            $attachmentListHtml + "`n" +
            '</div>' + "`n<hr/>`n" +
            '<div style="clear: both; display: block; position: relative; z-index: 1; margin-top: 12px;">' + "`n" +
            $editableHtml + "`n" +
            '</div>'
        )
    }

    $script:LastInlineHtmlSuccess = $false

    $plainText = Get-SearchableTextFromHtmlFile -HtmlPath $ItemData.HTMLFilePath -MaxChars $MaxBodyChars
    if ([string]::IsNullOrWhiteSpace($plainText)) {
        return "<p>Geen leesbare tekst gevonden. Open de HTML-attachment voor de volledige opmaak met afbeeldingen en bijlagen.</p>"
    }

    $safeText = [System.Net.WebUtility]::HtmlEncode($plainText)
    $safeNotebook = [System.Net.WebUtility]::HtmlEncode([string]$ItemData.SourceNotebook)
    $safeSection = [System.Net.WebUtility]::HtmlEncode([string]$ItemData.SourceSection)

    return (
        '<div style="position: relative; z-index: 2; background: #fff; padding-bottom: 10px;">' + "`n" +
        $attachmentListHtml + "`n" +
        '</div>' + "`n<hr/>`n" +
        '<div style="clear: both; display: block; margin-top: 12px;">' + "`n" +
        '<h2>OneNote inhoud (tekstweergave)</h2>' + "`n" +
        ('<p><strong>Notebook:</strong> {0}<br/>' -f $safeNotebook) + "`n" +
        ('<strong>Sectie:</strong> {0}</p>' -f $safeSection) + "`n" +
        '<p><em>Voor volledige opmaak, afbeeldingen en bestanden: open de HTML-attachment(s).</em></p>' + "`n" +
        '<hr/>' + "`n" +
        ('<pre style="white-space: pre-wrap; font-family: Segoe UI, Arial, sans-serif;">{0}</pre>' -f $safeText) + "`n" +
        '</div>'
    )
}

function Convert-PlainTextToRtf {
    [CmdletBinding()]
    param([string]$Text)

    if ([string]::IsNullOrWhiteSpace($Text)) { return $null }

    $escaped = $Text -replace '\\', '\\\\'
    $escaped = $escaped -replace '\{', '\\{'
    $escaped = $escaped -replace '\}', '\\}'
    $escaped = $escaped -replace "`r`n|`n|`r", '\\par '

    return "{\\rtf1\\ansi $escaped}"
}

function Set-RDMEntryEmbeddedViewMode {
    param([Parameter(Mandatory)][object]$Entry)
    # Zet de display-modus op "Embedded (tabbed)" zodat entries inline openen in RDM
    # ipv het externe venster dat de fout "Unable to retrieve..." veroorzaakt.
    try {
        if ($Entry.PSObject.Properties.Name -contains 'ViewMode') {
            $Entry.ViewMode = 'EmbeddedTab'
        }
    } catch { }
}

function Set-RDMEntrySearchFields {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][object]$Entry,
        [Parameter(Mandatory)][object]$ItemData
    )

    $description = Build-DocumentationDescription -ItemData $ItemData
    $Entry.Description = $description

    $searchText = Get-SearchableTextFromHtmlFile -HtmlPath $ItemData.HTMLFilePath -MaxChars 2000
    if (-not [string]::IsNullOrWhiteSpace($searchText)) {
        $rtf = Convert-PlainTextToRtf -Text $searchText
        if (-not [string]::IsNullOrWhiteSpace($rtf)) {
            $Entry.DescriptionRtf = $rtf
        }

        $maxTitleLen = 220
        if ($searchText.Length -gt $maxTitleLen) {
            $Entry.DocumentationTitle = $searchText.Substring(0, $maxTitleLen)
        } else {
            $Entry.DocumentationTitle = $searchText
        }
    }
}

function Set-RDMDocumentationBodyHtml {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][object]$Entry,
        [Parameter(Mandatory)][string]$HtmlBody,
        [string]$PageName = 'OneNote Import'
    )

    if (-not $Entry) { return $false }
    if ([string]::IsNullOrWhiteSpace($HtmlBody)) { return $false }

    $marker = "ONENOTE-IMPORT-MARKER"
    $payload = "<!-- $marker -->`n$HtmlBody"

    $entryId = $null
    if ($Entry.PSObject.Properties.Name -contains 'ID') {
        $entryId = [string]$Entry.ID
    }

    for ($attempt = 1; $attempt -le 5; $attempt++) {
        $targetEntry = $Entry

        if (-not [string]::IsNullOrWhiteSpace($entryId)) {
            try {
                $fresh = Get-RDMEntry | Where-Object { [string]$_.ID -eq $entryId } | Select-Object -First 1
                if ($fresh) { $targetEntry = $fresh }
            } catch {
            }
        }

        try {
            try {
                Remove-RDMSessionDocumentation -Session $targetEntry -All -Force -Refresh -ErrorAction SilentlyContinue | Out-Null
            } catch {
            }

            New-RDMEntryDocumentation -InputObject $targetEntry -Type Html -Name $PageName -Data $payload -AsNewDefault -Set -ErrorAction Stop | Out-Null
        } catch {
            if ($attempt -lt 5) {
                Start-Sleep -Milliseconds (200 * $attempt)
                continue
            }
            Write-Verbose "Failed to create documentation page '$PageName': $($_.Exception.Message)"
            return $false
        }

        try {
            $verifyPages = @(Get-RDMEntryDocumentation -InputObject $targetEntry -ErrorAction SilentlyContinue)
            if ($verifyPages.Count -gt 0) {
                $verifyPage = $verifyPages | Where-Object {
                    ($_.PSObject.Properties.Name -contains 'Name') -and ([string]$_.Name -eq $PageName)
                } | Select-Object -First 1

                if (-not $verifyPage) { $verifyPage = $verifyPages | Select-Object -First 1 }

                if ($verifyPage) {
                    foreach ($prop in @('Data','Content','Documentation','Html')) {
                        if ($verifyPage.PSObject.Properties.Name -contains $prop) {
                            $val = [string]$verifyPage.$prop
                            if (-not [string]::IsNullOrWhiteSpace($val) -and $val -like "*$marker*") {
                                return $true
                            }
                        }
                    }
                }
            }
        } catch {
        }

        if ($attempt -lt 5) {
            Start-Sleep -Milliseconds (200 * $attempt)
        }
    }

    return $false
}

function Get-RDMEntryTypeName {
    [CmdletBinding()]
    param([Parameter(Mandatory)][object]$Entry)

    if (-not $Entry) { return '' }

    foreach ($prop in @('Type','EntryType','ConnectionType','SessionType')) {
        if ($Entry.PSObject.Properties.Name -contains $prop) {
            $value = [string]$Entry.$prop
            if (-not [string]::IsNullOrWhiteSpace($value)) {
                return $value
            }
        }
    }

    return ''
}

function Test-IsDocumentationEntry {
    [CmdletBinding()]
    param([Parameter(Mandatory)][object]$Entry)

    $typeName = Get-RDMEntryTypeName -Entry $Entry
    if ([string]::IsNullOrWhiteSpace($typeName)) { return $false }

    return ($typeName -match '(?i)documentation|document')
}

function Test-IsGroupEntry {
    [CmdletBinding()]
    param([Parameter(Mandatory)][object]$Entry)

    $typeName = Get-RDMEntryTypeName -Entry $Entry
    if ([string]::IsNullOrWhiteSpace($typeName)) { return $false }

    return ($typeName -match '(?i)^group$')
}

function Get-RDMEntryAttachmentFileNameSet {
    [CmdletBinding()]
    param([Parameter(Mandatory)][object]$Entry)

    $nameSet = @{}
    try {
        $rawAtts = @(Get-RDMEntryAttachment -InputObject $Entry -ErrorAction SilentlyContinue)
    } catch {
        $rawAtts = @()
    }

    $atts = New-Object System.Collections.Generic.List[object]
    foreach ($att in $rawAtts) {
        if ($null -eq $att) { continue }

        if ($att -is [System.Array]) {
            foreach ($nested in $att) {
                if ($null -ne $nested) { [void]$atts.Add($nested) }
            }
        } else {
            [void]$atts.Add($att)
        }
    }

    foreach ($att in $atts) {
        $raw = [string]$att.FileName
        if ([string]::IsNullOrWhiteSpace($raw)) { continue }

        $allPaths = $raw -split '(?=[A-Z]:\\)' | Where-Object { $_ -and $_.Trim().Length -gt 0 }
        if ($allPaths.Count -eq 0) { $allPaths = @($raw) }

        foreach ($pathLike in $allPaths) {
            $candidate = $pathLike.Trim()
            if ([string]::IsNullOrWhiteSpace($candidate)) { continue }
            $name = Split-Path $candidate -Leaf
            if ([string]::IsNullOrWhiteSpace($name)) { $name = $candidate }
            $nameSet[$name.ToLowerInvariant()] = $true
        }
    }

    return $nameSet
}

function Ensure-RDMExpectedAttachments {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][object]$Entry,
        [Parameter(Mandatory)][object]$ItemData,
        [string]$Prefix = '    ',
        [bool]$SkipHtmlAttachment = $false
    )

    $expectedPaths = New-Object System.Collections.Generic.List[string]
    if (-not $SkipHtmlAttachment -and $ItemData.HTMLFilePath -and -not [string]::IsNullOrWhiteSpace($ItemData.HTMLFilePath) -and (Test-Path $ItemData.HTMLFilePath)) {
        $expectedPaths.Add([string]$ItemData.HTMLFilePath)
    }
    $attachmentPaths = @(Get-NormalizedAttachmentPaths -AttachmentPaths $ItemData.AttachmentPaths)
    if ($attachmentPaths.Count -gt 0) {
        foreach ($path in $attachmentPaths) {
            if (-not [string]::IsNullOrWhiteSpace($path) -and (Test-Path $path)) {
                $expectedPaths.Add([string]$path)
            }
        }
    }

    if ($expectedPaths.Count -eq 0) { return }

    $expectedByName = @{}
    foreach ($path in $expectedPaths) {
        $name = Split-Path $path -Leaf
        if (-not [string]::IsNullOrWhiteSpace($name)) {
            $expectedByName[$name.ToLowerInvariant()] = $path
        }
    }

    for ($attempt = 1; $attempt -le 2; $attempt++) {
        $present = Get-RDMEntryAttachmentFileNameSet -Entry $Entry
        $missing = @($expectedByName.Keys | Where-Object { -not $present.ContainsKey($_) })
        if ($missing.Count -eq 0) { break }

        foreach ($missingName in $missing) {
            $path = $expectedByName[$missingName]
            if (-not [string]::IsNullOrWhiteSpace($path) -and (Test-Path $path)) {
                try {
                    Add-RDMEntryAttachment -InputObject $Entry -Filename $path -ErrorAction Stop | Out-Null
                    Write-Host "$Prefix└─ ✓ Retry attach: $(Split-Path $path -Leaf)" -ForegroundColor DarkGray
                } catch {
                    Write-AttachmentImportWarning -FilePath $path -ErrorMessage $_.Exception.Message -Prefix "$Prefix└─ "
                }
            }
        }
    }

    $presentFinal = Get-RDMEntryAttachmentFileNameSet -Entry $Entry
    $missingFinal = @($expectedByName.Keys | Where-Object { -not $presentFinal.ContainsKey($_) })
    $expectedCount = $expectedByName.Count
    $presentCount = ($expectedByName.Keys | Where-Object { $presentFinal.ContainsKey($_) }).Count

    if ($missingFinal.Count -gt 0) {
        $missingNames = @($missingFinal | ForEach-Object { Split-Path $expectedByName[$_] -Leaf }) -join ', '
        Write-Warning "$Prefix└─ Attachments incomplete: $presentCount/$expectedCount present. Missing: $missingNames"
    } else {
        Write-Host "$Prefix└─ ✓ Attachments verified: $presentCount/$expectedCount present" -ForegroundColor Green
    }
}

function Get-RDMEntryHealthScore {
    [CmdletBinding()]
    param([Parameter(Mandatory)][object]$Entry)

    $score = 0

    try {
        $docs = @(Get-RDMEntryDocumentation -InputObject $Entry -ErrorAction SilentlyContinue)
    } catch {
        $docs = @()
    }

    $docCount = $docs.Count
    $score += ($docCount * 100)

    $hasNonEmptyDocData = $false
    foreach ($doc in $docs) {
        foreach ($prop in @('Data','Content','Documentation','Html')) {
            if ($doc.PSObject.Properties.Name -contains $prop) {
                $value = [string]$doc.$prop
                if (-not [string]::IsNullOrWhiteSpace($value)) {
                    $hasNonEmptyDocData = $true
                    break
                }
            }
        }
        if ($hasNonEmptyDocData) { break }
    }
    if ($hasNonEmptyDocData) { $score += 500 }

    $attSet = Get-RDMEntryAttachmentFileNameSet -Entry $Entry
    $attCount = $attSet.Count
    $score += ($attCount * 10)

    $typeName = Get-RDMEntryTypeName -Entry $Entry
    if (-not [string]::IsNullOrWhiteSpace($typeName) -and $typeName -match '(?i)document') {
        $score += 25
    }

    return [int]$score
}

function Resolve-RDMDuplicateEntries {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][object[]]$Entries,
        [string]$LogPrefix = '    '
    )

    if (-not $Entries -or $Entries.Count -eq 0) { return $null }
    if ($Entries.Count -eq 1) { return $Entries[0] }

    $ranked = @(
        $Entries | ForEach-Object {
            [pscustomobject]@{
                Entry = $_
                Score = Get-RDMEntryHealthScore -Entry $_
                Id    = $_.ID
            }
        } | Sort-Object Score -Descending
    )

    $keep = $ranked[0].Entry
    Write-Host "${LogPrefix}WAARSCHUWING: $($Entries.Count) dubbele entries gevonden - behoud ID $($keep.ID), score $($ranked[0].Score)" -ForegroundColor Yellow

    foreach ($candidate in ($ranked | Select-Object -Skip 1)) {
        $dup = $candidate.Entry
        try {
            Remove-RDMEntry -InputObject $dup -ForcePromptAnswer Yes -Refresh -ErrorAction Stop | Out-Null
            Write-Host "${LogPrefix}✓ Dubbele entry verwijderd (ID: $($dup.ID), score $($candidate.Score))" -ForegroundColor DarkGray
        } catch {
            try {
                Remove-RDMSession -Id $dup.ID -Force -ErrorAction Stop | Out-Null
                Write-Host "${LogPrefix}✓ Dubbele entry verwijderd via fallback (ID: $($dup.ID), score $($candidate.Score))" -ForegroundColor DarkGray
            } catch {
                Write-Warning "${LogPrefix}Kon dubbele entry niet verwijderen (ID: $($dup.ID)): $($_.Exception.Message)"
            }
        }
    }

    return $keep
}

function Invoke-RDMDuplicateConsistencySweep {
    [CmdletBinding()]
    param()

    Write-Host "`nRunning post-import duplicate consistency sweep..." -ForegroundColor Cyan

    try {
        $entries = @(Get-RDMEntry -ErrorAction Stop)
    } catch {
        Write-Warning "Could not enumerate entries for duplicate sweep: $($_.Exception.Message)"
        return [pscustomobject]@{ DuplicateGroups = 0; RemovedEntries = 0 }
    }

    $candidates = @(
        $entries | Where-Object {
            -not (Test-IsGroupEntry -Entry $_) -and
            -not [string]::IsNullOrWhiteSpace([string]$_.Name)
        }
    )

    $groups = @(
        $candidates | Group-Object {
            $grp = if ([string]::IsNullOrWhiteSpace([string]$_.Group)) { '' } else { [string]$_.Group }
            "$grp|||$([string]$_.Name)"
        } | Where-Object { $_.Count -gt 1 }
    )

    if ($groups.Count -eq 0) {
        Write-Host "  ✓ Geen duplicate naam+map combinaties gevonden." -ForegroundColor Green
        return [pscustomobject]@{ DuplicateGroups = 0; RemovedEntries = 0 }
    }

    $removedTotal = 0
    foreach ($grp in $groups) {
        $items = @($grp.Group)
        if ($items.Count -le 1) { continue }

        $before = $items.Count
        [void](Resolve-RDMDuplicateEntries -Entries $items -LogPrefix '  ')
        $removedTotal += ($before - 1)
    }

    Write-Host "  ✓ Duplicate sweep complete: groups=$($groups.Count), removed=$removedTotal" -ForegroundColor Green
    return [pscustomobject]@{ DuplicateGroups = $groups.Count; RemovedEntries = $removedTotal }
}

function Invoke-RDMDuplicateConsistencySweepForEntry {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Name,
        [Parameter(Mandatory)][string]$GroupPath,
        [string]$LogPrefix = '    '
    )

    $entries = @(
        Get-RDMEntry | Where-Object {
            $_.Name -eq $Name -and
            $_.Group -eq $GroupPath -and
            -not (Test-IsGroupEntry -Entry $_)
        }
    )

    if ($entries.Count -le 1) {
        return 0
    }

    $before = $entries.Count
    [void](Resolve-RDMDuplicateEntries -Entries $entries -LogPrefix $LogPrefix)
    return ($before - 1)
}

function Get-RDMDocumentationEntryType {
    [CmdletBinding()]
    param()

    if (-not [string]::IsNullOrWhiteSpace($script:RDMDocumentationEntryType)) {
        return $script:RDMDocumentationEntryType
    }

    $script:RDMDocumentationEntryType = 'Document'
    Write-Verbose "Using RDM entry type 'Document' for imported HTML pages."
    return $script:RDMDocumentationEntryType
}

# -------------------------
# Add attachments to a folder (Group entry)
# -------------------------
function Add-AttachmentsToFolder {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$FolderPath,
        [Parameter(Mandatory)][string]$FolderName,
        [Parameter(Mandatory)][object]$ItemData,
        [switch]$UpdateIfExists
    )

    Write-Host "    DEBUG: ENTERED Add-AttachmentsToFolder function" -ForegroundColor Magenta
    Write-Host "      Received FolderPath: [$FolderPath]" -ForegroundColor Magenta
    Write-Host "      Received FolderName: [$FolderName]" -ForegroundColor Magenta
    Write-Host "      ItemData.HTMLFilePath: [$($ItemData.HTMLFilePath)]" -ForegroundColor Magenta

    # Find or create the folder
    $parentPath = $FolderPath
    $parentEntry = $null
    $parentEntryId = ''
    if (-not [string]::IsNullOrWhiteSpace($parentPath)) {
        $parentEntry = Get-RDMFolderEntryByPath -FolderPath $parentPath
        if ($parentEntry) {
            if ($parentEntry.PSObject.Properties.Name -contains 'ID') { $parentEntryId = [string]$parentEntry.ID }
            elseif ($parentEntry.PSObject.Properties.Name -contains 'Id') { $parentEntryId = [string]$parentEntry.Id }
        }
    }

    $existing = Find-RDMGroupEntry -Name $FolderName -ParentPath $parentPath -ParentEntryId $parentEntryId

    # RDM-limiet: map kan niet dezelfde naam hebben als zijn parent-map (bijv. \Netwerk\Netwerk).
    # In dat geval aliassen we naar de bestaande parent-map.
    if (-not $existing -and $parentEntry -and [string]$parentEntry.Name -eq $FolderName) {
        Write-Host "    ⚠ RDM-limiet: '$FolderName' kan niet als child onder zichzelf; alias naar bestaande parent-map" -ForegroundColor DarkYellow
        Write-ImportLog "Naamconflict map-in-map: '$FolderName' gealiasd naar bestaande parent '$parentPath'" 'WARN'
        $existing = $parentEntry
    }

    if (-not $existing) {
        Write-Host "    Creating folder: $FolderName" -ForegroundColor DarkGray
        $newEntry = New-RDMEntry -Type Group -Name $FolderName
        $newEntry.Group = $parentPath
        if (-not [string]::IsNullOrWhiteSpace($parentEntryId) -and ($newEntry.PSObject.Properties.Name -contains 'ParentID')) {
            $newEntry.ParentID = $parentEntryId
        }

        $createdEntry = $null
        Write-Host "    └─ Saving folder to RDM..." -ForegroundColor DarkGray
        try {
            $createdEntry = Set-RDMEntry -InputObject $newEntry -Refresh -ErrorAction Stop
            $existing = $createdEntry
            Write-Host "    └─ Set-RDMEntry completed" -ForegroundColor DarkGray
        } catch {
            $isAlreadyExists = $_.Exception.Message -like "*already exists*" -or
                               $_.Exception.Message -like "*bestaat al*"
            if (-not $isAlreadyExists) {
                Write-Host "    └─ ✗ Set-RDMEntry failed (parent='$parentPath'): $($_.Exception.Message)" -ForegroundColor Red
                throw
            }
            # If already exists, try to find it below
            Write-Host "    └─ Entry already exists, will re-fetch" -ForegroundColor DarkGray
            $existing = $null
        }
        
        # ALWAYS re-fetch after creation to ensure entry is fully committed
        # Even if Set-RDMEntry returned an ID, the entry might not be fully synchronized yet
        Write-Host "    └─ Re-fetching folder after creation..." -ForegroundColor DarkGray
        
        # Small delay to allow RDM to commit the entry
        Start-Sleep -Milliseconds 250
        
        for ($retry = 0; $retry -lt 5; $retry++) {
            if ($retry -gt 0) {
                Start-Sleep -Milliseconds (250 * $retry)
            }
            
            # Try strict match first
            $existing = Find-RDMGroupEntry -Name $FolderName -ParentPath $parentPath -ParentEntryId $parentEntryId
            
            if ($existing) { break }
        }

        $createdEntryId = $null
        if ($createdEntry) {
            if ($createdEntry.PSObject.Properties.Name -contains 'ID') { $createdEntryId = $createdEntry.ID }
            elseif ($createdEntry.PSObject.Properties.Name -contains 'Id') { $createdEntryId = $createdEntry.Id }
        }

        if (-not $existing -and $createdEntry) {
            $existing = $createdEntry
        }

        if ($existing -and -not $createdEntryId -and $existing.PSObject.Properties.Name -contains 'ID') {
            $createdEntryId = $existing.ID
        } elseif ($existing -and -not $createdEntryId -and $existing.PSObject.Properties.Name -contains 'Id') {
            $createdEntryId = $existing.Id
        }

        if (-not $existing) {
            $existing = Get-RDMEntry -Type Group | Where-Object { $_.Name -eq $FolderName } | Select-Object -First 1
        }
        
        if (-not $existing) {
            throw "Failed to create or find folder '$FolderName' (parent: '$parentPath')"
        }
        
        Write-Host "    └─ ✓ Folder confirmed with ID: $($existing.ID)" -ForegroundColor Green
    } else {
        # Folder bestaat al - controleer en update bijlagen slim (zonder alles te verwijderen)
        Write-Host "    Folder exists: $FolderName" -ForegroundColor DarkYellow
    }

    Write-Host "    └─ Processing attachments for folder..." -ForegroundColor DarkGray

    $normalizeAttachmentList = {
        param([object]$RawItems)

        $normalized = @()
        foreach ($item in @($RawItems)) {
            if ($null -eq $item) { continue }

            $hasFileName = $item.PSObject.Properties.Name -contains 'FileName'
            if ($hasFileName) {
                $normalized += $item
                continue
            }

            if ($item -is [System.Collections.IEnumerable] -and -not ($item -is [string])) {
                foreach ($inner in @($item)) {
                    if ($null -eq $inner) { continue }
                    if ($inner.PSObject.Properties.Name -contains 'FileName') {
                        $normalized += $inner
                    }
                }
            }
        }

        return @($normalized)
    }
    
    # Smart attachment management: inventory existing, add missing, remove duplicates
    Write-Host "    └─ DEBUG: Fetching existing attachments for entry ID: $($existing.ID)" -ForegroundColor Magenta
    $rawExistingAtts = @(Get-RDMEntryAttachment -InputObject $existing -ErrorAction SilentlyContinue)
    $existingAtts = @(& $normalizeAttachmentList $rawExistingAtts)
    Write-Host "    └─ DEBUG: Found $($existingAtts.Count) normalized attachment object(s)" -ForegroundColor Magenta
    if ($rawExistingAtts.Count -ne $existingAtts.Count) {
        Write-Host "    └─ DEBUG: Filtered out $($rawExistingAtts.Count - $existingAtts.Count) non-attachment wrapper object(s)" -ForegroundColor Magenta
        foreach ($raw in $rawExistingAtts) {
            if ($null -eq $raw) { continue }
            if (-not ($raw.PSObject.Properties.Name -contains 'FileName')) {
                $rawType = $raw.GetType().FullName
                $rawProps = @($raw.PSObject.Properties.Name) -join ', '
                Write-Host ("    └─ DEBUG: Wrapper type={0}; properties={1}" -f $rawType, $rawProps) -ForegroundColor DarkGray
            }
        }
    }
    
    # Build inventory of existing attachments by filename
    $existingFileNames = @{}
    $duplicates = @()
    
    foreach ($att in $existingAtts) {
        # Skip attachments with null/empty filename
        if ([string]::IsNullOrWhiteSpace($att.FileName)) {
            Write-Host "    └─ ⚠ Warning: Found attachment with null/empty filename, skipping" -ForegroundColor DarkYellow
            $diagFields = @('Id','ID','AttachmentId','Name','Type','EntryId','ParentId','VaultId','Path','LocalPath','RemotePath','FileName')
            $diagParts = @()
            foreach ($field in $diagFields) {
                if ($att.PSObject.Properties.Name -contains $field) {
                    $value = $att.$field
                    if ($null -ne $value -and -not [string]::IsNullOrWhiteSpace([string]$value)) {
                        $diagParts += ("{0}={1}" -f $field, $value)
                    }
                }
            }
            if ($diagParts.Count -gt 0) {
                Write-Host ("    └─ DEBUG: Null-filename attachment details: {0}" -f ($diagParts -join '; ')) -ForegroundColor Magenta
            } else {
                $propNames = @($att.PSObject.Properties.Name)
                Write-Host ("    └─ DEBUG: Null-filename attachment has properties: {0}" -f ($propNames -join ', ')) -ForegroundColor Magenta
            }
            try {
                $stamp = Get-Date -Format 'yyyyMMdd-HHmmss-fff'
                $dumpPath = Join-Path $env:TEMP ("RDM-NullAttachment-{0}.json" -f $stamp)
                $att | ConvertTo-Json -Depth 8 | Set-Content -Path $dumpPath -Encoding UTF8
                Write-Host ("    └─ DEBUG: Null-filename attachment dumped to: {0}" -f $dumpPath) -ForegroundColor DarkGray
            } catch {
                Write-Host ("    └─ DEBUG: Could not dump null-filename attachment object: {0}" -f $_.Exception.Message) -ForegroundColor DarkYellow
            }
            continue
        }
        
        # RDM sometimes returns FileName as space-concatenated list of ALL attachment paths
        # Split on drive letter pattern (e.g., "C:\") to separate paths
        $allPaths = $att.FileName -split '(?=[A-Z]:\\)' | Where-Object { $_ -match '^[A-Z]:\\' }
        Write-Host "    └─ DEBUG: Attachment object contains $($allPaths.Count) path(s)" -ForegroundColor Magenta
        
        foreach ($fullPath in $allPaths) {
            if ([string]::IsNullOrWhiteSpace($fullPath)) { continue }
            
            $fname = Split-Path $fullPath.Trim() -Leaf
            Write-Host "    └─   - Existing: $fname" -ForegroundColor DarkGray
            
            if ($existingFileNames.ContainsKey($fname)) {
                # Duplicate found - mark for removal
                Write-Host "    └─     (marking as duplicate)" -ForegroundColor DarkYellow
                $duplicates += $att
            } else {
                $existingFileNames[$fname] = $att
            }
        }
    }
    
    # Remove duplicates if found
    if ($duplicates.Count -gt 0) {
        Write-Host "    └─ ⚠ Found $($duplicates.Count) duplicate attachment(s) - removing..." -ForegroundColor Yellow
        foreach ($dup in $duplicates) {
            if ([string]::IsNullOrWhiteSpace($dup.FileName)) {
                Write-Host "    └─   ⚠ Skipping duplicate with null filename" -ForegroundColor DarkYellow
                if ($dup.PSObject.Properties.Name -contains 'Id') {
                    Write-Host ("    └─   DEBUG: Duplicate null-filename attachment ID: {0}" -f $dup.Id) -ForegroundColor DarkGray
                }
                continue
            }
            $dupName = Split-Path $dup.FileName -Leaf
            try {
                Remove-RDMEntryAttachment -InputObject $dup -ErrorAction Stop | Out-Null
                Write-Host "    └─   ✓ Removed: $dupName" -ForegroundColor DarkGray
            } catch {
                Write-Warning "    └─   ✗ Could not remove duplicate ${dupName}: $($_.Exception.Message)"
            }
        }
        Write-Host "    └─ ✓ Duplicate cleanup completed" -ForegroundColor Green
    }
    
    # Add HTML attachment if missing or if UpdateIfExists is set
    $htmlAdded = $false
    
    # DEBUG: Show what we have
    Write-Verbose "HTMLFilePath value: '$($ItemData.HTMLFilePath)'"
    Write-Verbose "HTMLFilePath is null: $($null -eq $ItemData.HTMLFilePath)"
    Write-Verbose "HTMLFilePath is empty: $([string]::IsNullOrWhiteSpace($ItemData.HTMLFilePath))"
    
    if ($ItemData.HTMLFilePath -and -not [string]::IsNullOrWhiteSpace($ItemData.HTMLFilePath) -and (Test-Path $ItemData.HTMLFilePath)) {
        $htmlFileName = Split-Path $ItemData.HTMLFilePath -Leaf
        $htmlExists = $existingFileNames.ContainsKey($htmlFileName)
        
        if (-not $htmlExists) {
            try {
                Add-RDMEntryAttachment -InputObject $existing -Filename $ItemData.HTMLFilePath -ErrorAction Stop | Out-Null
                $sizeMB = [math]::Round(((Get-Item $ItemData.HTMLFilePath).Length / 1MB), 2)
                Write-Host "    └─ ✓ Added HTML attachment ($sizeMB MB)" -ForegroundColor Green
                $htmlAdded = $true
                
                # Refresh inventory after adding HTML (RDM may restructure attachment objects)
                $rawExistingAtts = @(Get-RDMEntryAttachment -InputObject $existing -ErrorAction SilentlyContinue)
                $existingAtts = @(& $normalizeAttachmentList $rawExistingAtts)
                $existingFileNames.Clear()
                foreach ($att in $existingAtts) {
                    if ([string]::IsNullOrWhiteSpace($att.FileName)) { continue }
                    $allPaths = $att.FileName -split '(?=[A-Z]:\\)' | Where-Object { $_ -match '^[A-Z]:\\' }
                    foreach ($fullPath in $allPaths) {
                        if ([string]::IsNullOrWhiteSpace($fullPath)) { continue }
                        $fname = Split-Path $fullPath.Trim() -Leaf
                        if (-not $existingFileNames.ContainsKey($fname)) {
                            $existingFileNames[$fname] = $att
                        }
                    }
                }
                Write-Host "    └─ Refreshed inventory: $($existingFileNames.Count) attachment(s)" -ForegroundColor DarkGray
            } catch {
                Write-AttachmentImportWarning -FilePath $ItemData.HTMLFilePath -ErrorMessage $_.Exception.Message -Prefix '    └─ '
            }
        } elseif ($UpdateIfExists) {
            # HTML exists but UpdateIfExists is set - replace it
            try {
                # Remove old HTML
                $oldHtml = $existingFileNames[$htmlFileName]
                Remove-RDMEntryAttachment -InputObject $oldHtml -ErrorAction Stop | Out-Null
                
                # Add new HTML
                Add-RDMEntryAttachment -InputObject $existing -Filename $ItemData.HTMLFilePath -ErrorAction Stop | Out-Null
                $sizeMB = [math]::Round(((Get-Item $ItemData.HTMLFilePath).Length / 1MB), 2)
                Write-Host "    └─ ✓ Updated HTML attachment ($sizeMB MB)" -ForegroundColor Green
                $htmlAdded = $true
                
                # CRITICAL: Refresh inventory after update - RDM may have recreated attachment objects
                # This prevents us from re-adding attachments that are already there
                $existingAtts = @(Get-RDMEntryAttachment -InputObject $existing -ErrorAction SilentlyContinue)
                $existingFileNames.Clear()
                foreach ($att in $existingAtts) {
                    if ([string]::IsNullOrWhiteSpace($att.FileName)) { continue }
                    $allPaths = $att.FileName -split '(?=[A-Z]:\\)' | Where-Object { $_ -match '^[A-Z]:\\' }
                    foreach ($fullPath in $allPaths) {
                        if ([string]::IsNullOrWhiteSpace($fullPath)) { continue }
                        $fname = Split-Path $fullPath.Trim() -Leaf
                        if (-not $existingFileNames.ContainsKey($fname)) {
                            $existingFileNames[$fname] = $att
                        }
                    }
                }
                Write-Host "    └─ Refreshed inventory: $($existingFileNames.Count) attachment(s)" -ForegroundColor DarkGray
            } catch {
                Write-AttachmentImportWarning -FilePath $ItemData.HTMLFilePath -ErrorMessage $_.Exception.Message -Prefix '    └─ '
            }
        } else {
            Write-Verbose "HTML attachment already exists, skipping"
        }
    } elseif ($ItemData.HTMLFilePath -and -not [string]::IsNullOrWhiteSpace($ItemData.HTMLFilePath)) {
        # HTML path specified but doesn't exist
        if (-not (Test-Path $ItemData.HTMLFilePath)) {
            Write-Host "    └─ ⚠ HTML file NOT FOUND: $($ItemData.HTMLFilePath)" -ForegroundColor Yellow
            Write-Host "    └─ This explains missing attachment!" -ForegroundColor Yellow
        }
    }

    # Add other attachments (only if not already present)
    $attachmentCount = 0
    $attachmentPaths = @(Get-NormalizedAttachmentPaths -AttachmentPaths $ItemData.AttachmentPaths)
    if ($attachmentPaths.Count -gt 0) {
        foreach ($p in $attachmentPaths) {
            try {
                if (-not [string]::IsNullOrWhiteSpace($p) -and (Test-Path $p)) {
                    $fname = Split-Path $p -Leaf
                    if (-not $existingFileNames.ContainsKey($fname)) {
                        try {
                            Add-RDMEntryAttachment -InputObject $existing -Filename $p -ErrorAction Stop | Out-Null
                            $attachmentCount++
                        } catch {
                            Write-AttachmentImportWarning -FilePath $p -ErrorMessage $_.Exception.Message -Prefix '    └─ '
                        }
                    } else {
                        Write-Verbose "Attachment $fname already exists, skipping"
                    }
                }
            } catch {
                Write-Host "    └─ ⚠ Error processing attachment path '$p': $($_.Exception.Message)" -ForegroundColor Red
                Write-Verbose "Attachment path value: [$p]"
                Write-Verbose "Attachment path is null: $($null -eq $p)"
            }
        }
    }

    if ($attachmentCount -gt 0) {
        Write-Host "    └─ ✓ Added $attachmentCount new attachment(s)" -ForegroundColor Green
    }
    
    # Determine return tag
    $tag = if ($htmlAdded -or $attachmentCount -gt 0 -or $duplicates.Count -gt 0) {
        'Updated'
    } elseif ($existingAtts.Count -eq 0) {
        'Created'
    } else {
        'Unchanged'
    }
    
    return [pscustomobject]@{ Entry = $existing; Tag = $tag }
}

# -------------------------
# Entry creation: Documentation (HTML self-contained + attachments)
# -------------------------
function New-RDMDocumentationEntry {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][object]$ItemData,
        [Parameter(Mandatory)][string]$GroupPath,
        [string]$EntryName,
        [switch]$SkipIfExists,
        [switch]$UpdateHtmlIfExists,
        [bool]$FailFastOnDocMismatch = $false
    )

    $effectiveEntryName = if ([string]::IsNullOrWhiteSpace($EntryName)) { $ItemData.SourcePage } else { $EntryName }

    $normalizedGroupPath = Normalize-RDMGroupPath -Path $GroupPath
    $collapsedGroupPath = Get-RDMCollapsedDuplicatePath -Path $normalizedGroupPath
    $GroupPath = Normalize-RDMGroupPath -Path $collapsedGroupPath.Path
    if ($collapsedGroupPath.Changed) {
        Write-ImportLog "GroupPath gecorrigeerd voor '$effectiveEntryName': '$normalizedGroupPath' -> '$GroupPath'" 'WARN'
    }

    # Check if entry already exists (idempotency)
    # BELANGRIJK: Get-RDMEntry gebruiken (niet Get-RDMSession) — nieuwere versies van
    # Devolutions.PowerShell retourneren Document-type entries niet meer via Get-RDMSession.
    if ($SkipIfExists -or $UpdateHtmlIfExists) {
        $allMatching = @(Get-RDMEntry | Where-Object {
            $_.Name -eq $effectiveEntryName -and $_.Group -eq $GroupPath
        })

        # Backward compatibility: older runs used 'page.rdm.html' for parent-page content entries.
        # Reuse and migrate that entry to 'Documentation' to avoid duplicate content entries.
        if ($allMatching.Count -eq 0 -and $effectiveEntryName -eq 'Documentation') {
            $allMatching = @(Get-RDMEntry | Where-Object {
                $_.Name -eq 'page.rdm.html' -and $_.Group -eq $GroupPath
            })
        }

        # Zelfde naam kan ook een map zijn; die mag nooit als bestaande pagina-entry gelden.
        $allMatching = @($allMatching | Where-Object { -not (Test-IsGroupEntry -Entry $_) })

        # Herstel: verwijder eventuele dubbele entries (zelfde naam+map), behoud de gezondste
        if ($allMatching.Count -gt 1) {
            $resolved = Resolve-RDMDuplicateEntries -Entries $allMatching -LogPrefix '    '
            if ($resolved) { $allMatching = @($resolved) }
        }

        $existing = $allMatching | Select-Object -First 1

        if ($existing) {
            if ([string]$existing.Name -ne $effectiveEntryName) {
                try {
                    $existing.Name = $effectiveEntryName
                    Set-RDMEntry -InputObject $existing -Refresh -ErrorAction Stop | Out-Null
                    Write-Host "    └─ Legacy entry renamed to '$effectiveEntryName'" -ForegroundColor DarkGray
                } catch {
                    Write-Warning "    └─ Kon legacy entry niet hernoemen naar '$effectiveEntryName': $($_.Exception.Message)"
                }
            }

            Write-Host "    Entry exists: $effectiveEntryName" -ForegroundColor DarkYellow

            # Legacy/foutieve entry types worden in update mode opnieuw aangemaakt als
            # compatibel documentation-entry type (Documentation of Document, afhankelijk van module).
            if ($UpdateHtmlIfExists -and -not (Test-IsDocumentationEntry -Entry $existing)) {
                $existingTypeName = Get-RDMEntryTypeName -Entry $existing
                if ([string]::IsNullOrWhiteSpace($existingTypeName)) { $existingTypeName = 'Unknown' }

                $targetEntryType = Get-RDMDocumentationEntryType
                Write-Host "    └─ Legacy type '$existingTypeName' gedetecteerd -> opnieuw aanmaken als $targetEntryType" -ForegroundColor Yellow
                try {
                    Remove-RDMSession -Id $existing.ID -Force -ErrorAction Stop | Out-Null
                    Start-Sleep -Milliseconds 200
                    $existing = $null
                } catch {
                    Write-Warning "    └─ Kon legacy entry niet verwijderen: $($_.Exception.Message)"
                }
            }

            if (-not $existing) {
                $targetEntryType = Get-RDMDocumentationEntryType
                Write-Host "    └─ Entry wordt opnieuw aangemaakt met type $targetEntryType" -ForegroundColor DarkGray
            }

            if ($existing) {
            
            # STEP 1: Build inventory of existing attachments (to avoid re-adding them)
            try {
                $existingAtts = @(Get-RDMEntryAttachment -InputObject $existing -ErrorAction SilentlyContinue)
                
                # Build inventory of filenames that already exist
                # NOTE: RDM returns FileName as space-concatenated list of ALL paths in ONE object
                # We store the ATTACHMENT OBJECT so we can later use it for remove/replace operations
                $existingFileNames = @{}
                
                foreach ($att in $existingAtts) {
                    if ([string]::IsNullOrWhiteSpace($att.FileName)) { continue }
                    
                    # Split on drive letter pattern to get individual paths
                    $allPaths = $att.FileName -split '(?=[A-Z]:\\)' | Where-Object { $_ -match '^[A-Z]:\\' }
                    
                    foreach ($fullPath in $allPaths) {
                        if ([string]::IsNullOrWhiteSpace($fullPath)) { continue }
                        
                        $fname = Split-Path $fullPath.Trim() -Leaf
                        if (-not $existingFileNames.ContainsKey($fname)) {
                            $existingFileNames[$fname] = $att  # Store the attachment object, not $true!
                        }
                    }
                }
                
                Write-Host "    └─ Found $($existingFileNames.Count) existing attachment(s)" -ForegroundColor DarkGray
            } catch {
                Write-Warning "    └─ Error reading existing attachments: $($_.Exception.Message)"
                $existingFileNames = @{}
            }
            
            # STEP 2: Handle HTML attachment if UpdateHtmlIfExists is set
            if ($UpdateHtmlIfExists) {
                if ($ItemData.HTMLFilePath -and -not [string]::IsNullOrWhiteSpace($ItemData.HTMLFilePath)) {
                    if (Test-Path $ItemData.HTMLFilePath) {
                        try {
                            $htmlFileName = Split-Path $ItemData.HTMLFilePath -Leaf
                            $htmlExists = $existingFileNames.ContainsKey($htmlFileName)
                            
                            if ($htmlExists) {
                                # Replace existing HTML
                                Write-Host "    └─ Updating HTML attachment: $htmlFileName" -ForegroundColor Cyan
                                $oldHtml = $existingFileNames[$htmlFileName]
                                Remove-RDMEntryAttachment -InputObject $oldHtml -ErrorAction Stop | Out-Null
                                Add-RDMEntryAttachment -InputObject $existing -Filename $ItemData.HTMLFilePath -ErrorAction Stop | Out-Null
                                $sizeMB = [math]::Round(((Get-Item $ItemData.HTMLFilePath).Length / 1MB), 2)
                                Write-Host "    └─ ✓ HTML updated ($sizeMB MB)" -ForegroundColor Green
                            } else {
                                # Add missing HTML
                                Write-Host "    └─ Adding missing HTML attachment: $htmlFileName" -ForegroundColor Cyan
                                Add-RDMEntryAttachment -InputObject $existing -Filename $ItemData.HTMLFilePath -ErrorAction Stop | Out-Null
                                $sizeMB = [math]::Round(((Get-Item $ItemData.HTMLFilePath).Length / 1MB), 2)
                                Write-Host "    └─ ✓ HTML added ($sizeMB MB)" -ForegroundColor Green
                            }
                            
                            # Refresh inventory after HTML add/update (RDM restructures attachment objects)
                            $existingAtts = @(Get-RDMEntryAttachment -InputObject $existing -ErrorAction SilentlyContinue)
                            $existingFileNames.Clear()
                            foreach ($att in $existingAtts) {
                                if ([string]::IsNullOrWhiteSpace($att.FileName)) { continue }
                                $allPaths = $att.FileName -split '(?=[A-Z]:\\)' | Where-Object { $_ -match '^[A-Z]:\\' }
                                foreach ($fullPath in $allPaths) {
                                    if ([string]::IsNullOrWhiteSpace($fullPath)) { continue }
                                    $fname = Split-Path $fullPath.Trim() -Leaf
                                    if (-not $existingFileNames.ContainsKey($fname)) {
                                        $existingFileNames[$fname] = $att
                                    }
                                }
                            }
                            Write-Host "    └─ Refreshed inventory: $($existingFileNames.Count) attachment(s)" -ForegroundColor DarkGray
                            
                            # Add other attachments if not already present
                            $attachmentCount = 0
                            $attachmentPaths = @(Get-NormalizedAttachmentPaths -AttachmentPaths $ItemData.AttachmentPaths)
                            if ($attachmentPaths.Count -gt 0) {
                                foreach ($p in $attachmentPaths) {
                                    if (-not [string]::IsNullOrWhiteSpace($p) -and (Test-Path $p)) {
                                        $fname = Split-Path $p -Leaf
                                        if (-not $existingFileNames.ContainsKey($fname)) {
                                            try {
                                                Add-RDMEntryAttachment -InputObject $existing -Filename $p -ErrorAction Stop | Out-Null
                                                $attachmentCount++
                                            } catch {
                                                Write-AttachmentImportWarning -FilePath $p -ErrorMessage $_.Exception.Message -Prefix '    └─ '
                                            }
                                        }
                                    }
                                }
                                if ($attachmentCount -gt 0) {
                                    Write-Host "    └─ ✓ Added $attachmentCount other attachment(s)" -ForegroundColor Green
                                }
                            }

                            $script:LastInlineHtmlSuccess = $false
                            $docHtml = Build-DocumentationBodyHtml -ItemData $ItemData
                            $inlineHtmlOk = $script:LastInlineHtmlSuccess

                            Ensure-RDMExpectedAttachments -Entry $existing -ItemData $ItemData -Prefix '    ' -SkipHtmlAttachment:$inlineHtmlOk

                            try {
                                Set-RDMEntrySearchFields -Entry $existing -ItemData $ItemData
                                Set-RDMEntryEmbeddedViewMode -Entry $existing
                                Set-RDMEntry -InputObject $existing -Refresh -ErrorAction Stop | Out-Null
                                Write-Host "    └─ ✓ Search-index description updated" -ForegroundColor Green
                            } catch {
                                Write-Warning "    └─ Could not update search-index description: $($_.Exception.Message)"
                            }

                            try {
                                if (Set-RDMDocumentationBodyHtml -Entry $existing -HtmlBody $docHtml -PageName 'OneNote Import') {
                                    Write-Host "    └─ ✓ Documentation editor content updated" -ForegroundColor Green
                                } else {
                                    if ($FailFastOnDocMismatch) {
                                        throw "Documentation editor content inconsistent after update for '$($ItemData.SourcePage)'"
                                    }
                                    Write-Warning "    └─ Documentation editor content kon niet worden bijgewerkt"
                                }
                            } catch {
                                if ($FailFastOnDocMismatch) { throw }
                                Write-Warning "    └─ Could not update documentation editor content: $($_.Exception.Message)"
                            }
                            
                            $existing | Add-Member -MemberType NoteProperty -Name Tag -Value 'RDMEntryUpdated' -Force
                            return $existing
                            
                        } catch {
                            Write-Host "    └─ ⚠ Error updating HTML: $($_.Exception.Message)" -ForegroundColor Yellow
                            $existing | Add-Member -MemberType NoteProperty -Name Tag -Value 'RDMEntrySkipped' -Force
                            return $existing
                        }
                    } else {
                        # HTML file path specified but file not found
                        Write-Host "    └─ ⚠ HTML file NOT FOUND: $($ItemData.HTMLFilePath)" -ForegroundColor Red
                        Write-Host "    └─ This explains missing attachment!" -ForegroundColor Yellow
                        Write-Host "    └─ Checking if file exists with different casing..." -ForegroundColor Cyan
                        
                        $htmlDir = Split-Path $ItemData.HTMLFilePath -Parent
                        $htmlFileName = Split-Path $ItemData.HTMLFilePath -Leaf
                        
                        if ($htmlDir -and (Test-Path $htmlDir)) {
                            $foundFiles = Get-ChildItem -LiteralPath $htmlDir -Filter "*.html" -ErrorAction SilentlyContinue
                            Write-Host "    └─ HTML files found in directory ($($foundFiles.Count)):" -ForegroundColor Cyan
                            foreach ($f in $foundFiles) {
                                Write-Host "    └─   - $($f.Name)" -ForegroundColor Gray
                            }
                            
                            $foundExact = $foundFiles | Where-Object { $_.Name -eq $htmlFileName } | Select-Object -First 1
                            if ($foundExact) {
                                Write-Host "    └─ ✓ Found exact match: $($foundExact.FullName)" -ForegroundColor Green
                                try {
                                    $htmlExists = $existingFileNames.ContainsKey($foundExact.Name)
                                    if (-not $htmlExists) {
                                        Add-RDMEntryAttachment -InputObject $existing -Filename $foundExact.FullName -ErrorAction Stop | Out-Null
                                        $sizeMB = [math]::Round(($foundExact.Length / 1MB), 2)
                                        Write-Host "    └─ ✓ HTML added ($sizeMB MB)" -ForegroundColor Green
                                    } else {
                                        Write-Host "    └─ HTML already attached" -ForegroundColor DarkGray
                                    }
                                } catch {
                                    Write-AttachmentImportWarning -FilePath $foundExact.FullName -ErrorMessage $_.Exception.Message -Prefix '    └─ '
                                }
                            } else {
                                Write-Host "    └─ ✗ No matching HTML file found" -ForegroundColor Red
                            }
                        } else {
                            Write-Host "    └─ ✗ Directory not found: $htmlDir" -ForegroundColor Red
                        }
                    }
                } else {
                    Write-Host "    └─ No HTML file path specified in ItemData" -ForegroundColor DarkGray
                }
            }
            
            # Zorg altijd dat de display-modus op Embedded (tabbed) staat,
            # ook als er geen HTML-bestand beschikbaar is.
            if ($UpdateHtmlIfExists) {
                try {
                    Set-RDMEntryEmbeddedViewMode -Entry $existing
                    Set-RDMEntry -InputObject $existing -Refresh -ErrorAction Stop | Out-Null
                } catch {
                    Write-Warning "    └─ Kon display-modus niet instellen op Embedded: $($_.Exception.Message)"
                }
            }

            # If we reach here and SkipIfExists is set, skip
            if ($existing -and $SkipIfExists) {
                Write-Host "    └─ No changes needed (SkipIfExists)" -ForegroundColor DarkGray
                $existing | Add-Member -MemberType NoteProperty -Name Tag -Value 'RDMEntrySkipped' -Force
                return $existing
            }
            }
        }
    }

    $targetEntryType = Get-RDMDocumentationEntryType
    $entry = New-RDMEntry -Type $targetEntryType -Name $effectiveEntryName
    $entry.Group = $GroupPath

    # Searchable index fields
    Set-RDMEntrySearchFields -Entry $entry -ItemData $ItemData

    # Display: Embedded (tabbed) zodat dubbel-klikken inline opent ipv extern
    Set-RDMEntryEmbeddedViewMode -Entry $entry

    # Save entry
    $expectedGroup = $entry.Group
    $expectedName  = $effectiveEntryName

    try {
        $entry = Set-RDMEntry -InputObject $entry -Refresh -ErrorAction Stop
    } catch {
        $saveError = $_.Exception.Message
        $isNameConflict = $saveError -like "*already exists*" -or
                          $saveError -like "*bestaat al*"
        $isInvalidGroup = $saveError -match '(?i)(ongeldige groep|invalid group)'

        if ($isInvalidGroup) {
            $originalGroup = Normalize-RDMGroupPath -Path $entry.Group
            $candidateGroups = New-Object System.Collections.Generic.List[string]

            $collapsed = Get-RDMCollapsedDuplicatePath -Path $originalGroup
            if ($collapsed.Changed -and -not [string]::IsNullOrWhiteSpace($collapsed.Path)) {
                $candidateGroups.Add($collapsed.Path) | Out-Null
            }

            $resolvedFolder = Get-RDMFolderEntryByPath -FolderPath $originalGroup
            $resolvedPath = Get-RDMEntryFullPath -Entry $resolvedFolder -FallbackPath $originalGroup
            if (-not [string]::IsNullOrWhiteSpace($resolvedPath) -and $resolvedPath -ne $originalGroup) {
                $candidateGroups.Add($resolvedPath) | Out-Null
            }

            foreach ($candidate in @($candidateGroups | Select-Object -Unique)) {
                try {
                    Write-ImportLog "Ongeldige groep bij '$effectiveEntryName': retry met Group '$candidate' (origineel '$originalGroup')" 'WARN'
                    $entry.Group = $candidate
                    $expectedGroup = $candidate
                    $entry = Set-RDMEntry -InputObject $entry -Refresh -ErrorAction Stop
                    $isInvalidGroup = $false
                    break
                } catch {
                    Write-ImportLog "Retry met Group '$candidate' faalde: $($_.Exception.Message)" 'WARN'
                }
            }

            if ($isInvalidGroup) {
                # Laatste fallback: importeer in de root van de vault zodat de entry niet verloren gaat
                Write-ImportLog "Ongeldige groep voor '$effectiveEntryName' (origineel: '$originalGroup') - alle retries mislukt, importeer in vault-root als noodoplossing" 'WARN'
                Write-Host "    ⚠ '$effectiveEntryName' -> vault-root (groep '$originalGroup' ongeldig, handmatig verplaatsen)" -ForegroundColor Yellow
                try {
                    $entry.Group = ''
                    $expectedGroup = ''
                    $entry = Set-RDMEntry -InputObject $entry -Refresh -ErrorAction Stop
                    $isInvalidGroup = $false
                } catch {
                    throw
                }
            }
        }
        elseif ($isNameConflict) {
            # RDM weigert een entry met dezelfde naam als een bestaande map.
            # Hernoem de entry naar "<naam>_" en probeer opnieuw.
            $fallbackName = "${effectiveEntryName}_"
            Write-ImportLog "Naamconflict met bestaande map '$effectiveEntryName' - entry hernoemd naar '$fallbackName'" 'WARN'
            Write-Host "    ⚠ Naamconflict met map '$effectiveEntryName' -> hernoemd naar '$fallbackName'" -ForegroundColor Yellow
            $entry.Name = $fallbackName
            $expectedName = $fallbackName
            $entry = Set-RDMEntry -InputObject $entry -Refresh -ErrorAction Stop
        }
        else {
            throw
        }
    }

    # Re-fetch for attachments (ID can be missing in returned object)
    # Add retry logic with delay to ensure entry is fully committed
    Write-Verbose "Re-fetching entry after creation to ensure it's fully committed..."
    Start-Sleep -Milliseconds 250
    
    for ($retry = 0; $retry -lt 5; $retry++) {
        if ($retry -gt 0) {
            Start-Sleep -Milliseconds (250 * $retry)
        }

        $entry = Get-RDMEntry | Where-Object {
            $_.Name -eq $expectedName -and
            $_.Group -eq $expectedGroup -and
            -not (Test-IsGroupEntry -Entry $_)
        } | Select-Object -First 1

        if ($entry -and $entry.ID) { break }
    }
    
    if (-not $entry -or -not $entry.ID) {
        throw "Entry created but not retrievable (Name: $expectedName, Group: $expectedGroup)"
    }

    Write-Verbose "Entry confirmed with ID: $($entry.ID)"


    Write-Host "    Created entry: $($ItemData.SourcePage)" -ForegroundColor DarkGray

    # Build documentation HTML early (sets $script:LastInlineHtmlSuccess) but set it last,
    # because adding attachments can reset documentation content on Document-type entries.
    $script:LastInlineHtmlSuccess = $false
    $docHtml = Build-DocumentationBodyHtml -ItemData $ItemData
    $inlineHtmlOk = $script:LastInlineHtmlSuccess

    # Attach HTML only when inline view failed (otherwise documentation already contains full content)
    if ($ItemData.HTMLFilePath -and -not [string]::IsNullOrWhiteSpace($ItemData.HTMLFilePath) -and (Test-Path $ItemData.HTMLFilePath)) {
        if (-not $inlineHtmlOk) {
            try {
                Add-RDMEntryAttachment -InputObject $entry -Filename $ItemData.HTMLFilePath -ErrorAction Stop | Out-Null
                $sizeMB = [math]::Round(((Get-Item $ItemData.HTMLFilePath).Length / 1MB), 2)
                Write-Host "    ✓ Attached HTML file ($sizeMB MB) - inline view niet beschikbaar" -ForegroundColor DarkGray
            } catch {
                Write-AttachmentImportWarning -FilePath $ItemData.HTMLFilePath -ErrorMessage $_.Exception.Message -Prefix '    '
            }
        } else {
            Write-Host "    ℹ HTML-attachment overgeslagen (inline documentation actief)" -ForegroundColor DarkGray
        }
    }

    # Attach loose image/file attachments, compressed to max 1200px where applicable
    $attachmentCount = 0

    $attachmentPaths = @(Get-NormalizedAttachmentPaths -AttachmentPaths $ItemData.AttachmentPaths)
    if ($attachmentPaths.Count -gt 0) {
        try { Add-Type -AssemblyName System.Drawing -ErrorAction Stop } catch {}

        foreach ($p in $attachmentPaths) {
            if ([string]::IsNullOrWhiteSpace($p) -or -not (Test-Path $p)) { continue }

            $ext = [System.IO.Path]::GetExtension($p).ToLower()
            $isImage = $ext -in @('.jpg', '.jpeg', '.png', '.bmp', '.gif', '.tiff', '.tif')

            if ($isImage -and ([System.Management.Automation.PSTypeName]'System.Drawing.Image').Type) {
                try {
                    $imgBytes = [System.IO.File]::ReadAllBytes($p)
                    $ms = New-Object System.IO.MemoryStream($imgBytes, 0, $imgBytes.Length)
                    $original = [System.Drawing.Image]::FromStream($ms, $true)

                    if ($original.Width -gt 1200) {
                        $originalSize = (Get-Item -LiteralPath $p).Length
                        $newWidth  = 1200
                        $newHeight = [int]($original.Height * (1200 / $original.Width))
                        $bmp       = New-Object System.Drawing.Bitmap($newWidth, $newHeight)
                        $gfx       = [System.Drawing.Graphics]::FromImage($bmp)
                        $gfx.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
                        $gfx.DrawImage($original, 0, 0, $newWidth, $newHeight)

                        $tempPath = "$p.__scaledtmp"
                        if (Test-Path -LiteralPath $tempPath) {
                            Remove-Item -LiteralPath $tempPath -Force -ErrorAction SilentlyContinue
                        }

                        if ($ext -in @('.jpg', '.jpeg')) {
                            $jpegCodec = [System.Drawing.Imaging.ImageCodecInfo]::GetImageEncoders() |
                                         Where-Object { $_.MimeType -eq 'image/jpeg' }
                            $encParams = New-Object System.Drawing.Imaging.EncoderParameters(1)
                            $encParams.Param[0] = New-Object System.Drawing.Imaging.EncoderParameter(
                                [System.Drawing.Imaging.Encoder]::Quality, [long]80)
                            $bmp.Save($tempPath, $jpegCodec, $encParams)
                            $encParams.Dispose()
                        } else {
                            $targetFormat = switch ($ext) {
                                '.png'  { [System.Drawing.Imaging.ImageFormat]::Png; break }
                                '.gif'  { [System.Drawing.Imaging.ImageFormat]::Gif; break }
                                '.bmp'  { [System.Drawing.Imaging.ImageFormat]::Bmp; break }
                                '.tif'  { [System.Drawing.Imaging.ImageFormat]::Tiff; break }
                                '.tiff' { [System.Drawing.Imaging.ImageFormat]::Tiff; break }
                                default { [System.Drawing.Imaging.ImageFormat]::Jpeg }
                            }
                            $bmp.Save($tempPath, $targetFormat)
                        }

                        $newSize = (Get-Item -LiteralPath $tempPath).Length
                        if ($newSize -lt $originalSize) {
                            Move-Item -LiteralPath $tempPath -Destination $p -Force
                            Write-Host "    ✓ Afbeelding geschaald op schijf: $(Split-Path $p -Leaf) ($([math]::Round($originalSize / 1KB,1)) KB -> $([math]::Round($newSize / 1KB,1)) KB)" -ForegroundColor DarkGray
                        } else {
                            Remove-Item -LiteralPath $tempPath -Force -ErrorAction SilentlyContinue
                            Write-Host "    ℹ Schalen overgeslagen (zou groter worden): $(Split-Path $p -Leaf)" -ForegroundColor DarkGray
                        }

                        $gfx.Dispose(); $bmp.Dispose(); $original.Dispose(); $ms.Dispose()
                    } else {
                        $original.Dispose(); $ms.Dispose()
                    }
                } catch {
                    Write-Verbose "Kon afbeelding niet schalen: $(Split-Path $p -Leaf) - $($_.Exception.Message)"
                }
            }

            try {
                Add-RDMEntryAttachment -InputObject $entry -Filename $p -ErrorAction Stop | Out-Null
                $attachmentCount++
            } catch {
                Write-AttachmentImportWarning -FilePath $p -ErrorMessage $_.Exception.Message -Prefix '    '
            }
        }
    }

    if ($attachmentCount -gt 0) {
        Write-Host "    ✓ Attached $attachmentCount additional file(s)" -ForegroundColor DarkGray
    }

    Ensure-RDMExpectedAttachments -Entry $entry -ItemData $ItemData -Prefix '    ' -SkipHtmlAttachment:$inlineHtmlOk

    # Set documentation as final step (attachments can reset docs on Document entries)
    $docSetOk = $false
    $docSetError = $null
    for ($docAttempt = 1; $docAttempt -le 4; $docAttempt++) {
        try {
            $freshEntry = Get-RDMEntry | Where-Object { [string]$_.ID -eq [string]$entry.ID } | Select-Object -First 1
            if (-not $freshEntry) { $freshEntry = $entry }

            if (Set-RDMDocumentationBodyHtml -Entry $freshEntry -HtmlBody $docHtml -PageName 'OneNote Import') {
                $entry = $freshEntry
                $docSetOk = $true
                break
            }
        } catch {
            $docSetError = $_.Exception.Message
        }

        if ($docAttempt -lt 4) {
            Start-Sleep -Milliseconds (400 * $docAttempt)
        }
    }

    if ($docSetOk) {
        Write-Host "    ✓ Documentation editor content set" -ForegroundColor DarkGray
    } else {
        if ($FailFastOnDocMismatch) {
            if (-not [string]::IsNullOrWhiteSpace($docSetError)) {
                throw "Documentation editor content inconsistent after create for '$($ItemData.SourcePage)': $docSetError"
            }
            throw "Documentation editor content inconsistent after create for '$($ItemData.SourcePage)'"
        }
        Write-Warning "    ⚠ Documentation editor content kon niet gezet worden"
    }

    # Tag as newly created
    $entry | Add-Member -MemberType NoteProperty -Name Tag -Value 'RDMEntryCreatedJustNow' -Force

    return $entry
}

# -------------------------
# Optional: Generic attachment helper (no New-RDMAttachment)
# (kept for backwards compatibility; not required for GeneralComments pages)
# -------------------------
function Add-GenericAttachmentToEntry {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][object]$Entry,
        [Parameter(Mandatory)][array]$Attachments
    )

    foreach ($a in $Attachments) {
        if ($a.FilePath -and -not [string]::IsNullOrWhiteSpace($a.FilePath) -and (Test-Path $a.FilePath)) {
            try {
                Add-RDMEntryAttachment -InputObject $Entry -Filename $a.FilePath -ErrorAction Stop | Out-Null
            } catch {
                Write-AttachmentImportWarning -FilePath $a.FilePath -ErrorMessage $_.Exception.Message -Prefix '      '
            }
        }
    }
}

# -------------------------
# MAIN IMPORT
# -------------------------
function Import-DataToRDM {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][object]$Data,
        [Parameter(Mandatory)][string]$DataSourceName,
        [Parameter(Mandatory)][string]$VaultName,
        [string]$UserGroupName,
        [switch]$UpdateHtmlIfExists,
        [string]$OnlySourcePage,
        [int]$MaxItems = 0,
        [switch]$RunDuplicateSweepEachItem,
        [bool]$FailFastOnDocMismatch = $false
    )

    Write-Host "`nStarting RDM import..." -ForegroundColor Cyan
    $vault = Connect-ToRDMDataSource -DataSourceName $DataSourceName -VaultName $VaultName -CreateIfMissing

    $importStats = @{
        ImportedCount = 0
        SkippedCount  = 0
        UpdatedCount  = 0
        FailedCount   = 0
        ByCategory    = @{}
        FailedItems   = New-Object System.Collections.Generic.List[object]
    }
    $rawItems = $null
    if ($Data -and ($Data.PSObject.Properties.Name -contains 'CategorizedItems')) {
        $rawItems = $Data.CategorizedItems
    } else {
        $rawItems = $Data
    }

    $itemsToProcess = New-Object System.Collections.Generic.List[object]

    if ($rawItems -is [System.Collections.IDictionary]) {
        foreach ($key in $rawItems.Keys) {
            $value = $rawItems[$key]
            if ($value -is [System.Collections.IEnumerable] -and -not ($value -is [string])) {
                foreach ($entry in $value) {
                    if ($null -ne $entry) { [void]$itemsToProcess.Add($entry) }
                }
            } elseif ($null -ne $value) {
                [void]$itemsToProcess.Add($value)
            }
        }
    }
    elseif ($rawItems -is [System.Collections.IEnumerable] -and -not ($rawItems -is [string])) {
        foreach ($entry in $rawItems) {
            if ($null -ne $entry) { [void]$itemsToProcess.Add($entry) }
        }
    }
    elseif ($null -ne $rawItems) {
        [void]$itemsToProcess.Add($rawItems)
    }

    if (-not [string]::IsNullOrWhiteSpace($OnlySourcePage)) {
        $itemsToProcess = @(
            $itemsToProcess | Where-Object {
                $_ -and
                ($_.PSObject.Properties.Name -contains 'SourcePage') -and
                ([string]$_.SourcePage -eq $OnlySourcePage)
            }
        )
        Write-Host "Filter: OnlySourcePage='$OnlySourcePage' -> $($itemsToProcess.Count) item(s)" -ForegroundColor Yellow
    }

    if ($MaxItems -gt 0 -and $itemsToProcess.Count -gt $MaxItems) {
        $itemsToProcess = @($itemsToProcess | Select-Object -First $MaxItems)
        Write-Host "Filter: MaxItems=$MaxItems" -ForegroundColor Yellow
    }

    if ($RunDuplicateSweepEachItem) {
        Write-Host "Mode: Per-item duplicate sweep enabled (troubleshooting)" -ForegroundColor Yellow
    }
    if ($FailFastOnDocMismatch) {
        Write-Host "Mode: Fail-fast on documentation mismatch enabled" -ForegroundColor Yellow
    }

    $totalItems = $itemsToProcess.Count
    if ($totalItems -eq 0) {
        Write-Warning "No items to process after filters."
        return $importStats
    }

    $i = 0
    
    if ($UpdateHtmlIfExists) {
        Write-Host "Mode: Update HTML attachments for existing entries" -ForegroundColor Cyan
    } else {
        Write-Host "Mode: Skip existing entries (idempotent import)" -ForegroundColor Cyan
    }
    Write-Host ""

    foreach ($item in $itemsToProcess) {
        $i++
        Write-Host "  Importing item $i/$totalItems : $($item.SourcePage) ($($item.Category))" -ForegroundColor Gray
        Write-ImportLog "[$i/$totalItems] Start: $($item.SourcePage) [$($item.Category)]"

        try {
            # Resolve group path:
            # If analyzer provided TargetFolder => use it (preserves OneNote hierarchy)
            $groupPath = $null

            if ($item.TargetFolder) {
                $groupPath = Get-RDMTargetFolderByName -FolderPath ([string]$item.TargetFolder)
            }
            else {
                # Fallback: if no TargetFolder, put in category root folder (requires config loaded in wrapper)
                $categoryConfig = $null
                if ($script:UserConfig -and $script:UserConfig.CategoryMappings) {
                    if ($script:UserConfig.CategoryMappings -is [hashtable]) {
                        $categoryConfig = $script:UserConfig.CategoryMappings[$item.Category]
                    }
                    elseif ($script:UserConfig.CategoryMappings.PSObject.Properties[$item.Category]) {
                        $categoryConfig = $script:UserConfig.CategoryMappings.$($item.Category)
                    }
                }
                if (-not $categoryConfig) {
                    Write-Warning "  Unknown category and no TargetFolder: $($item.Category) -> skipping"
                Write-ImportLog "[$i/$totalItems] OVERGESLAGEN: $($item.SourcePage) - onbekende categorie '$($item.Category)'" 'WARN'
                    $importStats.FailedCount++
                    $importStats.FailedItems.Add([pscustomobject]@{
                        SourcePage   = [string]$item.SourcePage
                        TargetFolder = [string]$item.TargetFolder
                        Category     = [string]$item.Category
                        Error        = "Unknown category and no TargetFolder"
                    }) | Out-Null
                    continue
                }
                $groupPath = Get-RDMTargetFolderByName -FolderPath $categoryConfig.RDMFolder
            }

            if (-not $groupPath) { throw "No target folder path resolved." }

            # Check if page has children -> create folder with attachments instead of document entry
            if ($item.HasChildren) {
                Write-Host "    Page has children -> creating folder with attachments + documentation entry" -ForegroundColor Gray
                Write-Host "    DEBUG: About to call Add-AttachmentsToFolder" -ForegroundColor Magenta
                Write-Host "      FolderPath: [$groupPath]" -ForegroundColor Magenta
                Write-Host "      FolderName: [$($item.SourcePage)]" -ForegroundColor Magenta
                Write-Host "      HTMLFilePath: [$($item.HTMLFilePath)]" -ForegroundColor Magenta
                $debugAttachmentPaths = @(Get-NormalizedAttachmentPaths -AttachmentPaths $item.AttachmentPaths)
                Write-Host "      AttachmentPaths count: $($debugAttachmentPaths.Count)" -ForegroundColor Magenta
                if ($debugAttachmentPaths.Count -gt 0) {
                    for ($idx = 0; $idx -lt $debugAttachmentPaths.Count; $idx++) {
                        Write-Host "        [$idx]: [$($debugAttachmentPaths[$idx])]" -ForegroundColor Magenta
                    }
                }
                $folderResult = Add-AttachmentsToFolder -FolderPath $groupPath -FolderName $item.SourcePage -ItemData $item -UpdateIfExists:$UpdateHtmlIfExists
                $fallbackDocGroupPath = if ([string]::IsNullOrWhiteSpace($groupPath)) { $item.SourcePage } else { "$groupPath\$($item.SourcePage)" }
                $docGroupPath = Get-RDMEntryFullPath -Entry $folderResult.Entry -FallbackPath $fallbackDocGroupPath
                $docResult = New-RDMDocumentationEntry -ItemData $item -GroupPath $docGroupPath -EntryName 'Documentation' -SkipIfExists:(-not $UpdateHtmlIfExists) -UpdateHtmlIfExists:$UpdateHtmlIfExists -FailFastOnDocMismatch:$FailFastOnDocMismatch
                if ($docResult) {
                    $result = $docResult
                } else {
                    $result = $folderResult
                }
                $resultTag = $result.Tag
            } else {
                # Create as documentation entry (or update existing if UpdateHtmlIfExists)
                $result = New-RDMDocumentationEntry -ItemData $item -GroupPath $groupPath -SkipIfExists:(-not $UpdateHtmlIfExists) -UpdateHtmlIfExists:$UpdateHtmlIfExists -FailFastOnDocMismatch:$FailFastOnDocMismatch
                $resultTag = $result.Tag
            }
            
            # Check if this was a new entry, updated entry, or skipped
            if ($result -and ($resultTag -eq 'RDMEntryCreatedJustNow' -or $resultTag -eq 'Created')) {
                # New entry created
                $importStats.ImportedCount++
                if (-not $importStats.ByCategory.ContainsKey($item.Category)) { $importStats.ByCategory[$item.Category] = 0 }
                $importStats.ByCategory[$item.Category]++
                Write-Host "    Imported successfully" -ForegroundColor Green
                Write-ImportLog "[$i/$totalItems] GEIMPORTEERD: $($item.SourcePage) -> $($item.TargetFolder)" 'SUCCESS'
            } elseif ($result -and ($resultTag -eq 'RDMEntryUpdated' -or $resultTag -eq 'Updated')) {
                # Existing entry updated
                $importStats.UpdatedCount++
                if (-not $importStats.ByCategory.ContainsKey($item.Category)) { $importStats.ByCategory[$item.Category] = 0 }
                Write-Host "    Updated successfully" -ForegroundColor Green
                Write-ImportLog "[$i/$totalItems] BIJGEWERKT: $($item.SourcePage)" 'SUCCESS'
            } elseif ($result -and ($resultTag -eq 'RDMEntrySkipped' -or $resultTag -eq 'Skipped')) {
                # Existing entry skipped
                $importStats.SkippedCount++
                if (-not $importStats.ByCategory.ContainsKey($item.Category)) { $importStats.ByCategory[$item.Category] = 0 }
                # Message already shown by New-RDMDocumentationEntry
            } else {
                # Something went wrong but didn't throw
                $importStats.FailedCount++
                $importStats.FailedItems.Add([pscustomobject]@{
                    SourcePage   = [string]$item.SourcePage
                    TargetFolder = [string]$item.TargetFolder
                    Category     = [string]$item.Category
                    Error        = "No entry returned"
                }) | Out-Null
                Write-Host "    Failed (no entry returned)" -ForegroundColor Red
                Write-ImportLog "[$i/$totalItems] GEEN ENTRY TERUGGEGEVEN: $($item.SourcePage)" 'WARN'
            }

            if ($RunDuplicateSweepEachItem -and -not [string]::IsNullOrWhiteSpace($groupPath)) {
                $removedNow = Invoke-RDMDuplicateConsistencySweepForEntry -Name $item.SourcePage -GroupPath $groupPath -LogPrefix '    '
                if ($removedNow -gt 0) {
                    Write-Host "    Duplicate cleanup (direct): removed $removedNow" -ForegroundColor Yellow
                }
            }
        }
        catch {
            Write-Host "    Failed to import: $($_.Exception.Message)" -ForegroundColor Red
            Write-ImportLog "[$i/$totalItems] DEBUG CONTEXT: SourcePage='$($item.SourcePage)' | Category='$($item.Category)' | TargetFolder='$($item.TargetFolder)' | HasChildren='$($item.HasChildren)' | GroupPath='$($groupPath)'" 'WARN'
            Write-ImportLog "[$i/$totalItems] MISLUKT: $($item.SourcePage) | $($_.Exception.Message)" 'ERROR'
            $importStats.FailedCount++
            $importStats.FailedItems.Add([pscustomobject]@{
                SourcePage   = [string]$item.SourcePage
                TargetFolder = [string]$item.TargetFolder
                Category     = [string]$item.Category
                Error        = [string]$_.Exception.Message
            }) | Out-Null
        }
    }

    $duplicateSweep = Invoke-RDMDuplicateConsistencySweep

    try { Update-RDMUI | Out-Null } catch {}

    Write-Host "`nRDM Import complete!" -ForegroundColor Green
    Write-Host "  Total imported (new): $($importStats.ImportedCount)" -ForegroundColor White
    if ($importStats.UpdatedCount -gt 0) {
        Write-Host "  Updated (HTML refresh): $($importStats.UpdatedCount)" -ForegroundColor Yellow
    }
    Write-Host "  Skipped (already exist): $($importStats.SkippedCount)" -ForegroundColor Cyan
    Write-Host "  Failed: $($importStats.FailedCount)" -ForegroundColor $(if ($importStats.FailedCount -gt 0) { 'Yellow' } else { 'White' })
    if ($duplicateSweep.RemovedEntries -gt 0) {
        Write-Host "  Duplicate cleanup removed: $($duplicateSweep.RemovedEntries)" -ForegroundColor Yellow
    }

    Write-Host "`n  By category:" -ForegroundColor White
    foreach ($k in $importStats.ByCategory.Keys) {
Write-Host "    - ${k}: $($importStats.ByCategory[$k])" -ForegroundColor Cyan    }

    return $importStats
}

# Note: This script is dot-sourced; Import-DataToRDM becomes available in caller scope.












