Runtime package for Bulk-Import-Client-ToRDM2.ps1

Included files:
- Bulk-Import-Client-ToRDM2.ps1
- Import-ToRDM2.ps1
- Analyze-Hydrex-Full.ps1
- migration-config.json

External prerequisites (not included in zip):
- Remote Desktop Manager + Devolutions.PowerShell module
- PowerShell with System.Windows.Forms support

Run from this folder:
  .\Bulk-Import-Client-ToRDM2.ps1
