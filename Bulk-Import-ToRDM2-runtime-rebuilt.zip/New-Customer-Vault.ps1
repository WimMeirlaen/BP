# Module requirement: Devolutions.PowerShell (automatically checked and installed)
<#
.SYNOPSIS
Create a new customer vault and populate it with the 'New Customer' template.

.DESCRIPTION
This script creates a new vault in Remote Desktop Manager and populates it with
the standard E.S.C. customer template structure from the 'New Customer' vault.

IMPORTANT PREREQUISITES:
1. Remote Desktop Manager (RDM) must be running
2. You must be logged in to your datasource in RDM
3. The datasource connection must be active (you should see vaults in RDM)

If the script fails with "Your connection is not ready" errors:
- Close all PowerShell windows
- Restart Remote Desktop Manager
- Log in to your datasource and wait for all vaults to load
- Open a NEW PowerShell window
- Run this script again

.DESCRIPTION
This script is intended to be run by RDM users. It prompts for a new customer name,
creates a new repository (Vault), and imports the standard template structure.

.NOTES
Version: 1.0.0
Author: Autoscaled via Agent
#>

[CmdletBinding(ConfirmImpact = 'Low')]
param(
    [Parameter(Mandatory = $true, HelpMessage = "Naam van de nieuwe klant")]
    [string]$NewCustomerName,

    [Parameter(Mandatory = $false, HelpMessage = "Naam van de RDM data source (optioneel, wordt interactief gevraagd indien niet opgegeven)")]
    [string]$DataSourceName,

    [string]$UserGroupName = 'Klanten - admin'

)

$ErrorActionPreference = 'Stop'

# --- PowerShell Version Check ---
function Test-PowerShell75Installed {
    # Check if we're running PowerShell 7.5+
    if ($PSVersionTable.PSVersion.Major -ge 7 -and $PSVersionTable.PSVersion.Minor -ge 5) {
        return $true
    }
    
    # Check if pwsh.exe with version 7.5+ exists
    try {
        $pwshPath = (Get-Command pwsh.exe -ErrorAction SilentlyContinue).Source
        if ($pwshPath) {
            $versionOutput = & $pwshPath -NoProfile -Command '$PSVersionTable.PSVersion.ToString()'
            if ($versionOutput -match '^(\d+)\.(\d+)') {
                $major = [int]$Matches[1]
                $minor = [int]$Matches[2]
                if ($major -ge 7 -and ($major -gt 7 -or $minor -ge 5)) {
                    return $true
                }
            }
        }
    }
    catch {
        # Ignore errors
    }
    
    return $false
}

function Install-PowerShell75 {
    Write-Host "PowerShell 7.5 of hoger is niet geïnstalleerd." -ForegroundColor Yellow
    Write-Host "Installatie van PowerShell 7.5 wordt gestart..." -ForegroundColor Cyan
    
    # Check if winget is available
    try {
        $null = Get-Command winget.exe -ErrorAction Stop
    }
    catch {
        Write-Error "winget is niet beschikbaar. Installeer PowerShell 7.5 handmatig via https://aka.ms/powershell-release?tag=stable"
        throw "winget niet gevonden"
    }
    
    # Install PowerShell 7.5 using winget
    try {
        Write-Host "Installeren via winget..." -ForegroundColor Gray
        $process = Start-Process -FilePath "winget.exe" -ArgumentList "install --id Microsoft.PowerShell --source winget --silent --accept-package-agreements --accept-source-agreements" -Wait -PassThru -NoNewWindow
        
        if ($process.ExitCode -ne 0) {
            throw "winget installatie mislukt met exit code: $($process.ExitCode)"
        }
        
        Write-Host "PowerShell 7.5 is succesvol geïnstalleerd!" -ForegroundColor Green
        Write-Host "Het script moet opnieuw worden uitgevoerd in PowerShell 7.5..." -ForegroundColor Yellow
        
        # Restart script in pwsh
        $pwshPath = "C:\Program Files\PowerShell\7\pwsh.exe"
        if (-not (Test-Path $pwshPath)) {
            # Try alternative location
            $pwshPath = "${env:ProgramFiles}\PowerShell\7\pwsh.exe"
            if (-not (Test-Path $pwshPath)) {
                Write-Warning "PowerShell 7 is geïnstalleerd maar pwsh.exe kon niet worden gevonden op de verwachte locatie."
                Write-Host "Start PowerShell 7 handmatig en voer dit script opnieuw uit."
                return $false
            }
        }
        
        # Build argument list to restart script
        $scriptPath = $MyInvocation.PSCommandPath
        $arguments = "-NoProfile -File `"$scriptPath`""
        
        # Add all bound parameters
        foreach ($key in $PSBoundParameters.Keys) {
            $value = $PSBoundParameters[$key]
            $arguments += " -$key `"$value`""
        }
        
        Write-Host "Script wordt herstart in PowerShell 7.5..." -ForegroundColor Cyan
        Start-Process -FilePath $pwshPath -ArgumentList $arguments -NoNewWindow
        
        # Exit current session
        exit 0
    }
    catch {
        Write-Error "Fout bij installeren van PowerShell 7.5: $($_.Exception.Message)"
        Write-Host "Installeer PowerShell 7.5 handmatig via https://aka.ms/powershell-release?tag=stable" -ForegroundColor Yellow
        throw
    }
}

# Check and install PowerShell 7.5 if needed
if (-not (Test-PowerShell75Installed)) {
    Install-PowerShell75
    # Script will exit if successful, otherwise error is thrown
}
else {
    Write-Host "PowerShell $($PSVersionTable.PSVersion) gedetecteerd - OK" -ForegroundColor Green
}

# --- Devolutions.PowerShell Module Check ---
function Test-DevolutionsModuleInstalled {
    # Check if the module is already loaded
    $loadedModule = Get-Module -Name Devolutions.PowerShell -ErrorAction SilentlyContinue
    if ($loadedModule) {
        return $true
    }
    
    # Check if the module is available to import
    $availableModule = Get-Module -ListAvailable -Name Devolutions.PowerShell -ErrorAction SilentlyContinue
    if ($availableModule) {
        return $true
    }
    
    return $false
}

function Install-DevolutionsModule {
    Write-Host "Devolutions.PowerShell module is niet geïnstalleerd." -ForegroundColor Yellow
    Write-Host "Installatie van Devolutions.PowerShell module wordt gestart..." -ForegroundColor Cyan
    
    try {
        # Check if running as administrator
        $isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
        
        if ($isAdmin) {
            # Install for all users
            Write-Host "Installeren voor alle gebruikers..." -ForegroundColor Gray
            Install-Module -Name Devolutions.PowerShell -Repository PSGallery -Force -AllowClobber -Scope AllUsers -ErrorAction Stop
        }
        else {
            # Install for current user only
            Write-Host "Installeren voor huidige gebruiker (geen admin rechten)..." -ForegroundColor Gray
            Install-Module -Name Devolutions.PowerShell -Repository PSGallery -Force -AllowClobber -Scope CurrentUser -ErrorAction Stop
        }
        
        Write-Host "Devolutions.PowerShell module is succesvol geïnstalleerd!" -ForegroundColor Green
        return $true
    }
    catch {
        Write-Error "Fout bij installeren van Devolutions.PowerShell module: $($_.Exception.Message)"
        Write-Host "Installeer de module handmatig met: Install-Module -Name Devolutions.PowerShell" -ForegroundColor Yellow
        throw
    }
}

function Import-DevolutionsModule {
    Write-Host "Laden van Devolutions.PowerShell module..." -ForegroundColor Gray

    try {
        # Use -Force to ensure clean state (exactly like manual command)
        Import-Module -Name Devolutions.PowerShell -Force -ErrorAction Stop
        Write-Host "Devolutions.PowerShell module succesvol geladen." -ForegroundColor Green
        return $true
    }
    catch {
        Write-Error "Fout bij laden van Devolutions.PowerShell module: $($_.Exception.Message)"
        throw
    }
}

# Check and install Devolutions.PowerShell module if needed
if (-not (Test-DevolutionsModuleInstalled)) {
    Install-DevolutionsModule
}

# Import the module
Import-DevolutionsModule

# --- Check if RDM is running ---
Write-Host "Controleren of Remote Desktop Manager actief is..." -ForegroundColor Gray
$rdmProcess = Get-Process -Name "RemoteDesktopManager64" -ErrorAction SilentlyContinue
if (-not $rdmProcess) {
    $rdmProcess = Get-Process -Name "RemoteDesktopManager" -ErrorAction SilentlyContinue
}

if (-not $rdmProcess) {
    Write-Host "`nWAARSCHUWING: Remote Desktop Manager lijkt niet actief te zijn!" -ForegroundColor Red
    Write-Host "Het PowerShell script vereist dat RDM is gestart en ingelogd." -ForegroundColor Yellow
    Write-Host "`nVereiste stappen:" -ForegroundColor Yellow
    Write-Host "  1. Start Remote Desktop Manager" -ForegroundColor White
    Write-Host "  2. Log in en open een van uw datasources" -ForegroundColor White
    Write-Host "  3. Laat RDM open op de achtergrond" -ForegroundColor White
    Write-Host "  4. Voer dit script opnieuw uit" -ForegroundColor White
    throw "RDM is niet actief. Start eerst RDM voordat u dit script uitvoert."
} else {
    Write-Host "  RDM proces gevonden (PID: $($rdmProcess.Id))" -ForegroundColor Green
}

# --- Constants ---
$TemplateVaultName = 'New Customer'
$UserGroupName = 'Klanten - admin'
$DeleteTempFile = $true

# --- Data Source Selection ---
function Select-RDMDataSource {
    <#
    .SYNOPSIS
    Interactively selects an RDM data source from available options.
    #>
    param()

    Write-Host "`n=== RDM Data Source Selectie ===" -ForegroundColor Cyan
    Write-Host "Ophalen van beschikbare data sources..." -ForegroundColor Gray

    try {
        $dataSources = Get-RDMDataSource -ErrorAction Stop

        if (-not $dataSources) {
            throw "Geen RDM data sources gevonden. Zorg ervoor dat RDM is geconfigureerd."
        }

        # Convert to array if single object
        if ($dataSources -isnot [array]) {
            $dataSources = @($dataSources)
        }

        Write-Host "`nBeschikbare data sources:" -ForegroundColor Cyan
        Write-Host ""

        for ($i = 0; $i -lt $dataSources.Count; $i++) {
            $ds = $dataSources[$i]
            Write-Host "  [$($i + 1)] $($ds.Name)" -ForegroundColor White
        }

        Write-Host ""

        # Get user selection
        do {
            $selection = Read-Host "Selecteer een data source (1-$($dataSources.Count))"

            if ($selection -match '^\d+$') {
                $index = [int]$selection - 1
                if ($index -ge 0 -and $index -lt $dataSources.Count) {
                    $selectedDataSource = $dataSources[$index].Name
                    Write-Host "`nGeselecteerd: $selectedDataSource" -ForegroundColor Green
                    return $selectedDataSource
                }
            }

            Write-Host "Ongeldige selectie. Kies een nummer tussen 1 en $($dataSources.Count)." -ForegroundColor Yellow

        } while ($true)
    }
    catch {
        Write-Error "Fout bij ophalen van data sources: $($_.Exception.Message)"
        throw
    }
}

# --- Helper Functions (Reused for robustness) ---

function Test-RDMConnection {
    <#
    .SYNOPSIS
    Verifies that RDM is running and ready for operations.
    #>
    param([string]$DataSourceName)

    Write-Host "Controleren van RDM verbinding..." -ForegroundColor Gray

    try {
        # Test if we can get datasources (this will trigger auth if needed)
        $allDataSources = Get-RDMDataSource -ErrorAction Stop

        if (-not $allDataSources) {
            throw "Geen datasources gevonden. Start RDM en configureer een datasource."
        }

        # Find the specific datasource
        $ds = $allDataSources | Where-Object { $_.Name -eq $DataSourceName } | Select-Object -First 1

        if (-not $ds) {
            throw "Datasource '$DataSourceName' niet gevonden."
        }

        # Try to set it as current (this may trigger authentication popup)
        Write-Host "Verbinden met datasource '$DataSourceName'..." -ForegroundColor Gray
        Set-RDMCurrentDataSource -DataSource $ds -ErrorAction Stop | Out-Null

        # Give time for authentication popup if needed
        Start-Sleep -Milliseconds 1000

        # Try to get repositories to verify connection works
        try {
            $null = Get-RDMRepository -ErrorAction Stop
            Write-Host "Verbinding met RDM succesvol." -ForegroundColor Green
            return $true
        }
        catch {
            Write-Warning "Kon geen repositories ophalen. Mogelijk is authenticatie vereist."
            Write-Host "Probeer opnieuw nadat u bent ingelogd..." -ForegroundColor Yellow
            Start-Sleep -Seconds 3

            # Try one more time
            $null = Get-RDMRepository -ErrorAction Stop
            return $true
        }
    }
    catch {
        Write-Host "Fout bij verbinden met RDM: $($_.Exception.Message)" -ForegroundColor Red
        throw
    }
}

function Use-Repo([string]$dsName, [string]$repoName) {
    Write-Host "Verbinden met vault '$repoName'..." -ForegroundColor Gray

    # 1. Get datasource (should already be active from stabilization)
    $ds = Get-RDMDataSource -Name $dsName
    if (-not $ds) { throw "Datasource '$dsName' niet gevonden." }

    # 2. Find Repository - SIMPLIFIED: just get it once, no retry loop
    $repo = Get-RDMRepository | Where-Object { $_.Name -eq $repoName } | Select-Object -First 1

    if (-not $repo) {
        throw "Vault '$repoName' niet gevonden in '$dsName'."
    }

    # 3. Set Active
    Set-RDMCurrentRepository -Repository $repo | Out-Null

    # 4. Short wait for vault to be ready
    Start-Sleep -Milliseconds 500
    try { Update-RDMUI | Out-Null } catch {}

    return $repo
}

function Invoke-ExportRDM([object[]]$Sessions, [string]$Path) {
    try {
        Export-RDMSession -XML -Sessions $Sessions -Path $Path -IncludeCredentials -IncludeAttachments -IncludeDocumentation -ErrorAction Stop | Out-Null
    }
    catch {
        # Legacy fallback
        Export-RDMSession -XML -Sessions $Sessions -Path $Path -IncludeCredentials -IncludeAttachements -IncludeDocumentation -ErrorAction Stop | Out-Null
    }
}

function Invoke-ImportRDM([string]$Path) {
    # Import at root
    try {
        Import-RDMEntry -Path $Path -DuplicateAction Add -Set -ErrorAction Stop | Out-Null
    }
    catch {
        # Legacy fallback
        Import-RDMEntry -Path $Path -DuplicateAction Add -ErrorAction Stop | Out-Null
    }
}

function Get-UserGroupRole([string]$groupName) {
    Write-Host "Ophalen van user group '$groupName'..." -ForegroundColor Gray
    
    try {
        $role = Get-RDMRole -Name $groupName -ErrorAction Stop
        if (-not $role) {
            Write-Warning "User group '$groupName' niet gevonden."
            return $null
        }
        Write-Host "User group '$groupName' gevonden." -ForegroundColor Green
        return $role
    }
    catch {
        Write-Warning "Fout bij ophalen van user group: $($_.Exception.Message)"
        return $null
    }
}

function Assign-UserGroupToRepository([string]$repoName, [string]$groupName, [object]$role = $null) {
    Write-Host "Toewijzen van user group '$groupName' aan vault '$repoName'..." -ForegroundColor Gray
    
    # If role not provided, fetch it
    if (-not $role) {
        $role = Get-UserGroupRole -groupName $groupName
        if (-not $role) {
            return $false
        }
    }
    
    # Retry logic for repository access assignment
    $maxRetries = 5
    $retryDelay = 1000  # milliseconds
    
    for ($attempt = 1; $attempt -le $maxRetries; $attempt++) {
        try {
            # Get the repository
            $repo = Get-RDMRepository | Where-Object { $_.Name -eq $repoName } | Select-Object -First 1
            if (-not $repo) {
                if ($attempt -lt $maxRetries) {
                    Write-Host "Vault '$repoName' nog niet beschikbaar, wachten... (poging $attempt/$maxRetries)" -ForegroundColor Gray
                    Start-Sleep -Milliseconds $retryDelay
                    continue
                }
                Write-Warning "Vault '$repoName' niet gevonden voor user group toewijzing."
                return $false
            }
            
            # Refresh RDM UI to ensure latest state
            try { Update-RDMUI | Out-Null } catch {}
            
            # Method 1: Add repository access to the role
            Add-RDMRoleRepositoryAccess -Role $role -Repository $repo -ErrorAction Stop
            
            # Method 2: Also set the repository security to use the role
            # This ensures the group is actually applied to the vault
            try {
                Set-RDMRepositorySecurity -Repository $repo -RoleId $role.ID -ErrorAction Stop
                Write-Host "Repository security ingesteld voor user group '$groupName'." -ForegroundColor Green
            }
            catch {
                Write-Host "Waarschuwing: Add-RDMRoleRepositoryAccess geslaagd, maar Set-RDMRepositorySecurity mislukt: $($_.Exception.Message)" -ForegroundColor Yellow
                # Continue anyway, the first method might be sufficient
            }
            
            Write-Host "User group '$groupName' succesvol toegewezen aan vault '$repoName'." -ForegroundColor Green
            return $true
        }
        catch {
            if ($attempt -lt $maxRetries) {
                Write-Host "Toewijzing mislukt (poging $attempt/$maxRetries), opnieuw proberen... Fout: $($_.Exception.Message)" -ForegroundColor Yellow
                Start-Sleep -Milliseconds $retryDelay
            }
            else {
                Write-Warning "Fout bij toewijzen van user group na $maxRetries pogingen: $($_.Exception.Message)"
                Write-Host "De vault is aangemaakt maar de user group is niet toegewezen." -ForegroundColor Yellow
                Write-Host "Mogelijke oorzaken:" -ForegroundColor Yellow
                Write-Host "  - Onvoldoende rechten om user groups toe te wijzen" -ForegroundColor Yellow
                Write-Host "  - User group bestaat niet of is niet actief" -ForegroundColor Yellow
                Write-Host "U kunt dit handmatig doen in RDM of een administrator om hulp vragen." -ForegroundColor Yellow
                return $false
            }
        }
    }
    
    return $false
}

# --- Main Script ---

# 1. Ask for Input if missing
if ([string]::IsNullOrWhiteSpace($NewCustomerName)) {
    # If running in RDM, this might pop up a console window or be handled by the script runner
    $NewCustomerName = Read-Host "Geef de naam van de nieuwe klant (bv. 'Klant ABC')"
}

if ([string]::IsNullOrWhiteSpace($NewCustomerName)) {
    Write-Warning "Geen naam opgegeven. Script stopt."
    return
}

# 2. Select Data Source if not provided
if ([string]::IsNullOrWhiteSpace($DataSourceName)) {
    $DataSourceName = Select-RDMDataSource

    if ([string]::IsNullOrWhiteSpace($DataSourceName)) {
        Write-Warning "Geen data source geselecteerd. Script stopt."
        return
    }
}
else {
    Write-Host "`nData source: $DataSourceName" -ForegroundColor Cyan
}

# Sanitize filename for temp export
$sanitizedName = ($NewCustomerName -replace '[\\\/:\*\?"<>\|\r\n]', '_')
$tempExportPath = Join-Path $env:TEMP ("RDM_Template_Export_{0}.rdm" -f [guid]::NewGuid())

try {
    # 0. Connect to datasource - Check if already connected first
    Write-Host "`n=== Verbinding maken met RDM ===" -ForegroundColor Cyan

    # Get the datasource
    $ds = Get-RDMDataSource | Where-Object { $_.Name -eq $DataSourceName } | Select-Object -First 1
    if (-not $ds) {
        throw "Datasource '$DataSourceName' niet gevonden."
    }

    # Always set datasource (even if already current) to ensure connection is active
    # This matches the manual command behavior
    Write-Host "Activeren van datasource '$DataSourceName'..." -ForegroundColor Gray
    Set-RDMCurrentDataSource -DataSource $ds

    # Wait for connection to initialize
    Start-Sleep -Seconds 2

    # Test connection with retry - connection may need time to stabilize
    Write-Host "Testen van verbinding..." -ForegroundColor Gray

    $testVaults = $null
    $maxAttempts = 8
    $connectionReady = $false

    for ($attempt = 1; $attempt -le $maxAttempts; $attempt++) {
        # Wait before each attempt (including first)
        Start-Sleep -Seconds 2

        # Get vaults - don't use ErrorAction Stop, let warnings pass through
        $testVaults = Get-RDMRepository

        if ($testVaults) {
            $connectionReady = $true
            break
        }

        if ($attempt -lt $maxAttempts) {
            Write-Host "  Nog geen vaults beschikbaar, poging $attempt/$maxAttempts..." -ForegroundColor Gray
        }
    }

    if ($connectionReady) {
        $vaultCount = @($testVaults).Count
        Write-Host "SUCCESS: Verbinding actief! $vaultCount vault(s) beschikbaar" -ForegroundColor Green

        # Check if template vault exists
        $templateExists = $testVaults | Where-Object { $_.Name -eq $TemplateVaultName }
        if ($templateExists) {
            Write-Host "  Template vault '$TemplateVaultName' gevonden" -ForegroundColor Gray
        } else {
            Write-Warning "Template vault '$TemplateVaultName' niet gevonden!"
            Write-Host "Beschikbare vaults:" -ForegroundColor Yellow
            $testVaults | ForEach-Object { Write-Host "  - $($_.Name)" -ForegroundColor Gray }
            throw "Template vault niet beschikbaar."
        }
    } else {
        Write-Host "`nFOUT: Kan geen verbinding maken met datasource na $maxAttempts pogingen!" -ForegroundColor Red
        Write-Host "`nMogelijke oorzaak: Verlopen authenticatiesessie" -ForegroundColor Yellow
        Write-Host "`nOplossing:" -ForegroundColor Cyan
        Write-Host "  1. Sluit ALLE PowerShell vensters (ook in VS Code)" -ForegroundColor White
        Write-Host "  2. Herstart Remote Desktop Manager" -ForegroundColor White
        Write-Host "  3. Log in op datasource '$DataSourceName' in RDM" -ForegroundColor White
        Write-Host "  4. Wacht tot alle vaults zichtbaar zijn in RDM" -ForegroundColor White
        Write-Host "  5. Open een NIEUW PowerShell venster" -ForegroundColor White
        Write-Host "  6. Voer dit script opnieuw uit" -ForegroundColor White
        Write-Host "`nDe authenticatie popup zal verschijnen - bevestig uw credentials." -ForegroundColor Yellow
        throw "Geen vaults beschikbaar - authenticatiesessie mogelijk verlopen."
    }

    # 3. Export Template
    Write-Host "`n=== Stap 1/4: Template ophalen ===" -ForegroundColor Cyan
    Use-Repo -dsName $DataSourceName -repoName $TemplateVaultName | Out-Null

    $templateEntries = Get-RDMEntry
    if (-not $templateEntries) { throw "Template vault '$TemplateVaultName' lijkt leeg!" }

    Invoke-ExportRDM -Sessions $templateEntries -Path $tempExportPath
    Write-Host "Template geëxporteerd naar tijdelijk bestand." -ForegroundColor Green

    # 3. Create New Vault
    Write-Host "`n=== Stap 2/4: Nieuwe vault '$NewCustomerName' aanmaken ===" -ForegroundColor Cyan
    
    # Pre-fetch user group role BEFORE creating vault to assign it immediately
    $userGroupRole = $null
    if (-not [string]::IsNullOrWhiteSpace($UserGroupName)) {
        $userGroupRole = Get-UserGroupRole -groupName $UserGroupName
        if (-not $userGroupRole) {
            Write-Warning "User group '$UserGroupName' kon niet worden opgehaald. De vault wordt aangemaakt zonder groep-toewijzing."
            Write-Host "U moet de rechten later handmatig toewijzen." -ForegroundColor Yellow
        }
    }
    
    # Check existence
    $exists = Get-RDMRepository | Where-Object { $_.Name -eq $NewCustomerName } | Select-Object -First 1
    $newlyCreatedVault = $null

    if ($exists) {
        Write-Warning "Vault '$NewCustomerName' bestaat al! We gebruiken de bestaande vault."
    }
    else {
        # Create new vault WITH -SetRepository to activate it immediately
        Write-Host "Aanmaken van nieuwe vault..." -ForegroundColor Gray
        $newlyCreatedVault = New-RDMRepository -Name $NewCustomerName -IsAllowedOffline $true -SetRepository
        Write-Host "Vault aangemaakt en geactiveerd (ID: $($newlyCreatedVault.ID))." -ForegroundColor Green

        # Wacht even zodat de vault volledig beschikbaar is
        Start-Sleep -Milliseconds 1500
        try { Update-RDMUI | Out-Null } catch {}
    }

    # 4. Import Template
    Write-Host "`n=== Stap 3/4: Template importeren ===" -ForegroundColor Cyan

    if ($exists) {
        # Bestaande vault: expliciet verbinden
        Write-Host "Verbinden met bestaande vault '$NewCustomerName'..." -ForegroundColor Gray
        Use-Repo -dsName $DataSourceName -repoName $NewCustomerName | Out-Null
    }
    else {
        # Nieuwe vault: we moeten de user group EERST toewijzen
        # DAN pas kan de vault gebruikt worden
        Write-Host "Vault net aangemaakt - user group moet EERST worden toegewezen." -ForegroundColor Yellow

        # Wijs user group toe aan het vault object (VOOR import)
        if ($userGroupRole) {
            Write-Host "Toewijzen van user group VOOR import..." -ForegroundColor Gray
            try {
                Add-RDMRoleRepositoryAccess -Role $userGroupRole -Repository $newlyCreatedVault -ErrorAction Stop
                Write-Host "User group toegewezen. Wachten op sync..." -ForegroundColor Green

                # Wacht op database sync
                Start-Sleep -Seconds 2
                try { Update-RDMUI | Out-Null } catch {}
                Start-Sleep -Seconds 2
            }
            catch {
                Write-Warning "Kon user group niet toewijzen: $($_.Exception.Message)"
            }
        }

        # Nu datasource volledig reconnecten
        Write-Host "Reconnecten met datasource om nieuwe vault zichtbaar te maken..." -ForegroundColor Gray
        $ds = Get-RDMDataSource -Name $DataSourceName
        Set-RDMCurrentDataSource -DataSource $ds | Out-Null
        Start-Sleep -Seconds 1
        try { Update-RDMUI | Out-Null } catch {}

        # Probeer de vault te vinden en activeren
        Write-Host "Zoeken naar nieuwe vault '$NewCustomerName'..." -ForegroundColor Gray
        $targetVault = Get-RDMRepository | Where-Object { $_.Name -eq $NewCustomerName } | Select-Object -First 1
        if ($targetVault) {
            Write-Host "Vault gevonden! Activeren..." -ForegroundColor Green
            Set-RDMCurrentRepository -Repository $targetVault | Out-Null
            Start-Sleep -Milliseconds 500
        }
        else {
            Write-Warning "Vault niet gevonden na security configuratie!"
            Write-Host "De vault is aangemaakt maar nog niet toegankelijk." -ForegroundColor Yellow
            throw "Vault niet toegankelijk. Wacht enkele minuten en voer het script opnieuw uit met dezelfde naam."
        }

        try { Update-RDMUI | Out-Null } catch {}
    }

    # Verificatie welke vault actief is
    $currentRepo = Get-RDMCurrentRepository
    Write-Host "Actieve vault: $($currentRepo.Name)" -ForegroundColor Gray

    # Check if vault is empty to avoid duplicates
    $current = Get-RDMEntry
    if ($current) {
        $entryCount = @($current).Count
        Write-Host "WAARSCHUWING: Vault bevat al $entryCount entries!" -ForegroundColor Yellow
        $conf = Read-Host "Toch importeren? (J/N)"
        if ($conf -notmatch '^[jJ]') {
            Write-Warning "Import overgeslagen."
        }
        else {
            Invoke-ImportRDM -Path $tempExportPath
            Write-Host "Template geïmporteerd." -ForegroundColor Green
        }
    }
    else {
        Write-Host "Vault is leeg, importeren van template..." -ForegroundColor Gray
        Invoke-ImportRDM -Path $tempExportPath
        Write-Host "Template geïmporteerd." -ForegroundColor Green
    }

    # 5. Verify user group (already assigned in Step 3 for new vaults)
    if ($userGroupRole -and -not $exists) {
        Write-Host "`n=== Stap 4/4: Verificatie ===" -ForegroundColor Cyan
        Write-Host "User group '$UserGroupName' werd toegewezen voor import (Stap 3)." -ForegroundColor Gray

        # Verify if vault is visible
        Write-Host "Controleren of vault zichtbaar is in repository lijst..." -ForegroundColor Gray
        $verifyRepo = Get-RDMRepository | Where-Object { $_.Name -eq $NewCustomerName } | Select-Object -First 1
        if ($verifyRepo) {
            Write-Host "SUCCESS: Vault '$NewCustomerName' is zichtbaar in de repository lijst!" -ForegroundColor Green
            Write-Host "User group security is correct geconfigureerd." -ForegroundColor Green
        }
        else {
            Write-Host "WAARSCHUWING: Vault is niet zichtbaar in repository lijst." -ForegroundColor Yellow
            Write-Host "Dit kan betekenen dat u geen lid bent van de user group '$UserGroupName'." -ForegroundColor Yellow
        }
    }

    Write-Host "`n=== Klaar! ===" -ForegroundColor Green
    Write-Host "De nieuwe klant vault '$NewCustomerName' is gereed voor gebruik." -ForegroundColor Green
    if ($userGroupRole) {
        Write-Host "User group '$UserGroupName' heeft toegang tot de vault." -ForegroundColor Cyan
    }

    # Instructies voor zichtbaarheid in RDM UI
    if (-not $exists) {
        Write-Host "`n=== BELANGRIJK: Vault zichtbaar maken in RDM ===" -ForegroundColor Yellow
        Write-Host "De vault is succesvol aangemaakt, maar is mogelijk nog niet zichtbaar in RDM UI." -ForegroundColor Yellow
        Write-Host "`nVoer EEN van de volgende acties uit:" -ForegroundColor Cyan
        Write-Host "  OPTIE 1 (Snelst): Druk F5 in RDM om de vault lijst te verversen" -ForegroundColor White
        Write-Host "  OPTIE 2: Klik op 'Bestand > Ververs' in RDM" -ForegroundColor White
        Write-Host "  OPTIE 3: Herstart RDM volledig" -ForegroundColor White
        Write-Host "  OPTIE 4: Log uit en weer in in RDM" -ForegroundColor White
        Write-Host "`nDaarna zou vault '$NewCustomerName' zichtbaar moeten zijn in uw vault lijst." -ForegroundColor Green
    }
    
}
catch {
    Write-Error "Fout opgetreden: $($_.Exception.Message)"
}
finally {
    # Cleanup
    if ($DeleteTempFile -and (Test-Path $tempExportPath)) {
        Remove-Item $tempExportPath -Force
    }
}
