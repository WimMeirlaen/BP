﻿
param(
    [bool]$UpdateHtmlIfExists = $true,
    [string]$OnlySourcePage,
    [int]$MaxItems = 0,
    [switch]$RunDuplicateSweepEachItem,
    [bool]$FailFastOnDocMismatch = $true,
    [bool]$RetryFailedItemsOnce = $true
)

Add-Type -AssemblyName System.Windows.Forms

# Quick Edit Mode uitschakelen (ConHost pauzeert script bij muisklik anders)
try {
    $consoleHelperCode = @"
using System;
using System.Runtime.InteropServices;
public class ConsoleQuickEdit {
    const uint ENABLE_QUICK_EDIT = 0x0040;
    const uint ENABLE_EXTENDED_FLAGS = 0x0080;
    [DllImport("kernel32.dll", SetLastError = true)]
    static extern IntPtr GetStdHandle(int nStdHandle);
    [DllImport("kernel32.dll")]
    static extern bool GetConsoleMode(IntPtr handle, out uint mode);
    [DllImport("kernel32.dll")]
    static extern bool SetConsoleMode(IntPtr handle, uint mode);
    public static void Disable() {
        IntPtr handle = GetStdHandle(-10);
        uint mode;
        if (GetConsoleMode(handle, out mode)) {
            mode &= ~ENABLE_QUICK_EDIT;
            mode |= ENABLE_EXTENDED_FLAGS;
            SetConsoleMode(handle, mode);
        }
    }
}
"@
    if (-not ([System.Management.Automation.PSTypeName]'ConsoleQuickEdit').Type) {
        Add-Type -TypeDefinition $consoleHelperCode
    }
    [ConsoleQuickEdit]::Disable()
} catch { }

# ==================================================
# BULK IMPORT CLIENT - NACHTVERWERKING VERSIE
# ==================================================
# Selecteer meerdere export folders en koppel ze aan vaults
# Alle user input gebeurt upfront, daarna batch verwerking

$script:RunWarnings = New-Object System.Collections.Generic.List[string]
$script:RunErrors = New-Object System.Collections.Generic.List[string]
$script:RunMessageSeen = @{}

function Add-RunSummaryMessage {
    param(
        [ValidateSet('WARN','ERROR')][string]$Level,
        [string]$Message
    )

    if ([string]::IsNullOrWhiteSpace($Message)) { return }

    $normalized = ([string]$Message).Trim()
    if ([string]::IsNullOrWhiteSpace($normalized)) { return }

    $key = "{0}|{1}" -f $Level, $normalized.ToLowerInvariant()
    if ($script:RunMessageSeen.ContainsKey($key)) { return }
    $script:RunMessageSeen[$key] = $true

    if ($Level -eq 'ERROR') {
        $script:RunErrors.Add($normalized) | Out-Null
    } else {
        $script:RunWarnings.Add($normalized) | Out-Null
    }
}

# Helpers
function Write-Step($t)   { Write-Host "`n$t" -ForegroundColor Yellow }
function Write-Ok($t)     { Write-Host "✓ $t" -ForegroundColor Green }
function Write-Info($t)   { Write-Host "ℹ $t" -ForegroundColor DarkGray }
function Write-Warn($t)   { Add-RunSummaryMessage -Level 'WARN' -Message $t; Write-Warning $t }
function Write-Error2($t) { Add-RunSummaryMessage -Level 'ERROR' -Message $t; Write-Host "✗ $t" -ForegroundColor Red }


# -----------------------------
# Logging setup
# -----------------------------
$script:LogDir = Join-Path $PSScriptRoot "logs"
New-Item -ItemType Directory -Path $script:LogDir -Force | Out-Null
$script:LogFile = Join-Path $script:LogDir "bulk-importlog$(Get-Date -Format 'ddMMyyyyHHmmss').log"
$script:ImportSuccessFile = Join-Path $script:LogDir "import-success.txt"
$script:ImportFailedFile  = Join-Path $script:LogDir "import-failed.txt"

function Write-Log {
    param(
        [string]$Message,
        [ValidateSet('INFO','WARN','ERROR','SUCCESS')][string]$Level = 'INFO'
    )
    $ts = Get-Date -Format 'dd/MM/yyyy HH:mm:ss'
    $line = "[$ts] [$Level] $Message"
    Add-Content -Path $script:LogFile -Value $line -Encoding UTF8

    if ($Level -in @('WARN','ERROR')) {
        Add-RunSummaryMessage -Level $Level -Message $Message
    }
}

Write-Log "=== SCRIPT GESTART ==="

function Ensure-DevolutionsModule {
    if (-not (Get-Module -ListAvailable -Name Devolutions.PowerShell)) {
        throw "Devolutions.PowerShell module niet gevonden."
    }
    Import-Module Devolutions.PowerShell -ErrorAction Stop
}

function Get-ExceptionMessageText {
    param(
        [Parameter(Mandatory)]$ErrorRecord
    )

    $parts = New-Object System.Collections.Generic.List[string]
    if ($ErrorRecord.Exception -and -not [string]::IsNullOrWhiteSpace($ErrorRecord.Exception.Message)) {
        $parts.Add([string]$ErrorRecord.Exception.Message) | Out-Null
    }

    $inner = $ErrorRecord.Exception
    while ($inner -and $inner.InnerException) {
        $inner = $inner.InnerException
        if ($inner -and -not [string]::IsNullOrWhiteSpace($inner.Message)) {
            $parts.Add([string]$inner.Message) | Out-Null
        }
    }

    if ($parts.Count -eq 0) {
        return [string]$ErrorRecord
    }

    return ($parts -join ' | ')
}

function Test-IsTransientDataSourceError {
    param([string]$Message)

    if ([string]::IsNullOrWhiteSpace($Message)) { return $false }

    return (
        $Message -match '(?i)timeout expired' -or
        $Message -match '(?i)unable to connect to your data source' -or
        $Message -match '(?i)server is not responding' -or
        $Message -match '(?i)transport-level error' -or
        $Message -match '(?i)connection.*(closed|broken|forcibly)' -or
        $Message -match '(?i)a network-related or instance-specific error'
    )
}

function Invoke-RDMOperationWithRetry {
    param(
        [Parameter(Mandatory)][string]$OperationName,
        [Parameter(Mandatory)][scriptblock]$Action,
        [int]$MaxAttempts = 3,
        [int]$BaseDelaySeconds = 3
    )

    for ($attempt = 1; $attempt -le $MaxAttempts; $attempt++) {
        try {
            return (& $Action)
        } catch {
            $msg = Get-ExceptionMessageText -ErrorRecord $_
            $isTransient = Test-IsTransientDataSourceError -Message $msg
            $isLast = ($attempt -ge $MaxAttempts)

            if ($isTransient -and -not $isLast) {
                $delay = [math]::Min(20, $BaseDelaySeconds * $attempt)
                Write-Warn "$OperationName tijdelijk mislukt (attempt $attempt/$MaxAttempts): $msg"
                Write-Info "Wacht $delay s en probeer opnieuw..."
                Start-Sleep -Seconds $delay
                continue
            }

            throw
        }
    }
}

function Refresh-RDMDataSourceContext {
    param(
        [Parameter(Mandatory)]$DataSource,
        [Parameter(Mandatory)]$Vault
    )

    Invoke-RDMOperationWithRetry -OperationName "Datasource context refresh" -Action {
        Set-RDMCurrentDataSource -DataSource $DataSource | Out-Null
    } -MaxAttempts 3 -BaseDelaySeconds 2 | Out-Null

    Start-Sleep -Seconds 2
    try { Update-RDMUI | Out-Null } catch {}

    Invoke-RDMOperationWithRetry -OperationName "Vault context activatie" -Action {
        Set-RDMCurrentRepository -Repository $Vault | Out-Null
    } -MaxAttempts 3 -BaseDelaySeconds 2 | Out-Null

    Start-Sleep -Seconds 1
}

function Get-RDMVaultsWithRetry {
    param(
        [Parameter(Mandatory)]$DataSource,
        [int]$MaxWaitSeconds = 60,
        [int]$IntervalSeconds = 3,
        [int]$MaxRefreshPasses = 3
    )

    Invoke-RDMOperationWithRetry -OperationName "Datasource activeren" -Action {
        Set-RDMCurrentDataSource -DataSource $DataSource | Out-Null
    } -MaxAttempts 3 -BaseDelaySeconds 2 | Out-Null

    Start-Sleep -Seconds 2
    try { Update-RDMUI | Out-Null } catch {}

    $vaults = @()
    $waited = 0
    $refreshPass = 0

    do {
        try {
            $vaults = Invoke-RDMOperationWithRetry -OperationName "Vaults ophalen" -Action {
                @(Get-RDMRepository)
            } -MaxAttempts 2 -BaseDelaySeconds 2
        } catch {
            $vaults = @()
        }

        $vaultCount = @($vaults).Count
        $firstVaultName = if ($vaultCount -gt 0) { [string]$vaults[0].Name } else { '' }

        if (($vaultCount -le 1 -or $firstVaultName -eq 'Default') -and $waited -lt $MaxWaitSeconds) {
            Write-Info "Wachten op vault sync... ($waited/$MaxWaitSeconds s)"
            Start-Sleep -Seconds $IntervalSeconds
            $waited += $IntervalSeconds
        }
    } while ((@($vaults).Count -le 1 -or ([string]$vaults[0].Name -eq 'Default')) -and $waited -lt $MaxWaitSeconds)

    while ((@($vaults).Count -le 1 -or ([string]$vaults[0].Name -eq 'Default')) -and $refreshPass -lt $MaxRefreshPasses) {
        $refreshPass++
        Write-Warn "Vault lijst onvolledig ($(@($vaults).Count) zichtbaar). Force refresh pass $refreshPass/$MaxRefreshPasses..."

        try {
            Set-RDMCurrentDataSource -DataSource $DataSource | Out-Null
            Start-Sleep -Seconds (2 + $refreshPass)
            try { Update-RDMUI | Out-Null } catch {}
            $vaults = @(Get-RDMRepository)
            # If Get-RDMRepository still returns only default/empty, try Get-RDMVault as fallback
            if ((@($vaults).Count -le 1 -or ([string]$vaults[0].Name -eq 'Default'))) {
                try {
                    Write-Info "Get-RDMRepository returned only Default/empty — probeer Get-RDMVault fallback..."
                    $vaults = @(Get-RDMVault)
                } catch {
                    Write-Warn "Get-RDMVault fallback faalde: $($_.Exception.Message)"
                }
            }
        } catch {
            $vaults = @()
            Write-Warn "Force refresh pass $refreshPass faalde: $($_.Exception.Message)"
        }
    }

    $vaultCount = @($vaults).Count
    if ($vaultCount -le 1 -or ([string]$vaults[0].Name -eq 'Default')) {
        $visibleNames = if ($vaultCount -gt 0) { @($vaults | ForEach-Object { $_.Name }) -join ', ' } else { '<geen>' }
        Write-Warn "Slechts $vaultCount vault(s) zichtbaar na sync/refresh: $visibleNames. Dit kan wijzen op een instabiele datasource sessie."
    }

    if (-not $vaults -or $vaults.Count -eq 0) {
        throw "Geen vaults gevonden in datasource '$($DataSource.Name)'. RDM-verbinding controleren!"
    }

    if (@($vaults).Count -eq 1 -and [string]$vaults[0].Name -eq 'Default') {
        throw "RDM toont alleen 'Default' voor datasource '$($DataSource.Name)'. Herstart RDM en log opnieuw in op de datasource."    
    }

    return @($vaults)
}

function Get-CustomerNameFromExportRoot {
    param([string]$Path)
    $leaf = Split-Path $Path -Leaf
    $name = $leaf -replace '(?i)([-_ ]?full|[-_ ]?export|[-_ ]?html|[-_ ]?onenote)$',''
    $name = $name.Trim(' ','-','_')
    if ([string]::IsNullOrWhiteSpace($name)) { $name = $leaf }
    return $name
}

function Normalize-Name {
    param([string]$Name)
    $n = ($Name ?? "").Trim().ToLowerInvariant()
    $n = $n -replace '[-_]+',' '
    $n = $n -replace '\s+',' '
    $n = $n -replace '(?i)\b(sharedwithcustomer|shared with customer|mw documentation|mwdocumentation)\b',''
    $n = $n -replace '\s+',' '
    return $n.Trim()
}

function Score-Match {
    param([string]$Left,[string]$Right)
    $a = Normalize-Name $Left
    $b = Normalize-Name $Right
    if ($a -eq $b) { return 100 }
    if ($a.Length -ge 4 -and $b.Length -ge 4) {
        if ($a.Contains($b)) { return 95 }
        if ($b.Contains($a)) { return 90 }
    }
    $aw = $a -split '\s+' | Where-Object { $_.Length -gt 2 }
    $bw = $b -split '\s+' | Where-Object { $_.Length -gt 2 }
    if ($aw.Count -eq 0 -or $bw.Count -eq 0) { return 0 }
    $common = ($aw | Where-Object { $bw -contains $_ }).Count
    $score = [math]::Round(($common / [math]::Max($aw.Count,$bw.Count)) * 100, 0)
    return [int]$score
}

function Select-FromList {
    param(
        [Parameter(Mandatory)]$Items,
        [Parameter(Mandatory)][string]$Title,
        [string]$DisplayProperty = "Name"
    )
    if (Get-Command Out-GridView -ErrorAction SilentlyContinue) {
        $pick = $Items | Select-Object $DisplayProperty | Out-GridView -PassThru -Title $Title
        if ($pick) {
            $val = $pick.$DisplayProperty
            return ($Items | Where-Object { $_.$DisplayProperty -eq $val } | Select-Object -First 1)
        }
        return $null
    }
    Write-Host "`n$Title" -ForegroundColor Cyan
    for ($i = 0; $i -lt $Items.Count; $i++) {
        Write-Host ("[{0}] {1}" -f $i, ($Items[$i].$DisplayProperty))
    }
    $idx = Read-Host "Kies index"
    if ($idx -notmatch '^\d+$') { throw "Ongeldige index." }
    return $Items[[int]$idx]
}

function Select-MultipleFromList {
    param(
        [Parameter(Mandatory)]$Items,
        [Parameter(Mandatory)][string]$Title,
        [string]$DisplayProperty = "Name",
        [string]$IdentityProperty = "FullName"
    )

    if (-not $Items -or $Items.Count -eq 0) { return @() }

    if (Get-Command Out-GridView -ErrorAction SilentlyContinue) {
        $gridItems = @()
        for ($i = 0; $i -lt $Items.Count; $i++) {
            $gridItems += [pscustomobject]@{
                Index = $i
                Name  = [string]$Items[$i].$DisplayProperty
                Path  = [string]$Items[$i].$IdentityProperty
            }
        }

        $picked = $gridItems | Out-GridView -PassThru -Title $Title
        if (-not $picked) { return @() }

        $selected = @()
        foreach ($p in @($picked)) {
            $match = $Items | Where-Object { [string]$_.$IdentityProperty -eq [string]$p.Path } | Select-Object -First 1
            if ($match) { $selected += $match }
        }
        return @($selected)
    }

    Write-Host "`n$Title" -ForegroundColor Cyan
    for ($i = 0; $i -lt $Items.Count; $i++) {
        Write-Host ("[{0}] {1}" -f $i, ($Items[$i].$DisplayProperty))
    }
    $raw = Read-Host "Kies indexen (komma-gescheiden, bv. 0,2,5)"
    if ([string]::IsNullOrWhiteSpace($raw)) { return @() }

    $selected = @()
    $parts = $raw -split ',' | ForEach-Object { $_.Trim() } | Where-Object { $_ -match '^\d+$' }
    foreach ($part in $parts) {
        $idx = [int]$part
        if ($idx -ge 0 -and $idx -lt $Items.Count) {
            $selected += $Items[$idx]
        }
    }

    return @($selected)
}

# ==================================================
# STAP 1: SCRIPTS EN CONFIG VALIDEREN
# ==================================================
Write-Step "Scripts en configuratie valideren..."

$ImportScript  = Join-Path $PSScriptRoot "Import-ToRDM2.ps1"
$AnalyzeScript = Join-Path $PSScriptRoot "Analyze-Hydrex-Full.ps1"
$ConfigPath    = Join-Path $PSScriptRoot "migration-config.json"

if (-not (Test-Path $ImportScript))  { throw "Import-ToRDM2.ps1 niet gevonden in scriptmap." }
if (-not (Test-Path $AnalyzeScript)) { throw "Analyze-Hydrex-Full.ps1 niet gevonden in scriptmap." }
if (-not (Test-Path $ConfigPath))    { throw "migration-config.json niet gevonden in scriptmap." }

Write-Ok "Alle scripts en config gevonden"

# Config laden
Write-Step "Config laden..."
$script:UserConfig = Get-Content $ConfigPath -Raw -Encoding UTF8 | ConvertFrom-Json
Write-Ok "Config geladen"

# Import library laden
Write-Step "Import library laden..."
. $ImportScript
Write-Ok "Import functies beschikbaar"

# ==================================================
# STAP 2: DEVOLUTIONS MODULE LADEN
# ==================================================
Write-Step "Devolutions.PowerShell module laden..."
Ensure-DevolutionsModule
Write-Ok "Module geladen"

# ...existing code...

# STAP 3: DATASOURCE EN VAULTS OPHALEN
Write-Step "RDM datasources ophalen..."
$datasources = Get-RDMDataSource
if (-not $datasources -or $datasources.Count -eq 0) {
    throw "Geen RDM datasources gevonden."
}

$writableDatasources = @($datasources | Where-Object { -not $_.ReadOnly })
if ($writableDatasources.Count -eq 0) {
    Write-Host "`nBeschikbare datasources:" -ForegroundColor Red
    $datasources | ForEach-Object { 
        $status = if ($_.ReadOnly) { "[READ-ONLY]" } else { "[BESCHRIJFBAAR]" }
        Write-Host "  - $($_.Name) $status" 
    }
    throw "FOUT: Geen beschrijfbare datasources gevonden. Controleer RDM instellingen."
}

$ds = if ($writableDatasources.Count -eq 1) {
    Write-Warn "Slechts 1 beschrijfbare datasource gevonden; automatisch gekozen."
    $writableDatasources[0]
} else {
    Write-Host "`nBeschrijfbare datasources:" -ForegroundColor Yellow
    $pick = Select-FromList -Items @($writableDatasources) -Title "Selecteer RDM datasource (beschrijfbaar)" -DisplayProperty "Name"
    if (-not $pick) { throw "Geen datasource geselecteerd." }
    $pick
}

Write-Ok "Datasource gekozen: $($ds.Name)"

if ($ds.ReadOnly) {
    throw "FOUT: De geselecteerde datasource '$($ds.Name)' is in READ-ONLY mode. Dit kan niet!"
}

# Vaults laden
Write-Step "Vaults uit datasource ophalen..."
$vaults = Get-RDMVaultsWithRetry -DataSource $ds -MaxWaitSeconds 60 -IntervalSeconds 3 -MaxRefreshPasses 3

Write-Ok "$($vaults.Count) vaults geladen"

# ==================================================
# STAP 4: EXPORT FOLDERS SELECTEREN EN MAPPEN KIEZEN
# ==================================================
Write-Step "Stap 4A: Kies eerst de BASISMAP met alle klant-exportfolders"
Write-Host "" 
Write-Host "  LET OP:" -ForegroundColor Yellow
Write-Host "  1) Eerst kies je de BASIMap (bv. C:\Temp)" -ForegroundColor Yellow
Write-Host "  2) Daarna kies je meerdere klantfolders uit die basismap" -ForegroundColor Yellow
Write-Host "" 

$mappings = @()

# 1) Kies basismap met klantexports
$dialog = New-Object System.Windows.Forms.FolderBrowserDialog
$dialog.Description = "Stap 4A - Kies BASISMAP met klant exportfolders (bv. C:\Temp). In de volgende stap kies je meerdere klantfolders."
$dialog.SelectedPath = "C:\Temp"
$dialog.ShowNewFolderButton = $false

$owner = New-Object System.Windows.Forms.Form
$owner.TopMost = $true
$owner.WindowState = [System.Windows.Forms.FormWindowState]::Minimized
$owner.Show()
[void]$owner.Focus()
$dialogResult = $dialog.ShowDialog($owner)
$owner.Dispose()

if ($dialogResult -ne [System.Windows.Forms.DialogResult]::OK) {
    Write-Host "Geannuleerd door gebruiker." -ForegroundColor Yellow
    exit 0
}

$baseFolder = $dialog.SelectedPath
if (-not (Test-Path -LiteralPath $baseFolder)) {
    throw "Basismap bestaat niet: $baseFolder"
}

# 2) Multi-select klantfolders uit basismap (LITERALPATH FIX)
Write-Step "Stap 4B: Selecteer nu één of meerdere klantfolders uit de gekozen basismap"
$candidateFolders = @(Get-ChildItem -LiteralPath $baseFolder -Directory -ErrorAction SilentlyContinue | Sort-Object Name)
if ($candidateFolders.Count -eq 0) {
    Write-Error2 "Geen subfolders gevonden in: $baseFolder"
    throw "Basismap leeg of niet toegankelijk"
}

$selectedFolders = Select-MultipleFromList -Items $candidateFolders `
                                          -Title "Selecteer één of meerdere klant exportfolders" `
                                          -DisplayProperty "Name" `
                                          -IdentityProperty "FullName"

if (-not $selectedFolders -or $selectedFolders.Count -eq 0) {
    Write-Host "Geen exportfolders geselecteerd. Script afgebroken." -ForegroundColor Yellow
    exit 0
}

Write-Ok "$($selectedFolders.Count) exportfolder(s) geselecteerd"

# 3) Vault matching NA folderselectie
foreach ($folder in $selectedFolders) {
    $ExportRoot = $folder.FullName
    $customerName = Get-CustomerNameFromExportRoot -Path $ExportRoot
    
    # Controleer of export folder nog toegankelijk is
    if (-not (Test-Path -LiteralPath $ExportRoot -PathType Container)) {
        Write-Error2 "Kan niet toegang krijgen tot: $ExportRoot"
        Write-Log "SKIP: $customerName - foldertoegang geweigerd" 'WARN'
        continue
    }
    
    Write-Ok "Folder: $ExportRoot → Klant: '$customerName'"

    Write-Host "`nVault selecteren voor '$customerName':" -ForegroundColor Cyan

    $searchTerm = $customerName
    $selectedVault = $null

    while (-not $selectedVault) {
        $scored = $vaults | ForEach-Object {
            [pscustomobject]@{ Vault = $_; Score = Score-Match -Left $searchTerm -Right $_.Name }
        } | Sort-Object Score -Descending

        Write-Host "  Top 5 matches voor '$searchTerm':" -ForegroundColor DarkGray
        $scored | Select-Object -First 5 | ForEach-Object {
            Write-Host ("    [{0,3}] {1}" -f $_.Score, $_.Vault.Name)
        }

        $best = $scored | Select-Object -First 1
        $bestScore = [int]$best.Score
        $bestVault = $best.Vault

        if ($bestScore -ge 85) {
            Write-Ok "Beste match: '$($bestVault.Name)' (score $bestScore)"
            $confirm = Read-Host "  Gebruiken? [J/n]"
            if ($confirm -eq '' -or $confirm -match '^[jJyY]') {
                $selectedVault = $bestVault
            } else {
                $newTerm = Read-Host "  Voer zoekterm in (Enter = '$customerName')"
                $searchTerm = if ([string]::IsNullOrWhiteSpace($newTerm)) { $customerName } else { $newTerm }
            }
        } else {
            Write-Warn "Geen sterke match (beste score $bestScore)"
            $newTerm = Read-Host "  Voer zoekterm in (Enter = '$customerName')"
            $searchTerm = if ([string]::IsNullOrWhiteSpace($newTerm)) { $customerName } else { $newTerm }

            $rescored = $vaults | ForEach-Object {
                [pscustomobject]@{ Vault = $_; Score = Score-Match -Left $searchTerm -Right $_.Name }
            } | Sort-Object Score -Descending

            $retryBest = $rescored | Select-Object -First 1
            if ([int]$retryBest.Score -lt 50) {
                Write-Warn "Nog geen goede match. Kies handmatig:"
                $pick = Select-FromList -Items @($vaults) -Title "Kies vault manueel" -DisplayProperty "Name"
                if ($pick) {
                    $confirm = Read-Host "  Vault: '$($pick.Name)' gebruiken? [J/n]"
                    if ($confirm -eq '' -or $confirm -match '^[jJyY]') {
                        $selectedVault = $pick
                    }
                }
            }
        }
    }

    $mappings += [pscustomobject]@{
        ExportRoot = $ExportRoot
        CustomerName = $customerName
        VaultId = $selectedVault.ID
        VaultName = $selectedVault.Name
        Status = "Wacht op verwerking"
        ItemsImported = 0
        Errors = ""
    }

    Write-Ok "Mapping toegevoegd: '$customerName' → '$($selectedVault.Name)'"
    Write-Host ""
}

if ($mappings.Count -eq 0) {
    Write-Host "`nGeen mappings ingevoerd. Script afgebroken." -ForegroundColor Yellow
    exit 0
}

# ==================================================
# STAP 5: OVERZICHT MAPPINGS
# ==================================================
Write-Step "Mappings overzicht:"
Write-Host ""
$mappings | ForEach-Object {
    Write-Host "  ├─ $($_.CustomerName)" -ForegroundColor Cyan
    Write-Host "  │  Export: $($_.ExportRoot)" -ForegroundColor DarkGray
    Write-Host "  │  Vault : $($_.VaultName)" -ForegroundColor DarkGray
    Write-Host "  │  Status: $($_.Status)" -ForegroundColor Yellow
}

Write-Host ""
$confirm = Read-Host "Batch verwerking starten? [J/n]"
if ($confirm -notmatch '^[jJyY]' -and $confirm -ne '') {
    Write-Host "Geannuleerd." -ForegroundColor Yellow
    exit 0
}

$runStamp = Get-Date -Format "yyyyMMdd-HHmmss"
$failedLogRoot = Join-Path $PSScriptRoot "logs\bulk-import-failed-items"
New-Item -ItemType Directory -Path $failedLogRoot -Force | Out-Null

# ==================================================
# STAP 6: BATCH VERWERKING
# ==================================================
Write-Step "Batch verwerking starten..."
Write-Host ""

$totalCount = $mappings.Count
$currentIndex = 1

foreach ($mapping in $mappings) {
    Write-Host "════════════════════════════════════════════════════════" -ForegroundColor Cyan
    Write-Host "ITEM $currentIndex/${totalCount}: $($mapping.CustomerName)" -ForegroundColor Cyan
    Write-Log "[$currentIndex/$totalCount] Start: $($mapping.CustomerName) | Vault: $($mapping.VaultName) | ExportRoot: $($mapping.ExportRoot)"
    Write-Host "════════════════════════════════════════════════════════" -ForegroundColor Cyan
    Write-Host ""

    try {
        # Controleer folder opnieuw voor deze run
        if (-not (Test-Path -LiteralPath $mapping.ExportRoot -PathType Container)) {
            throw "Export folder niet meer toegankelijk: $($mapping.ExportRoot)"
        }

        # Vault activeren
        $vault = $vaults | Where-Object { $_.ID -eq $mapping.VaultId }
        if (-not $vault) {
            throw "Vault niet meer beschikbaar: ID $($mapping.VaultId)"
        }

        Write-Info "Vault activeren: $($vault.Name)"
        Invoke-RDMOperationWithRetry -OperationName "Vault activeren" -Action {
            Set-RDMCurrentRepository -Repository $vault | Out-Null
        } -MaxAttempts 3 -BaseDelaySeconds 2 | Out-Null
        Write-Ok "Vault actief"

        # Export analyseren
        Write-Info "Export analyseren: $($mapping.ExportRoot)"
        $data = & $AnalyzeScript -ExportRoot $mapping.ExportRoot -ErrorAction Stop
        if (-not $data -or -not $data.CategorizedItems -or $data.CategorizedItems.Count -eq 0) {
            Write-Error2 "Analyzer retourneerde geen items of ongeldig resultaat"
            throw "Analyzer gaf geen items terug"
        }
        Write-Ok "Analyzer ok: $($data.CategorizedItems.Count) items"

        # Import starten met reconnect + retry bij transient datasource fouten
        $maxCustomerAttempts = 3
        $importStats = $null

        for ($customerAttempt = 1; $customerAttempt -le $maxCustomerAttempts; $customerAttempt++) {
            try {
                if ($customerAttempt -gt 1) {
                    Write-Warn "Herstelpoging $customerAttempt/$maxCustomerAttempts voor klant '$($mapping.CustomerName)'"
                    Refresh-RDMDataSourceContext -DataSource $ds -Vault $vault
                }

                Write-Info "Import naar RDM starten..."
                Write-Log "[$currentIndex/$totalCount] Import gestart: $($mapping.CustomerName) (attempt $customerAttempt/$maxCustomerAttempts)"

                $importStats = Import-DataToRDM -Data $data `
                                                -DataSourceName $ds.Name `
                                                -VaultName $vault.Name `
                                                -UpdateHtmlIfExists:$UpdateHtmlIfExists `
                                                -OnlySourcePage $OnlySourcePage `
                                                -MaxItems $MaxItems `
                                                -RunDuplicateSweepEachItem:$RunDuplicateSweepEachItem `
                                                -FailFastOnDocMismatch:$FailFastOnDocMismatch -ErrorAction Stop

                if ($RetryFailedItemsOnce -and $importStats -and $importStats.FailedCount -gt 0 -and $importStats.FailedItems) {
                    $failedKeys = @{}
                    foreach ($fi in $importStats.FailedItems) {
                        $k = "{0}|||{1}" -f ([string]$fi.TargetFolder), ([string]$fi.SourcePage)
                        if (-not $failedKeys.ContainsKey($k)) { $failedKeys[$k] = $true }
                    }

                    $retryItems = @($data.CategorizedItems | Where-Object {
                        $rk = "{0}|||{1}" -f ([string]$_.TargetFolder), ([string]$_.SourcePage)
                        $failedKeys.ContainsKey($rk)
                    })

                    # Retry in parent-first order
                    $retryItems = @($retryItems | Sort-Object `
                        @{ Expression = {
                                $tf = [string]$_.TargetFolder
                                if ([string]::IsNullOrWhiteSpace($tf)) { return 0 }
                                return (@(($tf -replace '/', '\\').Trim('\\') -split '\\') | Where-Object { -not [string]::IsNullOrWhiteSpace($_) }).Count
                            }; Ascending = $true },
                        @{ Expression = { [string]$_.TargetFolder }; Ascending = $true },
                        @{ Expression = { [string]$_.SourcePage }; Ascending = $true }
                    )

                    if ($retryItems.Count -gt 0) {
                        Write-Host "" 
                        Write-Info "Retry gestart voor $($retryItems.Count) gefaalde item(s)..."
                        Write-Log "[$currentIndex/$totalCount] Retry gestart: $($retryItems.Count) gefaalde items" 'WARN'
                        Write-Info "Retry volgorde: parent-mappen eerst, daarna child-items"
                        $retryData = [pscustomobject]@{ CategorizedItems = $retryItems }

                        $retryStats = Import-DataToRDM -Data $retryData `
                                                      -DataSourceName $ds.Name `
                                                      -VaultName $vault.Name `
                                                      -UpdateHtmlIfExists:$UpdateHtmlIfExists `
                                                      -OnlySourcePage $OnlySourcePage `
                                                      -MaxItems 0 `
                                                      -RunDuplicateSweepEachItem:$RunDuplicateSweepEachItem `
                                                      -FailFastOnDocMismatch:$FailFastOnDocMismatch -ErrorAction Stop

                        Write-Info "Retry klaar: imported=$($retryStats.ImportedCount), updated=$($retryStats.UpdatedCount), failed=$($retryStats.FailedCount)"
                        Write-Log "[$currentIndex/$totalCount] Retry klaar: geimporteerd=$($retryStats.ImportedCount) bijgewerkt=$($retryStats.UpdatedCount) mislukt=$($retryStats.FailedCount)" $(if ($retryStats.FailedCount -gt 0) { 'WARN' } else { 'SUCCESS' })
                        $importStats = $retryStats
                    }
                }

                break
            } catch {
                $attemptMsg = Get-ExceptionMessageText -ErrorRecord $_
                $transient = Test-IsTransientDataSourceError -Message $attemptMsg
                $isLastAttempt = ($customerAttempt -ge $maxCustomerAttempts)

                if ($transient -and -not $isLastAttempt) {
                    Write-Warn "Transient datasource fout tijdens import van '$($mapping.CustomerName)' (attempt $customerAttempt/$maxCustomerAttempts): $attemptMsg"
                    Write-Log "[$currentIndex/$totalCount] Transient datasource fout (attempt $customerAttempt/$maxCustomerAttempts): $attemptMsg" 'WARN'
                    continue
                }

                throw
            }
        }

        if (-not $importStats) {
            throw "Import gaf geen resultaat terug na retries voor '$($mapping.CustomerName)'"
        }

        $mapping.Status = "✓ Voltooid"
        if ($importStats) {
            $mapping.ItemsImported = [int]$importStats.ImportedCount + [int]$importStats.UpdatedCount
            if ([int]$importStats.FailedCount -gt 0) {
                $mapping.Status = "⚠ Voltooid met fouten"
                $mapping.Errors = "$($importStats.FailedCount) item(s) gefaald na retry"

                if ($importStats.FailedItems -and $importStats.FailedItems.Count -gt 0) {
                    $safeCustomer = ($mapping.CustomerName -replace '[\\/:*?"<>|\[\]]','_')
                    $failedLogPath = Join-Path $failedLogRoot ("{0}-{1}-failed.csv" -f $runStamp, $safeCustomer)

                    $importStats.FailedItems |
                        Select-Object @{n='Customer';e={$mapping.CustomerName}},
                                      @{n='Vault';e={$vault.Name}},
                                      SourcePage,
                                      TargetFolder,
                                      Category,
                                      Error |
                        Export-Csv -LiteralPath $failedLogPath -NoTypeInformation -Encoding UTF8

                    Write-Warn "Resterende failures gelogd: $failedLogPath"
                    Write-Log "[$currentIndex/$totalCount] Gefaalde items voor $($mapping.CustomerName):" 'ERROR'
                    foreach ($fi in $importStats.FailedItems) {
                        Write-Log "  MISLUKT: $($fi.SourcePage) [$($fi.Category)] -> $($fi.Error)" 'ERROR'
                    }
                }
            }
        } else {
            $mapping.ItemsImported = $data.CategorizedItems.Count
        }
        Write-Ok "Import voltooid"
        $ts2 = Get-Date -Format 'dd/MM/yyyy HH:mm:ss'
        $statsSuffix = if ($importStats) { "Nieuw=$($importStats.ImportedCount) Bijgewerkt=$($importStats.UpdatedCount) Mislukt=$($importStats.FailedCount)" } else { "" }
        Write-Log "[$currentIndex/$totalCount] VOLTOOID: $($mapping.CustomerName) | $statsSuffix" $(if ($importStats -and $importStats.FailedCount -gt 0) { 'WARN' } else { 'SUCCESS' })
        Add-Content -LiteralPath $script:ImportSuccessFile -Value "$ts2 | $($mapping.CustomerName) | Vault: $($mapping.VaultName) | $statsSuffix" -Encoding UTF8

    } catch {
        $mapping.Status = "✗ Fout"
        $mapping.Errors = $_.Exception.Message
        Write-Error2 "Fout bij import: $($_.Exception.Message)"
        Write-Log "[$currentIndex/$totalCount] FOUT: $($mapping.CustomerName) | $($_.Exception.Message)" 'ERROR'
        Write-Log "Stack: $($_.ScriptStackTrace)" 'ERROR'
        $ts2 = Get-Date -Format 'dd/MM/yyyy HH:mm:ss'
        Add-Content -LiteralPath $script:ImportFailedFile -Value "$ts2 | $($mapping.CustomerName) | Vault: $($mapping.VaultName) | FOUT: $($_.Exception.Message)" -Encoding UTF8
    }

    Write-Host ""
    $currentIndex++

    if ($currentIndex -le $totalCount) {
        Write-Info "Pauze voor volgende item..."
        Start-Sleep -Seconds 5
    }
}

# ==================================================
# STAP 7: SLOTRAPPORT + REIMPORTLIJST
# ==================================================
Write-Step "Batch verwerking afgerond"
Write-Host ""
Write-Host "SAMENVATTING:" -ForegroundColor Cyan

$mappings | ForEach-Object {
    $statusColor = if ($_.Status -match "✓") { "Green" } elseif ($_.Status -match "⚠") { "Yellow" } else { "Red" }
    Write-Host "  $($_.Status) $($_.CustomerName)" -ForegroundColor $statusColor
    if ($_.ItemsImported -gt 0) {
        Write-Host "       $($_.ItemsImported) items geïmporteerd" -ForegroundColor Gray
    }
    if ($_.Errors) {
        Write-Host "       Fout: $($_.Errors)" -ForegroundColor Yellow
    }
}

Write-Host ""
$succeed = ($mappings | Where-Object { $_.Status -match "✓" }).Count
$failed = ($mappings | Where-Object { $_.Status -match "✗" }).Count
$partial = ($mappings | Where-Object { $_.Status -match "⚠" }).Count

Write-Host "Resultaat: $succeed geslaagd, $partial met fouten, $failed mislukt van $($mappings.Count) totaal" -ForegroundColor Cyan
Write-Log "=== BATCH KLAAR: $succeed geslaagd, $partial met fouten, $failed mislukt van $($mappings.Count) totaal ===" $(if ($failed -gt 0 -or $partial -gt 0) { 'WARN' } else { 'SUCCESS' })

# Reimportlijst genereren
$reimportList = @($mappings | Where-Object { $_.Status -match "✗|⚠" } | Select-Object CustomerName, VaultName, ExportRoot, Status, Errors)
if ($reimportList.Count -gt 0) {
    $reimportCsv = Join-Path $script:LogDir "reimport-list-$runStamp.csv"
    $reimportList | Export-Csv -LiteralPath $reimportCsv -NoTypeInformation -Encoding UTF8
    Write-Host "`nKlanten voor herimport:" -ForegroundColor Yellow
    $reimportList | ForEach-Object { Write-Host "  - $($_.CustomerName) [$($_.Status)]" }
    Write-Host "`nHerimprtlijst: $reimportCsv" -ForegroundColor Yellow
}

if ($script:RunErrors.Count -gt 0 -or $script:RunWarnings.Count -gt 0) {
    Write-Host ""
    Write-Host "WAARSCHUWINGEN EN FOUTEN TIJDENS RUN:" -ForegroundColor Yellow

    if ($script:RunErrors.Count -gt 0) {
        Write-Host "  ERROR ($($script:RunErrors.Count))" -ForegroundColor Red
        foreach ($msg in $script:RunErrors) {
            Write-Host "    - $msg" -ForegroundColor Red
        }
    }

    if ($script:RunWarnings.Count -gt 0) {
        Write-Host "  WARNING ($($script:RunWarnings.Count))" -ForegroundColor Yellow
        foreach ($msg in $script:RunWarnings) {
            Write-Host "    - $msg" -ForegroundColor Yellow
        }
    }
}

Write-Host ""
Write-Host "Script afgerond." -ForegroundColor Green
Write-Log "=== SCRIPT GESTOPT ==="
