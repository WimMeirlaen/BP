param(
    [string]$ExportRoot = "C:\\Temp\\Hydrex-Full",
    [string]$BaseRdmFolder = "OneNote Export"
)

Write-Host "Analyzing OneNote export at $ExportRoot" -ForegroundColor Cyan

function Compress-HtmlImagesPass {
    param(
        [Parameter(Mandatory)][string]$Html,
        [Parameter(Mandatory)][object]$JpegEncoder,
        [Parameter(Mandatory)][int]$MaxImageWidth,
        [Parameter(Mandatory)][int]$JpegQuality
    )

    $imagePattern = '(<img[^>]+src=")((data:image/[^;]+;base64,[^"]+))(")'
    $imgMatches = [regex]::Matches($Html, $imagePattern)
    if ($imgMatches.Count -eq 0) { return $Html }

    $encoderParams = New-Object System.Drawing.Imaging.EncoderParameters(1)
    $encoderParams.Param[0] = New-Object System.Drawing.Imaging.EncoderParameter(
        [System.Drawing.Imaging.Encoder]::Quality, [long]$JpegQuality)

    $result = $Html
    foreach ($match in $imgMatches) {
        $prefix     = $match.Groups[1].Value
        $base64Full = $match.Groups[2].Value
        $suffix     = $match.Groups[4].Value
        try {
            $base64Data = $base64Full -replace '^data:image/[^;]+;base64,', ''
            $imageBytes = [Convert]::FromBase64String($base64Data)
            $ms   = New-Object System.IO.MemoryStream($imageBytes, 0, $imageBytes.Length)
            $orig = [System.Drawing.Image]::FromStream($ms, $true)

            if ($orig.Width -le $MaxImageWidth) {
                $newW = $orig.Width; $newH = $orig.Height
            } else {
                $ratio = $MaxImageWidth / $orig.Width
                $newW  = $MaxImageWidth
                $newH  = [int]($orig.Height * $ratio)
            }

            $bmp = New-Object System.Drawing.Bitmap($newW, $newH)
            $g   = [System.Drawing.Graphics]::FromImage($bmp)
            $g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
            $g.DrawImage($orig, 0, 0, $newW, $newH)

            $outMs = New-Object System.IO.MemoryStream
            $bmp.Save($outMs, $JpegEncoder, $encoderParams)
            $newB64    = [Convert]::ToBase64String($outMs.ToArray())
            $newDataUri = "data:image/jpeg;base64,$newB64"

            $g.Dispose(); $bmp.Dispose(); $orig.Dispose(); $ms.Dispose(); $outMs.Dispose()

            $result = $result.Replace($match.Groups[0].Value, ($prefix + $newDataUri + $suffix))
        } catch { }
    }
    return $result
}

function Compress-HtmlImagesIfNeeded {
    param(
        [Parameter(Mandatory)][string]$HtmlFilePath,
        [int]$ThresholdMB = 20,
        [int]$LimitMB     = 25
    )

    $fileSizeMB = (Get-Item -LiteralPath $HtmlFilePath).Length / 1MB
    if ($fileSizeMB -le $ThresholdMB) { return }
            if (-not (Test-Path -LiteralPath $HtmlFilePath)) { return }
    Write-Host "    ⚠ page.rdm.html is $([math]::Round($fileSizeMB,1)) MB (> ${ThresholdMB} MB) - afbeeldingen comprimeren..." -ForegroundColor Yellow
    Write-Host "      Bestand: $HtmlFilePath" -ForegroundColor DarkGray

    try {
        Add-Type -AssemblyName System.Drawing -ErrorAction Stop
    } catch {
        Write-Warning "System.Drawing niet beschikbaar - compressie overgeslagen: $_"
        return
    }

    $jpegEncoder = [System.Drawing.Imaging.ImageCodecInfo]::GetImageEncoders() |
        Where-Object { $_.MimeType -eq 'image/jpeg' }

    # Compressiepassen: elke pass wordt strenger als het bestand nog te groot is
    $passes = @(
        @{ MaxWidth = 1600; Quality = 75; Label = 'pass 1 (1600px, 75%)' },
        @{ MaxWidth =  800; Quality = 50; Label = 'pass 2 (800px, 50%)'  },
        @{ MaxWidth =  600; Quality = 40; Label = 'pass 3 (600px, 40%)'  },
        @{ MaxWidth =  400; Quality = 25; Label = 'pass 4 (400px, 25%)'  }
    )

    $currentHtml = Get-Content -LiteralPath $HtmlFilePath -Raw -Encoding UTF8

    foreach ($pass in $passes) {
        $currentSizeMB = [System.Text.Encoding]::UTF8.GetByteCount($currentHtml) / 1MB
        if ($currentSizeMB -le $LimitMB) { break }

        Write-Host "    → $($pass.Label)..." -ForegroundColor Gray
        $currentHtml = Compress-HtmlImagesPass -Html $currentHtml -JpegEncoder $jpegEncoder `
            -MaxImageWidth $pass.MaxWidth -JpegQuality $pass.Quality

        $newSizeMB = [math]::Round([System.Text.Encoding]::UTF8.GetByteCount($currentHtml) / 1MB, 1)
        Write-Host "    ✓ Na $($pass.Label): $newSizeMB MB" -ForegroundColor $(if ($newSizeMB -le $LimitMB) { 'Green' } else { 'Yellow' })
    }

    $currentHtml | Set-Content -LiteralPath $HtmlFilePath -Encoding UTF8

    $finalSizeMB = [math]::Round((Get-Item -LiteralPath $HtmlFilePath).Length / 1MB, 1)

    # Laatste redmiddel: afbeeldingen verwijderen als alle passes onvoldoende waren
    if ($finalSizeMB -gt $LimitMB) {
        Write-Host "    ⚠ Nog steeds $finalSizeMB MB na alle compressiepassen - afbeeldingen verwijderen uit HTML..." -ForegroundColor Yellow
        $html2   = Get-Content -LiteralPath $HtmlFilePath -Raw -Encoding UTF8
        $stripped = [regex]::Replace(
            $html2,
            '(<img[^>]+src=")data:image/[^"]+(")',
            '$1data:image/gif;base64,R0lGODlhAQABAAD/ACwAAAAAAQABAAACADs=$2'
        )
        $notice  = '<div style="background:#fff3cd;border:1px solid #ffc107;padding:8px 12px;margin:8px 0;font-family:sans-serif;font-size:13px;">⚠ Afbeeldingen zijn verwijderd uit deze weergave omdat de pagina te groot was (&gt;25 MB). De originele afbeeldingen zijn beschikbaar als losse bijlagen in het tabblad <strong>Bijlagen</strong>.</div>'
        $stripped = [regex]::Replace($stripped, '(<body[^>]*>)', "`$1`n$notice", 1)
        $stripped | Set-Content -LiteralPath $HtmlFilePath -Encoding UTF8
        $finalSizeMB = [math]::Round((Get-Item -LiteralPath $HtmlFilePath).Length / 1MB, 1)
        Write-Host "    ✓ Afbeeldingen verwijderd: $finalSizeMB MB" -ForegroundColor Green
    }
}

function Get-MimeFromExt {
    param([string]$ext)
    switch ($ext.ToLowerInvariant()) {
        ".png"  { "image/png" }
        ".jpg"  { "image/jpeg" }
        ".jpeg" { "image/jpeg" }
        ".gif"  { "image/gif" }
        default { "application/octet-stream" }
    }
}

function Get-ImageMimeFromBytes {
    # Detect image type from magic bytes (first bytes of the file)
    param([byte[]]$Bytes)
    if (-not $Bytes -or $Bytes.Length -lt 4) { return $null }
    if ($Bytes[0] -eq 0xFF -and $Bytes[1] -eq 0xD8) { return "image/jpeg" }
    if ($Bytes[0] -eq 0x89 -and $Bytes[1] -eq 0x50 -and $Bytes[2] -eq 0x4E -and $Bytes[3] -eq 0x47) { return "image/png" }
    if ($Bytes[0] -eq 0x47 -and $Bytes[1] -eq 0x49 -and $Bytes[2] -eq 0x46) { return "image/gif" }
    return $null
}

function To-DataUri {
    param([Parameter(Mandatory)][string]$FullPath)
    $bytes = [System.IO.File]::ReadAllBytes($FullPath)
    $b64   = [Convert]::ToBase64String($bytes)
    $mime  = Get-MimeFromExt ([System.IO.Path]::GetExtension($FullPath))
    return "data:$mime;base64,$b64"
}

function To-DataDownloadLinkHtml {
    param(
        [Parameter(Mandatory)][string]$FullPath,
        [Parameter(Mandatory)][string]$DisplayName
    )
    $bytes = [System.IO.File]::ReadAllBytes($FullPath)
    $b64   = [Convert]::ToBase64String($bytes)
    $href  = "data:application/octet-stream;base64,$b64"
    return "<a href=`"$href`" download=`"$DisplayName`">📎 $DisplayName downloaden/openen</a>"
}

function Remove-OneNoteAttachmentsBlock {
    param([Parameter(Mandatory)][string]$Html)

    # Remove OneNote exported "Bijlagen" blocks
    $Html = [regex]::Replace(
        $Html,
        '(?is)<hr\s*/?>\s*<div[^>]*>\s*<h3>\s*Bijlagen\s*</h3>.*?</div>',
        ''
    )
    $Html = [regex]::Replace(
        $Html,
        '(?is)<(h[1-6]|p|div)[^>]*>\s*Bijlagen\s*</\1>\s*<ul[^>]*>.*?</ul>',
        ''
    )

    return $Html
}

function Get-AttrValue {
    param([string]$Tag, [string]$AttrName)
    $m = [regex]::Match($Tag, "(?is)\b$AttrName\s*=\s*([`"'])(.*?)\1")
    if ($m.Success) { return $m.Groups[2].Value }
    return $null
}

function Strip-Attrs {
    param([string]$Tag, [string[]]$Names)
    foreach ($n in $Names) {
        $Tag = [regex]::Replace($Tag, "(?is)\s$n\s*=\s*([`"']).*?\1", "")
    }
    return $Tag
}

function Force-Src {
    param([string]$Tag, [string]$NewSrc)
    $Tag = [regex]::Replace($Tag, "(?is)\ssrc\s*=\s*([`"']).*?\1", "")
    return [regex]::Replace($Tag, "(?is)<img", "<img src=`"$NewSrc`"", 1)
}

function Process-HtmlForRdm {
    param(
        [Parameter(Mandatory)][string]$Html,
        [Parameter(Mandatory)][string]$AttachmentsPath
    )

    $Html = Remove-OneNoteAttachmentsBlock -Html $Html

    # Safety: remove any CSS url(...bin...) to prevent viewer requests
    $Html = [regex]::Replace($Html, '(?is)url\([^)]+\.bin[^)]*\)', 'none')

    # Replace each <img ...> tag safely.
    # OneNote OCR alt text can contain raw " and ' characters (malformed HTML), which break any
    # attribute-aware regex. The reliable fix: match the full self-closing tag with .*?/>
    # (OneNote always emits self-closing img tags). Lazy .*? + (?s) spans newlines but stops at
    # the FIRST /> — which is the tag end, since OCR text contains > but virtually never />.
    $imgTagPattern = '(?is)<img\b.*?/>'
    $Html = [regex]::Replace($Html, $imgTagPattern, {
        param($m)
        $tag = $m.Value

        # If ANY attribute contains .bin, try magic bytes to embed as image; else show download link
        if ($tag -match '(?i)\.bin') {
            # Try to resolve the bin filename from common attributes
            $ref = Get-AttrValue $tag 'data-fullres-src'
            if ([string]::IsNullOrWhiteSpace($ref)) { $ref = Get-AttrValue $tag 'src' }
            if ([string]::IsNullOrWhiteSpace($ref)) { $ref = Get-AttrValue $tag 'data-cke-saved-src' }

            $leaf = 'inline.bin'
            if (-not [string]::IsNullOrWhiteSpace($ref)) {
                $refNorm = ($ref -replace '\\','/')
                $refNoQ  = ($refNorm -split '\?')[0]
                $leaf    = ($refNoQ -split '/')[-1]
            }
            if ($leaf -match '[\*\?\[\]]') {
                Write-Verbose "Skipping wildcard attachment reference: $refNoQ"
                return $tag
            }

            if (Test-Path -LiteralPath $AttachmentsPath) {
                $full = Join-Path $AttachmentsPath $leaf
                if (Test-Path -LiteralPath $full) {
                    $binBytes = [System.IO.File]::ReadAllBytes($full)
                    $imageMime = Get-ImageMimeFromBytes $binBytes
                    if ($imageMime) {
                        # Real image data in a .bin file - embed as base64 data URI
                        $b64 = [Convert]::ToBase64String($binBytes)
                        $dataUri = "data:$imageMime;base64,$b64"
                        $tag2 = Strip-Attrs $tag @('data-fullres-src','data-fullres-src-type','data-src-type','data-cke-saved-src')
                        $tag2 = Force-Src $tag2 $dataUri
                        return $tag2
                    }
                    # Not an image: embed as download link alleen als bestand <= 5 MB
                    $fileSizeBytes = (Get-Item -LiteralPath $full).Length
                    if ($fileSizeBytes -gt 5MB) {
                        $fileSizeMBLabel = [math]::Round($fileSizeBytes / 1MB, 1)
                        return "<div style=`"margin:6px 0;font-style:italic;color:#666;`">📎 Bijlage ($leaf, $fileSizeMBLabel MB) - beschikbaar in het tabblad <strong>Bijlagen</strong></div>"
                    }
                    $link = To-DataDownloadLinkHtml -FullPath $full -DisplayName $leaf
                    return "<div style=`"margin:6px 0;font-style:italic;color:#666;`">📎 Bijlage ($leaf)</div><div style=`"margin:4px 0;`">$link</div>"
                }
            }
            return "<div style=`"margin:6px 0;font-style:italic;color:#666;`">📎 Bijlage ($leaf)</div>"
        }

        # Normal images: embed only if src points to attachments/*.(png|jpg|jpeg|gif)
        $ref = Get-AttrValue $tag 'data-fullres-src'
        if ([string]::IsNullOrWhiteSpace($ref)) { $ref = Get-AttrValue $tag 'src' }
        if ([string]::IsNullOrWhiteSpace($ref)) { $ref = Get-AttrValue $tag 'data-cke-saved-src' }
        if ([string]::IsNullOrWhiteSpace($ref)) { return $tag }

        $refNorm = ($ref -replace '\\','/')
        $refNoQ  = ($refNorm -split '\?')[0]

        # Match images in attachments folder - handle various path formats:
        # - "attachments/img.png" (no prefix)
        # - "./attachments/img.png" (relative current)
        # - "../attachments/img.png" (relative parent)
        # - "/attachments/img.png" (absolute)
        if ($refNoQ -match '(?i)attachments/([^/]+\.(png|jpg|jpeg|gif))$') {
            if (Test-Path -LiteralPath $AttachmentsPath) {
                $leaf = $Matches[1]  # Extract just the filename (without path)
                $full = Join-Path $AttachmentsPath $leaf
                if (Test-Path -LiteralPath $full) {
                    try {
                        $dataUri = To-DataUri -FullPath $full
                        $tag2 = Strip-Attrs $tag @('data-fullres-src','data-fullres-src-type','data-src-type','data-cke-saved-src')
                        $tag2 = Force-Src $tag2 $dataUri
                        return $tag2
                    } catch {
                        Write-Verbose "Failed to embed image $leaf : $_"
                        return $tag
                    }
                } else {
                    Write-Verbose "Image file not found: $full"
                }
            }
        }

        # Fallback: bare filename of path/naar/filename — extraheer alleen de basename
        # Vangt <img src="img_565adc08.png"> op (geen attachments/ prefix)
        # en <img src="E-mail Security_files/img.png"> (OneNote _files-formaat)
        if ($refNoQ -match '(?i)([^/\\?#]+\.(png|jpg|jpeg|gif))$') {
            $leaf = $Matches[1]
                if ($leaf -match '[\*\?\[\]]') { return $tag }
            if (Test-Path -LiteralPath $AttachmentsPath) {
                $full = Join-Path $AttachmentsPath $leaf
                if (Test-Path -LiteralPath $full) {
                    try {
                        $dataUri = To-DataUri -FullPath $full
                        $tag2 = Strip-Attrs $tag @('data-fullres-src','data-fullres-src-type','data-src-type','data-cke-saved-src')
                        $tag2 = Force-Src $tag2 $dataUri
                        return $tag2
                    } catch {
                        Write-Verbose "Failed to embed image (fallback) $leaf : $_"
                    }
                }
            }
        }

        return $tag
    })

    # Embed non-image file attachments (zip, pdf, docx, msg, ...) als base64 download-link
    # Zo werken de links ook vanuit RDM (bestanden staan als attachment in de DB, niet op disk)
    # Pattern gebouwd via concatenatie om single-quote-in-single-quoted-string te vermijden
    $aTagPattern = '(?is)<a\b([^>]*)\bhref\s*=\s*([' + '"' + "'" + '])([^' + '"' + "'" + '?\r\n]+)\2([^>]*)>(.*?)</a>'
    $Html = [regex]::Replace($Html, $aTagPattern, {
        param($m)
        $href = ($m.Groups[3].Value -replace '\\','/').Trim()
        $inner = $m.Groups[5].Value

        # Laat echte web-/mail-links ongemoeid
        if ($href -match '^(?:https?|mailto|ftp|tel|#):?') { return $m.Value }

        # Haal bestandsnaam op uit de URL (zonder query)
        $leaf = ($href -split '/')[-1]
        $leaf = ($leaf -split '\?')[0]
        if ([string]::IsNullOrWhiteSpace($leaf)) { return $m.Value }

        # Zoek bestand in attachments-map van de pagina
        if (Test-Path -LiteralPath $AttachmentsPath) {
            $full = Join-Path $AttachmentsPath $leaf
            if (Test-Path -LiteralPath $full) {
                $fileSizeBytes = (Get-Item -LiteralPath $full).Length
                if ($fileSizeBytes -gt 5MB) {
                    $fileSizeMBLabel = [math]::Round($fileSizeBytes / 1MB, 1)
                    return "<span style=`"color:#555;font-style:italic;`">📎 $leaf ($fileSizeMBLabel MB) — beschikbaar in het tabblad <strong>Bijlagen</strong></span>"
                }
                return To-DataDownloadLinkHtml -FullPath $full -DisplayName $leaf
            }
        }

        # Bestand niet gevonden: toon placeholder (geen gebroken link)
        return "<span style=`"color:#888;font-style:italic;`">📎 $leaf (bijlage — zie RDM attachments)</span>"
    })

    # Fix table formatting: verwijder width attributen van table EN cellen
    # (OneNote kan enorm grote breedtes instellen die overflow veroorzaken)
    $Html = [regex]::Replace($Html, '(?i)(<table[^>]*?)\s+width\s*=\s*["''][^"'']*["'']', '$1')
    $Html = [regex]::Replace($Html, '(?i)(<td[^>]*?)\s+width\s*=\s*["''][^"'']*["'']', '$1')
    $Html = [regex]::Replace($Html, '(?i)(<th[^>]*?)\s+width\s*=\s*["''][^"'']*["'']', '$1')
    
    # Add CSS for better table formatting
    # Strategy: Use auto layout and let content determine widths naturally
    $tableStyleCss = @"
<style>
/* Better table formatting - prevent narrow first column issue */
table {
    table-layout: auto !important;
    width: 100% !important;
    max-width: 100% !important;
    border-collapse: collapse !important;
}

/* Ensure first column has reasonable minimum width */
table td:first-child, table th:first-child {
    min-width: 250px !important;
    width: auto !important;
}

/* All cells: proper padding and word wrapping */
table td, table th {
    padding: 8px 12px !important;
    vertical-align: top !important;
    word-wrap: break-word !important;
    overflow-wrap: break-word !important;
    white-space: normal !important;
}

/* Constrain images within table cells */
table td img, table th img {
    max-width: 100% !important;
    height: auto !important;
    display: block !important;
}
</style>
"@

    # Insert CSS before closing </head> or at start of <body> if no </head>
    if ($Html -match '(?i)</head>') {
        $Html = $Html -replace '(?i)(</head>)', "$tableStyleCss`$1"
    } elseif ($Html -match '(?i)<body') {
        $Html = $Html -replace '(?i)(<body[^>]*>)', "`$1$tableStyleCss"
    } else {
        # No head or body tag, prepend CSS
        $Html = $tableStyleCss + $Html
    }

    return $Html
}

$items = New-Object System.Collections.Generic.List[object]
$notebookName = Split-Path $ExportRoot -Leaf

Get-ChildItem -LiteralPath $ExportRoot -Directory | ForEach-Object {
    $section = $_
    $sectionName = $section.Name

    Get-ChildItem -LiteralPath $section.FullName -Directory -Recurse | ForEach-Object {
        $pageDir  = $_
        $pageName = $pageDir.Name
        $htmlPath = Join-Path $pageDir "page.html"
        if (-not (Test-Path -LiteralPath $htmlPath)) { return }

        # Hierarchy
        $relative = $pageDir.FullName.Substring($section.FullName.Length).TrimStart('\')
        $parentPath = if ($relative -like "*\*") { Split-Path $relative -Parent } else { $null }

        $hasChildren = @(
            Get-ChildItem -LiteralPath $pageDir.FullName -Directory -ErrorAction SilentlyContinue |
            Where-Object { Test-Path -LiteralPath (Join-Path $_.FullName "page.html") }
        ).Count -gt 0

        # Determine target folder and entry name
        # If page has children: create a FOLDER (Group) with page name, attachments go on that folder
        # If no children: create document entry in parent folder with page name
        # Either way: TargetFolder = parent path, SourcePage = page name
        $targetFolder = (( @($BaseRdmFolder, $sectionName, $parentPath) | Where-Object { $_ -and $_.Trim() -ne "" } ) -join "\")
        $entryName = $pageName

        # Attachments
        $attachmentsPath = Join-Path $pageDir "attachments"
        $attachmentPaths = @()
        if (Test-Path -LiteralPath $attachmentsPath) {
            $attachmentPaths = Get-ChildItem -LiteralPath $attachmentsPath -File -ErrorAction SilentlyContinue | ForEach-Object { $_.FullName }
        }

        # HTML -> page.rdm.html (always overwrite)
        $rdmHtmlPath = Join-Path $pageDir "page.rdm.html"
        $html = Get-Content -LiteralPath $htmlPath -Raw -Encoding UTF8
        $html = Process-HtmlForRdm -Html $html -AttachmentsPath $attachmentsPath
        # Bestaand bestand verwijderen zodat de huidige gebruiker eigenaar wordt.
        # Als Remove-Item faalt (andere eigenaar), eerst rechten herstellen via icacls.
        if (Test-Path -LiteralPath $rdmHtmlPath) {
            try {
                Remove-Item -LiteralPath $rdmHtmlPath -Force -ErrorAction Stop
            } catch {
                try {
                    $currentUser = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
                    & icacls $rdmHtmlPath /grant "${currentUser}:(F)" /c 2>&1 | Out-Null
                    Remove-Item -LiteralPath $rdmHtmlPath -Force -ErrorAction Stop
                } catch {
                    Write-Warning "Kan $rdmHtmlPath niet verwijderen: $_. Probeer als administrator te draaien of de map-rechten te corrigeren."
                }
            }
        }
        $html | Set-Content -LiteralPath $rdmHtmlPath -Encoding UTF8
        Compress-HtmlImagesIfNeeded -HtmlFilePath $rdmHtmlPath

        $items.Add([pscustomobject]@{
            Category        = 'GeneralComments'
            SourceNotebook  = $notebookName
            SourceSection   = $sectionName
            SourcePage      = $entryName
            TargetFolder    = $targetFolder
            HasChildren     = $hasChildren
            HTMLFilePath    = $rdmHtmlPath
            AttachmentPaths = $attachmentPaths
            Images          = @()
            MsgFiles        = @()
            Confidence      = 100
        })
    }
}

Write-Host "Analysis complete. Pages found: $($items.Count)" -ForegroundColor Green
return [pscustomobject]@{ CategorizedItems = $items }
