<#
.SYNOPSIS
    OneNote export met intelligente deduplicatie - Queue-compatible versie WITHOUT user prompts
    
.DESCRIPTION
    Dit script scant alle SharePoint sites van een klant (A-site, P-site, P-shared site)
    en detecteert duplicate pagina's op basis van SectionName + PageTitle.
    
    Voor duplicaten wordt alleen de nieuwste versie geëxporteerd, waardoor:
    - Export tijd significant vermindert
    - Geen dubbele informatie wordt gedownload
    - De meest actuele versie wordt bewaard
    
    BELANGRIJK:
    - Dit is de Queue-compatible versie - GEEN user prompts
    - Alle parameters moeten gegeven worden
    - Aangevinkt door Bulk-Export-OneNote-Queue.ps1
    
.PARAMETER CustomerSites
    Array van CSV site objects (met Title en Url properties)
    Pre-selected door queue script
    
.PARAMETER ExportPath
    Bestemmingsmap voor export (al bepaald door queue script)
    
.PARAMETER ClientId
    Entra app ID (default: onenote-bulk-export app)
    
.PARAMETER TenantId
    Azure tenant ID (default: ESC tenant)
    
.EXAMPLE
    $sites = @(
        @{Title="P-Acasa - MW documentation"; Url="https://..."},
        @{Title="P-Acasa - MW documentation-Shared"; Url="https://..."}
    )
    .\Export-OneNote-Deduplicated-Queue.ps1 -CustomerSites $sites -ExportPath "C:\Temp\Acasa"
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory)]
    [object[]]$CustomerSites,
    
    [Parameter(Mandatory)]
    [string]$ExportPath,
    
    [string]$ClientId = "3eb5d070-b60e-4d2b-97a9-1f775f2ea594",
    [string]$TenantId = "8e426d61-a69d-4927-8a3f-ef2f62da7f57",
    
    [string]$DefaultExportRoot = "C:\Temp",
    [switch]$SkipCleanup,
    [string]$ParentLogFile
)

# Schrijf naar het logbestand van de parent als dat meegegeven werd
function Write-ParentLog {
    param([string]$Message, [string]$Level = 'INFO')
    if ([string]::IsNullOrWhiteSpace($ParentLogFile)) { return }
    try {
        $ts = Get-Date -Format 'dd/MM/yyyy HH:mm:ss'
        "[$ts] [$Level] [export] $Message" | Add-Content -Path $ParentLogFile -Encoding UTF8
    } catch { }
}

# =========================
# BANNER
# =========================
Write-Host "`n╔══════════════════════════════════════════════════════════════╗" -ForegroundColor Cyan
Write-Host "║  ONENOTE EXPORT MET DEDUPLICATIE (QUEUE MODE - NO PROMPTS) ║" -ForegroundColor Cyan
Write-Host "║  Scant meerdere sites en exporteert alleen unieke pagina's ║" -ForegroundColor Cyan
Write-Host "╚══════════════════════════════════════════════════════════════╝`n" -ForegroundColor Cyan

# =========================
# LOAD COMMON FUNCTIONS
# =========================
$commonScript = Join-Path $PSScriptRoot "Common-OneNoteExport.ps1"
if (-not (Test-Path $commonScript)) {
    Write-Error "FOUT: Common-OneNoteExport.ps1 niet gevonden in $PSScriptRoot"
    Write-Error "Dit script vereist Common-OneNoteExport.ps1 voor throttling, HTTP en export functies."
    exit 1
}

Write-Host "Loading Common-OneNoteExport.ps1..." -ForegroundColor Gray
. $commonScript
Write-Host "✓ Common functions geladen`n" -ForegroundColor Green

# =========================
# SESSION FILE (persist refresh token between script invocations)
# BELANGRIJK: moet NA dot-source van Common-OneNoteExport.ps1 staan,
# anders worden de $script:OAuth* variabelen terug op $null gezet door de dot-source
# =========================
$script:SessionFile = Join-Path $env:TEMP "onenote-export-session-$($ClientId.Substring(0,8)).json"
if (Test-Path $script:SessionFile) {
    try {
        $savedSession = Get-Content $script:SessionFile -Raw -Encoding UTF8 | ConvertFrom-Json -ErrorAction Stop
        if ($savedSession.RefreshToken -and $savedSession.ClientId -eq $ClientId) {
            $script:OAuthRefreshToken = [string]$savedSession.RefreshToken
            $script:OAuthClientId    = [string]$savedSession.ClientId
            $script:OAuthTenantId    = [string]$savedSession.TenantId
            $script:OAuthScopeString = [string]$savedSession.ScopeString
        }
    } catch {
        # Session file corrupt or unreadable - ignore, will re-authenticate
    }
}

function Ensure-GraphPowerShellCommands {
    <#
    .SYNOPSIS
    Zorg dat vereiste Microsoft Graph cmdlets beschikbaar zijn (import/install indien nodig)
    #>
    [CmdletBinding()]
    param()

    $requiredCommands = @('Get-MgContext', 'Connect-MgGraph', 'Disconnect-MgGraph', 'Invoke-MgGraphRequest')
    $missing = @($requiredCommands | Where-Object { -not (Get-Command $_ -ErrorAction SilentlyContinue) })
    if ($missing.Count -eq 0) {
        return
    }

    Write-Host "Microsoft Graph cmdlets ontbreken: $($missing -join ', ')" -ForegroundColor Yellow
    Write-Host "→ Probeer Graph module te importeren..." -ForegroundColor Yellow

    $importSucceeded = $false
    try {
        Import-Module Microsoft.Graph.Authentication -ErrorAction Stop
        $importSucceeded = $true
    } catch {
        try {
            Import-Module Microsoft.Graph -ErrorAction Stop
            $importSucceeded = $true
        } catch {
            $importSucceeded = $false
        }
    }

    $missingAfterImport = @($requiredCommands | Where-Object { -not (Get-Command $_ -ErrorAction SilentlyContinue) })
    if ($missingAfterImport.Count -eq 0) {
        Write-Host "✓ Microsoft Graph module geïmporteerd" -ForegroundColor Green
        return
    }

    Write-Host "→ Probeer Microsoft.Graph.Authentication te installeren (CurrentUser)..." -ForegroundColor Yellow
    try {
        if (Get-Command Set-PSRepository -ErrorAction SilentlyContinue) {
            try { Set-PSRepository -Name PSGallery -InstallationPolicy Trusted -ErrorAction Stop } catch {}
        }

        Install-Module Microsoft.Graph.Authentication -Scope CurrentUser -Force -AllowClobber -Confirm:$false -ErrorAction Stop
        Import-Module Microsoft.Graph.Authentication -ErrorAction Stop
    } catch {
        throw "Microsoft Graph PowerShell ontbreekt en kon niet automatisch worden geïnstalleerd: $($_.Exception.Message)"
    }

    $missingAfterInstall = @($requiredCommands | Where-Object { -not (Get-Command $_ -ErrorAction SilentlyContinue) })
    if ($missingAfterInstall.Count -gt 0) {
        throw "Vereiste Graph cmdlets nog steeds niet beschikbaar: $($missingAfterInstall -join ', ')"
    }

    Write-Host "✓ Microsoft Graph cmdlets beschikbaar" -ForegroundColor Green
}

# Queue mode: geen initiële warmup cooldown (alleen throttle-gedreven pauzes)
$InitialCooldownSec = 0

# Queue mode: bij ELKE HTTP 429 direct 30 min pauze met aftelklok
$script:EnableHard429Cooldown = $true
$script:Hard429CooldownSec = 1800

$script:DiscoveryFailures = New-Object System.Collections.Generic.List[object]
$script:ThrottleCooldownSeconds = 1800

function Start-ThrottleCooldown {
    param(
        [string]$Reason = "HTTP 429 throttling"
    )

    $total = $script:ThrottleCooldownSeconds
    if (-not $total -or $total -lt 1) {
        $total = 1800
    }

    Write-Host "`n⏸️  Throttle cooldown gestart ($Reason)" -ForegroundColor Yellow
    Write-Host "   Pauze: $([math]::Round($total / 60, 1)) minuten" -ForegroundColor Yellow
    Write-ParentLog "Throttle cooldown gestart: $Reason ($([math]::Round($total/60,1)) min)" 'WARN'

    for ($remaining = $total; $remaining -gt 0; $remaining--) {
        $ts = [timespan]::FromSeconds($remaining)
        $timerText = "{0:D2}:{1:D2}:{2:D2}" -f $ts.Hours, $ts.Minutes, $ts.Seconds
        $pct = [int](($total - $remaining) / $total * 100)
        Write-Progress -Activity "⏸️  Throttle cooldown ($Reason)" -Status "Hervat over: $timerText" -PercentComplete $pct
        if ($remaining % 300 -eq 0 -and $remaining -lt $total) {
            Write-ParentLog "Throttle cooldown actief - nog $([math]::Round($remaining/60,1)) min" 'INFO'
        }
        Start-Sleep -Seconds 1
    }
    Write-Progress -Activity "⏸️  Throttle cooldown ($Reason)" -Completed

    Write-Host "✓ Cooldown voltooid, Graph calls worden hervat`n" -ForegroundColor Green
    Write-ParentLog "Throttle cooldown voltooid" 'INFO'
}

function Test-IsThrottleError {
    param([string]$Message)

    if ([string]::IsNullOrWhiteSpace($Message)) { return $false }
    return ($Message -match '429|TooManyRequests|too many retries performed|throttle|"code"\s*:\s*"20166"')
}

function Invoke-GraphRequestWithThrottleCooldown {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Uri,
        [string]$Method = 'GET',
        [string]$Operation = 'Graph request'
    )

    $attempt = 0
    while ($true) {
        $attempt++
        try {
            # Use Invoke-GraphHttp (has 120s timeout) instead of Invoke-MgGraphRequest (no timeout)
            $result = Invoke-GraphHttp -Method $Method -Uri $Uri
            if ($result.Skipped) {
                throw "Graph request mislukt ($($result.SkipReason)): $Uri"
            }
            if ($result.Response -and $result.Response.ContentText) {
                return $result.Response.ContentText | ConvertFrom-Json
            }
            return $null
        } catch {
            $message = $_.Exception.Message
            if ($message -match 'timed out|TaskCanceledException|OperationCanceledException') {
                Write-Warning "$Operation timed out (attempt $attempt) - opnieuw proberen na 30s..."
                Start-Sleep -Seconds 30
                continue
            }
            if (Test-IsThrottleError -Message $message) {
                Write-Warning "$Operation throttled (attempt $attempt). 30 min cooldown en daarna opnieuw proberen..."
                Start-ThrottleCooldown -Reason "$Operation (TooManyRequests/429)"
                continue
            }
            throw
        }
    }
}

# =========================
# DEDUPLICATIE LOGICA
# =========================

function Get-AllSectionsRecursive {
    param(
        [Parameter(Mandatory)][string]$SiteId,
        [Parameter(Mandatory)][string]$NotebookId,
        [string]$SectionGroupId = $null
    )
    
    $allSections = @()
    
    # Get direct sections of notebook or section group
    if ($SectionGroupId) {
        $sectionsUri = "https://graph.microsoft.com/v1.0/sites/$SiteId/onenote/sectionGroups/$SectionGroupId/sections"
    } else {
        $sectionsUri = "https://graph.microsoft.com/v1.0/sites/$SiteId/onenote/notebooks/$NotebookId/sections"
    }
    
    try {
        $response = Invoke-GraphRequestWithThrottleCooldown -Method GET -Uri $sectionsUri -Operation "Sections ophalen"
        if ($response.value) {
            $allSections += $response.value
        }
        Start-Sleep -Milliseconds 500
    } catch {
        Write-Warning "Could not fetch sections ($sectionsUri): $($_.Exception.Message)"
    }
    
    # Get nested section groups and recurse
    if ($SectionGroupId) {
        $groupsUri = "https://graph.microsoft.com/v1.0/sites/$SiteId/onenote/sectionGroups/$SectionGroupId/sectionGroups"
    } else {
        $groupsUri = "https://graph.microsoft.com/v1.0/sites/$SiteId/onenote/notebooks/$NotebookId/sectionGroups"
    }
    
    try {
        $grResponse = Invoke-GraphRequestWithThrottleCooldown -Method GET -Uri $groupsUri -Operation "Section groups ophalen"
        if ($grResponse.value) {
            foreach ($grp in $grResponse.value) {
                Start-Sleep -Milliseconds 500
                $nestedSections = Get-AllSectionsRecursive -SiteId $SiteId -NotebookId $NotebookId -SectionGroupId $grp.id
                $allSections += $nestedSections
            }
        }
        Start-Sleep -Milliseconds 500
    } catch {
        Write-Warning "Could not fetch section groups ($groupsUri): $($_.Exception.Message)"
    }
    
    return $allSections
}

function Get-AllPagesFromSite {
    param(
        [Parameter(Mandatory)]
        [string]$SiteUrl,
        [Parameter(Mandatory)]
        [string]$SiteName
    )
    
    Write-Host "📍 Scannen: $SiteName" -ForegroundColor Yellow
    
    $allPages = @()
    
    # Step 1: Resolve site ID from URL
    $siteResolveUris = @()
    try {
        $siteUri = [uri]$SiteUrl
        $hostName = $siteUri.Host
        $serverRelativePath = $siteUri.AbsolutePath.TrimEnd('/')

        if ([string]::IsNullOrWhiteSpace($serverRelativePath)) {
            $serverRelativePath = "/"
        }

        # Preferred: resolve directly by hostname + server-relative path (no site enumeration)
        if ($serverRelativePath -eq "/") {
            $siteResolveUris += "https://graph.microsoft.com/v1.0/sites/$hostName"
        } else {
            $siteResolveUris += "https://graph.microsoft.com/v1.0/sites/${hostName}:${serverRelativePath}"
            $siteResolveUris += "https://graph.microsoft.com/v1.0/sites/${hostName}:${serverRelativePath}:"
        }
    } catch {
        Write-Warning "   ⚠️  Ongeldige SiteUrl '$SiteUrl', probeer fallback resolutie"
    }

    # Legacy fallback (some tenants still allow this)
    $siteResolveUris += "https://graph.microsoft.com/v1.0/sites?`$filter=webUrl eq '$SiteUrl'"
    
    try {
        $siteResponse = $null
        $lastResolveError = $null
        foreach ($resolveUri in $siteResolveUris) {
            try {
                $siteResponse = Invoke-GraphRequestWithThrottleCooldown -Method GET -Uri $resolveUri -Operation "Site resolve"
                if ($siteResponse) {
                    break
                }
            } catch {
                $lastResolveError = $_.Exception.Message
                continue
            }
        }

        if (-not $siteResponse) {
            if ($lastResolveError) {
                throw "Kon SiteId niet resolven via Graph URL resolvers. Laatste fout: $lastResolveError"
            }
            throw "Kon SiteId niet resolven via Graph URL resolvers"
        }

        # Response can be direct site object OR collection with value[]
        if ($siteResponse.id) {
            $siteId = $siteResponse.id
        } elseif ($siteResponse.value -and $siteResponse.value.Count -gt 0) {
            $siteId = $siteResponse.value[0].id
        } else {
            Write-Warning "   ✗ Site not found: $SiteUrl"
            $script:DiscoveryFailures.Add(@{SiteName=$SiteName; Reason="Site not found"})
            return $allPages
        }

        Write-Host "   ✓ Site resolved: $siteId" -ForegroundColor Gray
        Start-Sleep -Milliseconds 500
    } catch {
        Write-Warning "   ✗ Kan site niet vinden: $_"
        $script:DiscoveryFailures.Add(@{SiteName=$SiteName; Reason="$($_.Exception.Message)"})
        return $allPages
    }
    
    # Step 2: Get all notebooks
    $notebooksUri = "https://graph.microsoft.com/v1.0/sites/$siteId/onenote/notebooks"
    
    $notebooks = @()
    try {
        $nbResponse = Invoke-GraphRequestWithThrottleCooldown -Method GET -Uri $notebooksUri -Operation "Notebooks ophalen voor '$SiteName'"
        $notebooks = $nbResponse.value
        Write-Host "   ✓ Gevonden: $($notebooks.Count) notebooks" -ForegroundColor Gray
        Start-Sleep -Milliseconds 500
    } catch {
        Write-Warning "   ✗ Kan notebooks niet ophalen: $_"
        $script:DiscoveryFailures.Add(@{SiteName=$SiteName; Reason="Cannot fetch notebooks - $_"})
        return $allPages
    }
    
    if ($notebooks.Count -eq 0) {
        Write-Host "   ⚠️  Geen notebooks gevonden" -ForegroundColor Yellow
        return $allPages
    }
    
    # Step 3: For each notebook, get all sections and pages
    foreach ($notebook in $notebooks) {
        $notebookName = $notebook.displayName
        Write-Host "     📓 Notebook: $notebookName" -ForegroundColor Gray
        
        $sections = Get-AllSectionsRecursive -SiteId $siteId -NotebookId $notebook.id
        if ($sections.Count -eq 0) {
            Write-Host "       (Geen secties)" -ForegroundColor DarkGray
            continue
        }
        
        foreach ($section in $sections) {
            $sectionName = $section.displayName

            try {
                $pages = @(Get-SectionPagesRobust -ResolvedSiteId $siteId -SectionId $section.id)

                if ($pages.Count -gt 0) {
                    Write-Host "       📋 Section: $sectionName ($($pages.Count) pages)" -ForegroundColor Gray

                    foreach ($page in $pages) {
                        $allPages += [PSCustomObject]@{
                            SiteId = $siteId
                            SiteName = $SiteName
                            SiteUrl = $SiteUrl
                            NotebookId = $notebook.id
                            NotebookName = $notebookName
                            SectionId = $section.id
                            SectionName = $sectionName
                            PageId = $page.id
                            PageTitle = $page.title
                            LastModifiedDateTime = if ($page.lastModifiedDateTime) { $page.lastModifiedDateTime } else { [datetime]::MinValue }
                            Level = if ($page.level) { $page.level } else { 0 }
                            Order = if ($page.order) { $page.order } else { 0 }
                        }
                    }
                }

                Start-Sleep -Milliseconds 500
            } catch {
                if ($_.Exception.Message -match '429|throttle') {
                    Write-Warning "       Throttled bij ophalen section pages"
                    Start-ThrottleCooldown -Reason "Section pages ophalen (429)"
                    try {
                        $pages = @(Get-SectionPagesRobust -ResolvedSiteId $siteId -SectionId $section.id)
                        if ($pages.Count -gt 0) {
                            foreach ($page in $pages) {
                                $allPages += [PSCustomObject]@{
                                    SiteId = $siteId
                                    SiteName = $SiteName
                                    SiteUrl = $SiteUrl
                                    NotebookId = $notebook.id
                                    NotebookName = $notebookName
                                    SectionId = $section.id
                                    SectionName = $sectionName
                                    PageId = $page.id
                                    PageTitle = $page.title
                                    LastModifiedDateTime = if ($page.lastModifiedDateTime) { $page.lastModifiedDateTime } else { [datetime]::MinValue }
                                    Level = if ($page.level) { $page.level } else { 0 }
                                    Order = if ($page.order) { $page.order } else { 0 }
                                }
                            }
                        }
                    } catch {
                        Write-Warning "       Kan pages niet ophalen na retry"
                    }
                } else {
                    Write-Warning "       Kan pages niet ophalen: $_"
                }
            }
        }
    }
    
    Write-Host "   ✓ Totaal: $($allPages.Count) pagina's gevonden" -ForegroundColor Green
    
    return $allPages
}

function Build-DeduplicationIndex {
    param(
        [Parameter(Mandatory)]
        [object[]]$AllPages
    )
    
    $index = @{}
    
    foreach ($page in $AllPages) {
        # Key = SectionName|PageTitle (section-specific deduplication)
        $key = "$($page.SectionName)|$($page.PageTitle)"
        
        if (-not $index.ContainsKey($key)) {
            $index[$key] = @()
        }
        
        $index[$key] += $page
    }
    
    Write-Host "   Deduplicatie index gebouwd:" -ForegroundColor Gray
    Write-Host "     - Totale pagina's: $($AllPages.Count)" -ForegroundColor Gray
    Write-Host "     - Unieke combinaties: $($index.Count)" -ForegroundColor Gray
    Write-Host "     - Duplicaten: $($AllPages.Count - $index.Count)" -ForegroundColor Gray
    Write-Host ""
    
    return $index
}

function Select-NewestPages {
    param(
        [Parameter(Mandatory)]
        [hashtable]$DeduplicationIndex
    )
    
    $selectedPages = @()
    $metadata = @()
    
    foreach ($key in $DeduplicationIndex.Keys) {
        $pages = $DeduplicationIndex[$key]
        
        # Sort by LastModifiedDateTime (most recent first)
        $sorted = $pages | Sort-Object { [datetime]$_.LastModifiedDateTime } -Descending
        $newest = $sorted[0]
        $selectedPages += $newest
        
        if ($sorted.Count -gt 1) {
            $alternates = ($sorted[1..($sorted.Count-1)] | ForEach-Object { $_.SiteName }) -join "; "

            $metadata += [PSCustomObject]@{
                PageTitle = $newest.PageTitle
                SectionName = $newest.SectionName
                NotebookName = $newest.NotebookName
                SelectedSite = $newest.SiteName
                SelectedSiteUrl = $newest.SiteUrl
                LastModified = $newest.LastModifiedDateTime
                DuplicateCount = $pages.Count
                AlternateSites = $alternates
            }
            
            Write-Host "  ⚡ $($newest.SectionName) > $($newest.PageTitle)" -ForegroundColor DarkGray
            Write-Host "     └─ Nieuwste: $($newest.SiteName) ($($newest.LastModifiedDateTime))" -ForegroundColor DarkGray
        } else {
            $metadata += [PSCustomObject]@{
                PageTitle = $newest.PageTitle
                SectionName = $newest.SectionName
                NotebookName = $newest.NotebookName
                SelectedSite = $newest.SiteName
                SelectedSiteUrl = $newest.SiteUrl
                LastModified = $newest.LastModifiedDateTime
                DuplicateCount = 1
                AlternateSites = ""
            }
        }
    }
    
    Write-Host "✓ $($selectedPages.Count) pagina's geselecteerd voor export`n" -ForegroundColor Green
    
    return @{
        Pages = $selectedPages
        Metadata = $metadata
    }
}

function Connect-MgGraphExplicitDeviceCode {
    <#
    .SYNOPSIS
    Betrouwbare device-code login via OAuth endpoints met zichtbare code in console
    #>
    param(
        [Parameter(Mandatory)][string]$ClientId,
        [Parameter(Mandatory)][string]$TenantId
    )

    $scopeString = "https://graph.microsoft.com/Sites.Read.All https://graph.microsoft.com/Notes.Read.All offline_access"
    $deviceCodeEndpoint = "https://login.microsoftonline.com/$TenantId/oauth2/v2.0/devicecode"
    $tokenEndpoint = "https://login.microsoftonline.com/$TenantId/oauth2/v2.0/token"

    Write-Host "→ Device code aanvragen..." -ForegroundColor Yellow

    $deviceCodeResponse = Invoke-RestMethod -Method Post `
                                            -Uri $deviceCodeEndpoint `
                                            -ContentType "application/x-www-form-urlencoded" `
                                            -Body @{
                                                client_id = $ClientId
                                                scope = $scopeString
                                            } `
                                            -ErrorAction Stop

    Write-Host "`n════════ DEVICE CODE ════════" -ForegroundColor Cyan
    Write-Host "Code: $($deviceCodeResponse.user_code)" -ForegroundColor Green
    Write-Host "URL : $($deviceCodeResponse.verification_uri)" -ForegroundColor Cyan
    Write-Host "Open deze URL en voer de code in." -ForegroundColor Cyan
    Write-Host "══════════════════════════════`n" -ForegroundColor Cyan

    try {
        Start-Process $deviceCodeResponse.verification_uri | Out-Null
    } catch {
        Write-Warning "Kon browser niet automatisch openen. Open de URL handmatig."
    }

    $interval = [Math]::Max(2, [int]$deviceCodeResponse.interval)
    $expiresAt = (Get-Date).AddSeconds([int]$deviceCodeResponse.expires_in)
    $tokenResponse = $null

    while ((Get-Date) -lt $expiresAt) {
        Start-Sleep -Seconds $interval

        try {
            $tokenResponse = Invoke-RestMethod -Method Post `
                                               -Uri $tokenEndpoint `
                                               -ContentType "application/x-www-form-urlencoded" `
                                               -Body @{
                                                   grant_type = "urn:ietf:params:oauth:grant-type:device_code"
                                                   client_id = $ClientId
                                                   device_code = $deviceCodeResponse.device_code
                                               } `
                                               -ErrorAction Stop
            if ($tokenResponse.access_token) {
                break
            }
        } catch {
            $errorCode = $null
            try {
                if ($_.ErrorDetails.Message) {
                    $oauthError = $_.ErrorDetails.Message | ConvertFrom-Json -ErrorAction Stop
                    $errorCode = $oauthError.error
                }
            } catch {
                $errorCode = $null
            }

            switch ($errorCode) {
                "authorization_pending" { continue }
                "slow_down" { $interval += 5; continue }
                "authorization_declined" { throw "Login geweigerd door gebruiker" }
                "expired_token" { throw "Device code verlopen" }
                default {
                    throw "OAuth token fout: $($_.Exception.Message)"
                }
            }
        }
    }

    if (-not $tokenResponse -or -not $tokenResponse.access_token) {
        throw "Geen access token ontvangen binnen geldige device-code periode"
    }

    # Persist OAuth session for long-running exports (auto refresh without user interaction)
    $script:OAuthClientId = $ClientId
    $script:OAuthTenantId = $TenantId
    $script:OAuthScopeString = $scopeString
    $script:OAuthRefreshToken = if ($tokenResponse.refresh_token) { [string]$tokenResponse.refresh_token } else { $null }
    $script:BearerToken = [string]$tokenResponse.access_token

    # Save session to file so subsequent script invocations can skip device code login
    if ($script:OAuthRefreshToken -and $script:SessionFile) {
        try {
            @{
                RefreshToken = $script:OAuthRefreshToken
                ClientId     = $ClientId
                TenantId     = $TenantId
                ScopeString  = $scopeString
                SavedAt      = [DateTime]::UtcNow.ToString("o")
            } | ConvertTo-Json | Set-Content -Path $script:SessionFile -Encoding UTF8 -Force
        } catch {
            Write-Warning "Kon sessie niet opslaan naar bestand: $_"
        }
    }
    $expiresIn = 3600
    if ($tokenResponse.expires_in) {
        try { $expiresIn = [int]$tokenResponse.expires_in } catch { $expiresIn = 3600 }
    }
    $script:TokenExpiresAt = [DateTime]::UtcNow.AddSeconds([Math]::Max(120, $expiresIn - 120))

    $secureAccessToken = ConvertTo-SecureString $tokenResponse.access_token -AsPlainText -Force
    Connect-MgGraph -AccessToken $secureAccessToken -NoWelcome -ErrorAction Stop

    # Verify with a lightweight Graph call requiring Sites.Read.All
    Invoke-GraphRequestWithThrottleCooldown -Method GET -Uri "https://graph.microsoft.com/v1.0/sites/root?`$select=id" -Operation "Graph context verify na login" | Out-Null
}

# =========================
# MAIN EXECUTION
# =========================

Write-Host "PARAMETERS:"
Write-Host "  Export directory: $ExportPath" -ForegroundColor Cyan
Write-Host "  Customer sites: $($CustomerSites.Count)" -ForegroundColor Cyan
foreach ($site in $CustomerSites) {
    Write-Host "    • $($site.Title)" -ForegroundColor Gray
}
Write-Host ""

# Create export directory if not exists
New-Item -ItemType Directory -Path $ExportPath -Force | Out-Null

# STAP 1: Connect to Graph
Write-Host "Verbinden met Microsoft Graph..." -ForegroundColor Yellow

Ensure-GraphPowerShellCommands

$context = Get-MgContext

$hasCorrectApp = $context -and $context.ClientId -eq $ClientId
$hasCorrectScopes = $context -and ($context.Scopes -contains "Sites.Read.All") -and ($context.Scopes -contains "Notes.Read.All")
$hasDurableRefreshSession = -not [string]::IsNullOrWhiteSpace($script:OAuthRefreshToken)

$contextUsable = $false
if ($hasCorrectApp -and $hasCorrectScopes) {
    try {
        Invoke-GraphRequestWithThrottleCooldown -Method GET -Uri "https://graph.microsoft.com/v1.0/sites/root?`$select=id" -Operation "Graph context verify bestaande sessie" | Out-Null
        $contextUsable = $true
    } catch {
        Write-Warning "Bestaande Graph sessie is niet bruikbaar: $($_.Exception.Message)"
        $contextUsable = $false
    }
}

if ($hasCorrectApp -and $hasCorrectScopes -and $contextUsable -and $hasDurableRefreshSession) {
    Write-Host "✓ Reeds ingelogd als: $($context.Account)" -ForegroundColor Green
    Write-Host "  App: onenote-bulk-export" -ForegroundColor DarkGray
    Write-Host "  Scopes: Sites.Read.All, Notes.Read.All" -ForegroundColor DarkGray
    Write-Host "  Sessie: refresh-token beschikbaar" -ForegroundColor DarkGray
} else {
    if ($hasCorrectApp -and $hasCorrectScopes -and $contextUsable -and -not $hasDurableRefreshSession) {
        Write-Host "⚠️  Bestaande Graph context heeft geen refresh-token sessie." -ForegroundColor Yellow
        Write-Host "    Voor lange queue-runs wordt opnieuw aangemeld via device code (duurzame sessie)." -ForegroundColor Yellow
    }

    # Disconnect any existing session
    if ($context -and (-not $hasCorrectApp -or -not $hasCorrectScopes -or -not $contextUsable -or -not $hasDurableRefreshSession)) {
        Write-Host "⚠️  Graph sessie wordt vernieuwd (app/scopes/context/refresh-token check)." -ForegroundColor Yellow
        Disconnect-MgGraph | Out-Null
        Start-Sleep -Seconds 2
    }
    
    Write-Host "`nInloggen met custom Entra app (onenote-bulk-export)..." -ForegroundColor Yellow
    Write-Host "  ClientId: $ClientId" -ForegroundColor DarkGray
    Write-Host "  TenantId: $TenantId" -ForegroundColor DarkGray
    Write-Host ""
    
    try {
        Connect-MgGraphExplicitDeviceCode -ClientId $ClientId -TenantId $TenantId
        
        # Verify the connection
        $newContext = Get-MgContext
        if (-not $newContext) {
            throw "Connectie mislukt - geen Graph context"
        }
        
        Write-Host "`n✓ Succesvol ingelogd als: $($newContext.Account)" -ForegroundColor Green
    } catch {
        Write-Error "Kan niet verbinden met Microsoft Graph: $($_.Exception.Message)"
        Write-Host "`nProbeer handmatig:" -ForegroundColor Yellow
        Write-Host "  Disconnect-MgGraph" -ForegroundColor Cyan
        Write-Host "  Connect-MgGraph -ClientId '$ClientId' -TenantId '$TenantId' -Scopes 'Sites.Read.All','Notes.Read.All' -UseDeviceCode`n" -ForegroundColor Cyan
        exit 1
    }
}
Write-Host ""

# STAP 2: Scan alle sites
Write-Host "═══════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host "FASE 1: DISCOVERY - Scannen van alle sites" -ForegroundColor Cyan
Write-Host "═══════════════════════════════════════════════════`n" -ForegroundColor Cyan

Write-Host "Start discovery zonder initiële cooldown`n" -ForegroundColor Gray

$allPagesFromAllSites = @()

foreach ($site in $CustomerSites) {
    $pages = Get-AllPagesFromSite -SiteUrl $site.Url -SiteName $site.Title
    $allPagesFromAllSites += $pages

    $siteDiscoveryError = $script:DiscoveryFailures | Where-Object { $_.SiteName -eq $site.Title } | Select-Object -Last 1
    if ($siteDiscoveryError) {
        Write-Warning "  ✗ Site discovery niet volledig voor '$($site.Title)': $($siteDiscoveryError.Reason)"
    } else {
        Write-Host "  ✓ Site voltooid - cooldown 5s voor volgende site..." -ForegroundColor DarkGray
    }
    Start-Sleep -Seconds 5
    Write-Host ""
}

if ($allPagesFromAllSites.Count -eq 0) {
    Write-Error "Geen pagina's gevonden om te exporteren. Discovery is mislukt of volledig gethrottled."
    if ($script:DiscoveryFailures.Count -gt 0) {
        Write-Host "Discovery failures:" -ForegroundColor Yellow
        foreach ($f in $script:DiscoveryFailures) {
            Write-Host "  - $($f.SiteName): $($f.Reason)" -ForegroundColor Yellow
        }
    }
    exit 1
}

# STAP 3: Deduplicatie
Write-Host "═══════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host "FASE 2: DEDUPLICATIE ANALYSE" -ForegroundColor Cyan
Write-Host "═══════════════════════════════════════════════════`n" -ForegroundColor Cyan

$deduplicationIndex = Build-DeduplicationIndex -AllPages $allPagesFromAllSites
$selectionResult = Select-NewestPages -DeduplicationIndex $deduplicationIndex

$selectedPages = $selectionResult.Pages
$metadata = $selectionResult.Metadata

# Save metadata
$metadataPath = Join-Path $ExportPath "deduplication-metadata.csv"
$metadata | Export-Csv -Path $metadataPath -NoTypeInformation -Encoding UTF8
Write-Host "✓ Metadata opgeslagen: $metadataPath`n" -ForegroundColor Green

# STAP 4: Hierarchical Export
Write-Host "═══════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host "FASE 3: EXPORT MET HIERARCHIE" -ForegroundColor Cyan
Write-Host "═══════════════════════════════════════════════════`n" -ForegroundColor Cyan

$firstSiteId = ($selectedPages | Select-Object -First 1).SiteId
if ($firstSiteId) {
    Write-Host "Warmup phase voor throttle protection..." -ForegroundColor Yellow
    Warmup -ResolvedSiteId $firstSiteId
    Write-Host ""
}

Write-Host "Start hierarchical export van $($selectedPages.Count) dedupl pagina's...`n" -ForegroundColor Yellow

# =========================
# ADD PARENT PAGES
# =========================
Write-Host "Parent pages toevoegen voor hierarchy..." -ForegroundColor Yellow

$allPagesMap = @{}
foreach ($p in $allPagesFromAllSites) {
    $key = "$($p.SiteId)|$($p.SectionId)|$($p.PageId)"
    $allPagesMap[$key] = $p
}

$parentPagesToAdd = @{}
foreach ($page in $selectedPages) {
    if ($page.Level -gt 0) {
        $sectionPages = $allPagesFromAllSites | Where-Object { 
            $_.SiteId -eq $page.SiteId -and 
            $_.SectionId -eq $page.SectionId 
        } | Sort-Object Level, Order
        
        foreach ($potentialParent in $sectionPages) {
            # Only consider potential parents that appear BEFORE the child in the section order
            if ($potentialParent.Level -lt $page.Level -and $potentialParent.Order -lt $page.Order) {
                $parentKey = "$($potentialParent.SiteId)|$($potentialParent.SectionId)|$($potentialParent.PageId)"
                if (-not $parentPagesToAdd.ContainsKey($parentKey)) {
                    $parentPagesToAdd[$parentKey] = $potentialParent
                }
            }
        }
    }
}

$originalCount = $selectedPages.Count
foreach ($parentPage in $parentPagesToAdd.Values) {
    $key = "$($parentPage.SiteId)|$($parentPage.SectionId)|$($parentPage.PageId)"
    if (-not ($selectedPages | Where-Object { 
        $_.SiteId -eq $parentPage.SiteId -and 
        $_.SectionId -eq $parentPage.SectionId -and 
        $_.PageId -eq $parentPage.PageId 
    })) {
        $selectedPages += $parentPage
    }
}

if ($selectedPages.Count -gt $originalCount) {
    Write-Host "  ✓ $($selectedPages.Count - $originalCount) parent pages toegevoegd" -ForegroundColor Green
} else {
    Write-Host "  ✓ Geen extra parent pages nodig" -ForegroundColor Green
}

# CRITICAL FIX: Re-sort pages by Section and original Order so pages follow natural section order
# Force parents to appear before children within each section.
# Build map of parent pages per section
$parentPerSection = @{}
foreach ($pp in $parentPagesToAdd.Values) {
    $secKey = "{0}|{1}" -f $pp.SiteId, $pp.SectionId
    if (-not $parentPerSection.ContainsKey($secKey)) { $parentPerSection[$secKey] = @() }
    $parentPerSection[$secKey] += $pp
}

# Reorder selected pages per section: parents (forced) first, then remaining pages by original order
$newSelected = @()
$sections = $selectedPages | Group-Object SiteId, SectionId
foreach ($grp in $sections) {
    $siteId = $grp.Group[0].SiteId
    $sectionId = $grp.Group[0].SectionId
    $secKey = "{0}|{1}" -f $siteId, $sectionId

    $parents = @()
    if ($parentPerSection.ContainsKey($secKey)) {
        $parents = $parentPerSection[$secKey] | Sort-Object {[int]($_.Order ?? 0)}
    }

    $others = $grp.Group | Where-Object { $p = $_; -not ($parents | Where-Object { $_.PageId -eq $p.PageId }) } | Sort-Object {[int]($_.Order ?? 0)}

    $newSelected += $parents
    $newSelected += $others
}

$selectedPages = $newSelected

# CRITICAL: Sort ALL pages globally by Level first (L0 before L1, L1 before L2)
# This ensures parents ALWAYS appear before children, regardless of selection order
$selectedPages = $selectedPages | Sort-Object { [int]($_.Level ?? 0) }, { [int]($_.Order ?? 0) }
Write-Host "  ✓ Pages reordered: parents forced before children per section, and globally by level" -ForegroundColor Green

# Create hashtable for fast lookup
$selectedPageIds = @{}
foreach ($p in $selectedPages) {
    $selectedPageIds["$($p.SiteId)|$($p.SectionId)|$($p.PageId)"] = $p
}

# Reset export counter
$script:ExportedPageCount = 0

# =========================
# DETECT BULK EXPORT & OPTIMIZE THROTTLING
# =========================
$totalPagesToExport = $selectedPages.Count
if ($totalPagesToExport -ge 100) {
    Write-Host "`n⚠️  BULK EXPORT DETECTED: $totalPagesToExport pagina's" -ForegroundColor Yellow
    Write-Host "    → Verhoogde throttling delays worden gebruikt" -ForegroundColor Yellow
    Write-Host "    → Page delay: ${ExtraDelayBetweenPagesMs}ms" -ForegroundColor Gray
    if ($InitialCooldownSec -gt 0) {
        Write-Host "    → Initial cooldown: ${InitialCooldownSec}s" -ForegroundColor Gray
    } else {
        Write-Host "    → Initial cooldown: uitgeschakeld (queue mode)" -ForegroundColor Gray
    }
    Write-Host "    → Ultra-conservative mode wordt automatisch geactiveerd na 3x HTTP 429`n" -ForegroundColor Gray
} else {
    Write-Host "`n✓ Normale export: $totalPagesToExport pagina's`n" -ForegroundColor Green
}

# =========================
# EXPORT PER NOTEBOOK FOLDER
# =========================
Write-Host "`nExporteren notebooks met intelligente merge..." -ForegroundColor Yellow

$notebookGroups = $selectedPages | Group-Object NotebookName

Write-Host "Gevonden: $($notebookGroups.Count) unieke notebook naam(en)" -ForegroundColor Cyan
Write-Host "→ Notebooks met dezelfde naam worden samengevoegd`n" -ForegroundColor Gray

foreach ($nbGroup in $notebookGroups) {
    $notebookNameRaw = $nbGroup.Name

    $isDefaultNotebook = $notebookNameRaw -match '\s*(Notitieblok|Notebook)\s*$'

    $notebookName = $notebookNameRaw
    $notebookName = $notebookName -replace '\s*(Notitieblok|Notebook)\s*$', ''
    $notebookName = Smart-Abbreviate $notebookName
    $notebookName = $notebookName -replace '[\\/:*?"<>|]', '_'
    if ([string]::IsNullOrWhiteSpace($notebookName)) { $notebookName = "Notebook" }
    if ($notebookName.Length -gt 60) { $notebookName = $notebookName.Substring(0, 60) }

    if ($isDefaultNotebook) {
        $notebookPath = $ExportPath
    } else {
        $notebookPath = Join-Path $ExportPath $notebookName
        New-Item -ItemType Directory -Path $notebookPath -Force | Out-Null
    }

    Write-Host "📓 NOTEBOOK: $notebookNameRaw" -ForegroundColor Yellow
    if ($isDefaultNotebook) {
        Write-Host "   → Folder: $notebookPath (default notebook → root)" -ForegroundColor Gray
    } else {
        Write-Host "   → Folder: $notebookPath" -ForegroundColor Gray
    }
    Write-ParentLog "Notebook exporteren: $notebookNameRaw ($($nbGroup.Group.Count) pagina's)" 'INFO'

    $uniqueSources = $nbGroup.Group | Group-Object SiteId, NotebookId
    Write-Host "   → Bronnen: $($uniqueSources.Count) SharePoint site(s)" -ForegroundColor Cyan

    foreach ($source in $uniqueSources) {
        $firstPage = $source.Group | Select-Object -First 1
        $siteId = $firstPage.SiteId
        $notebookId = $firstPage.NotebookId
        $siteName = $firstPage.SiteName

        Write-Host "     • Van: $siteName" -ForegroundColor DarkGray

        $notebookInfo = @{
            SiteId = $siteId
            SiteName = $siteName
            NotebookId = $notebookId
            NotebookName = $notebookNameRaw
        }

        try {
            Export-NotebookSectionsHierarchical -ResolvedSiteId $siteId `
                                                 -NotebookId $notebookId `
                                                 -ParentFolder $notebookPath `
                                                 -NotebookInfo $notebookInfo `
                                                 -SelectedPageIds $selectedPageIds
        } catch {
            Write-Warning "  ✗ Fout bij exporteren van $siteName : $($_.Exception.Message)"
        }
    }

    Write-Host ""
}

# =========================
# EXPORT COMPLETE
# =========================
Write-Host "═══════════════════════════════════════════════════" -ForegroundColor Green
Write-Host "EXPORT VOLTOOID" -ForegroundColor Green
Write-Host "═══════════════════════════════════════════════════`n" -ForegroundColor Green

Write-Host "✓ $($script:ExportedPageCount) pagina's geëxporteerd" -ForegroundColor Green
Write-Host "  Totaal geselecteerd: $totalPagesToExport pagina's" -ForegroundColor Cyan
Write-Host "  Export directory: $ExportPath" -ForegroundColor Cyan
Write-ParentLog "Export voltooid: $($script:ExportedPageCount)/$totalPagesToExport pagina's geëxporteerd naar $ExportPath" 'SUCCESS'
Write-Host "  Metadata: $metadataPath" -ForegroundColor Cyan

if ($script:ThrottleHits -gt 0) {
    Write-Host "`n⚠️  Throttling Statistics:" -ForegroundColor Yellow
    Write-Host "  HTTP 429 hits: $($script:Throttle429Count)" -ForegroundColor Gray
    Write-Host "  Total throttles: $($script:ThrottleHits)" -ForegroundColor Gray
    if ($script:UltraConservativeMode) {
        Write-Host "  Ultra-conservative mode: ACTIVATED" -ForegroundColor Yellow
    }
} else {
    Write-Host "`n✓ Geen throttling problemen gedetecteerd" -ForegroundColor Green
}

Write-Host ""
