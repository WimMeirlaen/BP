[CmdletBinding()]
param(
    [Parameter(Mandatory)]
    [string]$SiteUrl,

    [string]$ExportPath,

    [string]$SiteTitle,

    [switch]$SkipCleanup,

    [string]$ParentLogFile
)

function Convert-ToCanonicalSharePointSiteUrl {
    param([Parameter(Mandatory)][string]$InputUrl)

    $trimmed = $InputUrl.Trim()
    if ([string]::IsNullOrWhiteSpace($trimmed)) {
        throw "SiteUrl mag niet leeg zijn."
    }

    try {
        $uri = [Uri]$trimmed
    } catch {
        throw "Ongeldige SiteUrl: $trimmed"
    }

    $path = $uri.AbsolutePath.TrimEnd('/')
    if ($path -match '^/:[^/]+:/r/(.+)$') {
        $path = '/' + $matches[1].TrimStart('/')
    }

    if ($path -notmatch '^/(sites|teams)/') {
        if ($path -eq '/') {
            $path = '/sites'
        }
    }

    return ($uri.Scheme + '://' + $uri.Host + $path)
}

function Convert-ToSafeFolderName {
    param([string]$Name)

    if ([string]::IsNullOrWhiteSpace($Name)) {
        return 'OneNote-Export'
    }

    $safe = $Name.Trim()
    $invalid = [System.IO.Path]::GetInvalidFileNameChars()
    foreach ($ch in $invalid) {
        $safe = $safe.Replace([string]$ch, '_')
    }

    $safe = ($safe -replace '\s+', ' ').Trim()
    if ($safe.Length -gt 80) {
        $safe = $safe.Substring(0, 80).Trim()
    }

    if ([string]::IsNullOrWhiteSpace($safe)) {
        return 'OneNote-Export'
    }

    return $safe
}

$rootScript = Join-Path $PSScriptRoot 'Export-OneNote-Deduplicated-Queue.ps1'
if (-not (Test-Path $rootScript)) {
    throw "Export-OneNote-Deduplicated-Queue.ps1 niet gevonden in $PSScriptRoot"
}

$canonicalSiteUrl = Convert-ToCanonicalSharePointSiteUrl -InputUrl $SiteUrl
$sitePath = ([Uri]$canonicalSiteUrl).AbsolutePath.TrimEnd('/')
$derivedTitle = if ($SiteTitle) { $SiteTitle } else { Split-Path $sitePath -Leaf }
$resolvedTitle = Convert-ToSafeFolderName -Name $derivedTitle

if ([string]::IsNullOrWhiteSpace($ExportPath)) {
    $ExportPath = Join-Path $PSScriptRoot (Join-Path 'Exports' $resolvedTitle)
}

$customerSites = @(
    [pscustomobject]@{
        Title = $resolvedTitle
        Url   = $canonicalSiteUrl
    }
)

Write-Host "╔════════════════════════════════════════════════════════════╗" -ForegroundColor Cyan
Write-Host "║  ONENOTE EXPORT VIA SHAREPOINT SITE URL                   ║" -ForegroundColor Cyan
Write-Host "╚════════════════════════════════════════════════════════════╝`n" -ForegroundColor Cyan
Write-Host "SiteUrl: $SiteUrl" -ForegroundColor Gray
Write-Host "Canonical: $canonicalSiteUrl" -ForegroundColor Gray
Write-Host "Title: $resolvedTitle" -ForegroundColor Gray
Write-Host "ExportPath: $ExportPath`n" -ForegroundColor Gray

& $rootScript -CustomerSites $customerSites -ExportPath $ExportPath -SkipCleanup:$SkipCleanup -ParentLogFile $ParentLogFile
