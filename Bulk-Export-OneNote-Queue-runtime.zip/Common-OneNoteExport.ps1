<#
.SYNOPSIS
    Gedeelde OneNote export functionaliteit voor alle export scripts
    
.DESCRIPTION
    Dit bestand bevat alle gedeelde functies voor OneNote export:
    - Throttling en Governor logica
    - HTTP client met retry/bearer token handling
    - MIME type detectie en magic bytes
    - EMF → PNG conversie
    - Resource extractie en download
    - Attachment processing
    - URL normalisatie
    - Hierarchical export logica
    
    Dit bestand wordt ge-dot-sourced door:
    - Export-OneNote-Interactive-Full.ps1
    - Export-OneNote-Deduplicated.ps1
#>

# =========================
# THROTTLING CONFIG
# =========================
$script:MinDelayMs     = 1000   # Increased from 600 for better throttling
$script:StartDelayMs   = 3500   # Increased from 2500
$script:MaxDelayMs     = 20000  # Increased from 12000
$script:CurrentDelayMs = $script:StartDelayMs
$script:SuccessStreak  = 0
$script:ThrottleHits   = 0
$script:ConsecThrottles = 0
$script:UltraConservativeMode = $false  # Activated after repeated 429s
$script:Throttle429Count = 0             # Count 429 errors to trigger ultra mode

$InitialCooldownSec    = 150  # Increased from 120
$WarmupGapSec          = 10

$CircuitBreakerThreshold = 8   # Reduced from 12 - more sensitive
$CircuitBreakerPauseSec  = 240 # Increased from 180

$TopPerRequest         = 50
$ExtraDelayBetweenPagesMs     = 750  # Increased to reduce Graph API load
$ExtraDelayBetweenResourcesMs = 200  # Increased from 150

# Ultra-conservative mode settings (activated on heavy throttling)
$UltraDelayBetweenPagesMs     = 2000  # 2s per page in ultra mode
$UltraDelayBetweenResourcesMs = 500   # 0.5s per resource in ultra mode
$Throttle429Threshold         = 3     # After 3x HTTP 429, go ultra-conservative

$MaxSdkRetryHitsPerUri = 2
$RecoveryRounds        = 6
$RecoveryBaseSleepSec  = 12

# Runtime state
$script:ThrottleCounts   = @{}
$script:MissingResources = New-Object System.Collections.Generic.List[object]
$script:FailedPages      = New-Object System.Collections.Generic.List[object]
$script:DirectHttpClient = $null
$script:ExportedPageCount = 0  # Track number of pages successfully exported
$script:BearerToken      = $null
$script:TokenExpiresAt   = [DateTime]::MinValue
$script:OAuthRefreshToken = $null
$script:OAuthClientId     = $null
$script:OAuthTenantId     = $null
$script:OAuthScopeString  = $null

# Optional hard throttle cooldown mode (used by queue export)
$script:EnableHard429Cooldown = $false
$script:Hard429CooldownSec    = 1800

# Graph diagnostics log (captures headers, Retry-After, request id on throttles)
$script:GraphLogFile = Join-Path $PSScriptRoot 'graph-throttle.log'

# Ensure log file exists and is writable immediately (helps when script is interrupted)
try {
    if (-not $script:GraphLogFile) { $script:GraphLogFile = Join-Path $PWD 'graph-throttle.log' }
    $logDir = Split-Path $script:GraphLogFile -Parent
    if ($logDir -and -not (Test-Path $logDir)) { New-Item -ItemType Directory -Path $logDir -Force | Out-Null }
    if (-not (Test-Path $script:GraphLogFile)) {
        "Graph throttle log initialized: $(Get-Date -Format o)" | Out-File -FilePath $script:GraphLogFile -Encoding UTF8 -Force
    }
} catch {
    Write-Verbose "Graph log initialization failed: $_"
}
function Start-Hard429Cooldown {
    param(
        [int]$Seconds = 1800,
        [string]$Reason = "HTTP 429 throttling"
    )

    if ($Seconds -lt 1) { $Seconds = 1800 }

    Write-Warning "HTTP 429 gedetecteerd. Hard cooldown geactiveerd ($Reason)."
    Write-Host "⏸️  Graph cooldown: $([math]::Round($Seconds / 60, 1)) minuten" -ForegroundColor Yellow

    for ($remaining = $Seconds; $remaining -gt 0; $remaining--) {
        $ts = [TimeSpan]::FromSeconds($remaining)
        $timerText = "{0:D2}:{1:D2}:{2:D2}" -f $ts.Hours, $ts.Minutes, $ts.Seconds
        $pct = [int](($Seconds - $remaining) / $Seconds * 100)
        Write-Progress -Activity "⏸️  Graph cooldown (429 throttling)" -Status "Hervat over: $timerText" -PercentComplete $pct
        Start-Sleep -Seconds 1
    }
    Write-Progress -Activity "⏸️  Graph cooldown (429 throttling)" -Completed

    Write-Host "✓ Hard cooldown voltooid, Graph calls hervatten" -ForegroundColor Green
}

# =========================
# GOVERNOR
# =========================
function Wait-Governor { 
    Start-Sleep -Milliseconds $script:CurrentDelayMs 
}

function Governor-OnSuccess {
    $script:SuccessStreak++
    $script:ConsecThrottles = 0
    if ($script:SuccessStreak -ge 5) {
        $script:SuccessStreak = 0
        $script:CurrentDelayMs = [Math]::Max($script:MinDelayMs, [Math]::Floor($script:CurrentDelayMs * 0.80))
    }
}

function Governor-OnThrottle {
    $script:ThrottleHits++
    $script:SuccessStreak = 0
    $script:ConsecThrottles++
    $script:Throttle429Count++
    
    # Activate ultra-conservative mode after repeated 429s
    if ($script:Throttle429Count -ge $Throttle429Threshold -and -not $script:UltraConservativeMode) {
        $script:UltraConservativeMode = $true
        Write-Warning "⚠️  ULTRA-CONSERVATIVE MODE ACTIVATED (na $($script:Throttle429Count)x HTTP 429)"
        Write-Host "    → Page delay: $($UltraDelayBetweenPagesMs)ms" -ForegroundColor Yellow
        Write-Host "    → Resource delay: $($UltraDelayBetweenResourcesMs)ms" -ForegroundColor Yellow
        Write-Host "    → Governor blijft op MaxDelayMs" -ForegroundColor Yellow
    }
    
    $script:CurrentDelayMs = [Math]::Min($script:MaxDelayMs, [Math]::Ceiling($script:CurrentDelayMs * 1.4))
    if ($script:CurrentDelayMs -lt $script:MinDelayMs) { $script:CurrentDelayMs = $script:MinDelayMs }
    if ($script:ConsecThrottles -ge $CircuitBreakerThreshold) {
        $script:ConsecThrottles = 0
        Write-Warning "Circuit breaker: $CircuitBreakerThreshold throttles. Pauze $CircuitBreakerPauseSec sec..."
        Start-Sleep -Seconds $CircuitBreakerPauseSec
        # In ultra mode, stay at max; otherwise reset
        if (-not $script:UltraConservativeMode) {
            $script:CurrentDelayMs = $script:StartDelayMs
        }
        Write-Host "Circuit breaker klaar" -ForegroundColor Green
    }
}

# =========================
# HTTP CLIENT
# =========================
function Initialize-DirectHttpClient {
    if (-not $script:DirectHttpClient) {
        $script:DirectHttpClient = [System.Net.Http.HttpClient]::new()
        $script:DirectHttpClient.Timeout = [System.TimeSpan]::FromSeconds(120)
    }
}

function Refresh-BearerToken {
    if (-not [string]::IsNullOrWhiteSpace($script:OAuthRefreshToken) -and
        -not [string]::IsNullOrWhiteSpace($script:OAuthClientId) -and
        -not [string]::IsNullOrWhiteSpace($script:OAuthTenantId)) {
        $tokenEndpoint = "https://login.microsoftonline.com/$($script:OAuthTenantId)/oauth2/v2.0/token"
        $body = @{
            grant_type    = "refresh_token"
            client_id     = $script:OAuthClientId
            refresh_token = $script:OAuthRefreshToken
        }
        if (-not [string]::IsNullOrWhiteSpace($script:OAuthScopeString)) {
            $body.scope = $script:OAuthScopeString
        }

        $maxAttempts = 4
        $delaySec    = 15
        for ($attempt = 1; $attempt -le $maxAttempts; $attempt++) {
            try {
                $tokenResponse = Invoke-RestMethod -Method Post `
                                                   -Uri $tokenEndpoint `
                                                   -ContentType "application/x-www-form-urlencoded" `
                                                   -Body $body `
                                                   -TimeoutSec 30 `
                                                   -ErrorAction Stop

                if (-not $tokenResponse.access_token) {
                    throw "Geen access_token in refresh response"
                }

                $script:BearerToken = [string]$tokenResponse.access_token
                if ($tokenResponse.refresh_token) {
                    $script:OAuthRefreshToken = [string]$tokenResponse.refresh_token
                }
                $expiresIn = 3600
                if ($tokenResponse.expires_in) {
                    try { $expiresIn = [int]$tokenResponse.expires_in } catch { $expiresIn = 3600 }
                }
                $script:TokenExpiresAt = [DateTime]::UtcNow.AddSeconds([Math]::Max(120, $expiresIn - 120))
                return

            } catch {
                $errMsg = $_.Exception.Message
                # invalid_grant = refresh token permanently expired/revoked → no point retrying
                $isPermanent = ($errMsg -match 'invalid_grant|AADSTS7000[0-9]|AADSTS500|interaction_required')
                if ($isPermanent) {
                    throw "OAuth refresh token is verlopen of ingetrokken. Herstart het script om opnieuw in te loggen via device code. ($errMsg)"
                }
                if ($attempt -lt $maxAttempts) {
                    Write-Warning "Token refresh poging $attempt/$maxAttempts mislukt: $errMsg — opnieuw proberen na ${delaySec}s..."
                    Start-Sleep -Seconds $delaySec
                    $delaySec = $delaySec * 2  # exponential backoff
                } else {
                    throw "Token refresh definitief mislukt na $maxAttempts pogingen: $errMsg"
                }
            }
        }
    }

    # No refresh token available - cannot silently re-authenticate.
    # Throwing here prevents Invoke-MgGraphRequest from triggering an interactive login prompt.
    throw "Geen OAuth refresh token beschikbaar. Herstart het script om opnieuw in te loggen via device code."
}

function Ensure-BearerToken {
    if (-not $script:BearerToken -or [DateTime]::UtcNow -ge $script:TokenExpiresAt) {
        Refresh-BearerToken
    }
}

function Invoke-GraphHttp {
    param(
        [Parameter(Mandatory)][string]$Uri,
        [ValidateSet("GET","POST","PATCH","PUT","DELETE")][string]$Method = "GET",
        [switch]$ReturnBytes,
        [string]$OutFile
    )

    Initialize-DirectHttpClient
    try { Ensure-BearerToken } catch {
        Write-Warning "Token niet beschikbaar, request overgeslagen: $_"
        return @{ Response=$null; Bytes=$null; Skipped=$true; SkipReason="TokenUnavailable"; Uri=$Uri }
    }
    Wait-Governor

    # helper to write detailed Graph response info for debugging throttling
    function Write-GraphDebugLog {
        param($Entry)
        try {
            $json = $Entry | ConvertTo-Json -Depth 6
            Add-Content -Path $script:GraphLogFile -Value ("==== " + (Get-Date).ToString("o") + " ====") -ErrorAction SilentlyContinue
            Add-Content -Path $script:GraphLogFile -Value $json -ErrorAction SilentlyContinue
            Add-Content -Path $script:GraphLogFile -Value "`n" -ErrorAction SilentlyContinue
        } catch {}
    }

    $tokenRefreshDone = $false

    while ($true) {
        try {
            $req = [System.Net.Http.HttpRequestMessage]::new([System.Net.Http.HttpMethod]::new($Method), $Uri)
            $req.Headers.TryAddWithoutValidation("Authorization", "Bearer $script:BearerToken") | Out-Null
            $resp = $script:DirectHttpClient.SendAsync($req).GetAwaiter().GetResult()
        }
        catch {
            Write-Warning "Netwerkfout voor $Uri"
            return @{ Response=$null; Bytes=$null; Skipped=$true; SkipReason="NetworkError"; Uri=$Uri }
        }

        $status = [int]$resp.StatusCode

        if ($status -eq 401 -and -not $tokenRefreshDone) {
            $tokenRefreshDone = $true
            Write-Warning "Token verlopen (401)"
            $resp.Dispose()
            try { Refresh-BearerToken } catch {
                return @{ Response=$null; Bytes=$null; Skipped=$true; SkipReason="TokenRefreshFailed"; Uri=$Uri }
            }
            continue
        }

        if ($status -ge 200 -and $status -lt 300) {
            Governor-OnSuccess
            if ($ReturnBytes) {
                $bytes = $resp.Content.ReadAsByteArrayAsync().GetAwaiter().GetResult()
                $resp.Dispose()
                return @{ Response=$null; Bytes=$bytes; Skipped=$false; Uri=$Uri }
            }
            if ($OutFile) {
                $bytes = $resp.Content.ReadAsByteArrayAsync().GetAwaiter().GetResult()
                [System.IO.File]::WriteAllBytes($OutFile, $bytes)
                $resp.Dispose()
                return @{ Response=$null; Skipped=$false; Uri=$Uri }
            }
            $contentText = $resp.Content.ReadAsStringAsync().GetAwaiter().GetResult()
            $resp.Dispose()
            return @{ Response=@{ ContentText=$contentText }; Skipped=$false; Uri=$Uri }
        }

        if ($status -in 429, 503, 504) {
            $is429 = ($status -eq 429)
            Governor-OnThrottle
            if (-not $script:ThrottleCounts.ContainsKey($Uri)) { $script:ThrottleCounts[$Uri] = 0 }
            $script:ThrottleCounts[$Uri]++
            $hits = [int]$script:ThrottleCounts[$Uri]

            $retryAfter = $null
            try {
                $raVals = $resp.Headers.GetValues("Retry-After")
                $retryAfter = [int]($raVals | Select-Object -First 1)
            } catch {}
            try {
                if (-not $retryAfter) {
                    $raMs = $resp.Headers.GetValues("x-ms-retry-after-ms")
                    $retryAfter = [Math]::Ceiling([int]($raMs | Select-Object -First 1) / 1000)
                }
            } catch {}
            if (-not $retryAfter -or $retryAfter -le 0) { $retryAfter = [Math]::Ceiling($script:CurrentDelayMs / 1000) }

            if ($is429 -and $script:EnableHard429Cooldown) {
                $pauseSec = [Math]::Max([int]$script:Hard429CooldownSec, [int]$retryAfter)
                Write-Warning "HTTP 429 (hit $hits/$MaxSdkRetryHitsPerUri). Retry-After=${retryAfter}s. Hard cooldown ${pauseSec}s. GovernorDelayMs=$($script:CurrentDelayMs)"
                $resp.Dispose()
                Start-Hard429Cooldown -Seconds $pauseSec -Reason "429 op URI $Uri"
                $script:ThrottleCounts[$Uri] = 0
                $script:ConsecThrottles = 0
                continue
            }

            $sleepSec = [Math]::Min(60, [Math]::Max(10, $retryAfter + (Get-Random -Minimum 0 -Maximum 6)))

            Write-Warning "HTTP $status (hit $hits/$MaxSdkRetryHitsPerUri). Retry-After=${retryAfter}s. Sleeping ${sleepSec}s. GovernorDelayMs=$($script:CurrentDelayMs)"
            $resp.Dispose()

            if ($hits -ge $MaxSdkRetryHitsPerUri) {
                return @{ Response=$null; Bytes=$null; Skipped=$true; SkipReason="HttpThrottle$status"; Uri=$Uri }
            }

            Start-Sleep -Seconds $sleepSec
            continue
        }

        $sc = $status
        $resp.Dispose()
        return @{ Response=$null; Bytes=$null; Skipped=$true; SkipReason="Http$sc"; Uri=$Uri }
    }
}

function Invoke-GraphJson {
    param([Parameter(Mandatory)][string]$Uri)
    $r = Invoke-GraphHttp -Uri $Uri -Method GET
    if ($r.Skipped) {
        # Throw a structured exception so callers can reliably decide retry behavior.
        $skipReason = [string]$r.SkipReason
        $isRetryable = $skipReason -match '(429|503|504)'
        $ex = [System.Exception]::new("Graph JSON failed: $skipReason for $Uri")
        $null = $ex.Data.Add('SkipReason', $skipReason)
        $null = $ex.Data.Add('IsRetryable', $isRetryable)
        $null = $ex.Data.Add('GraphUri', $Uri)
        throw $ex
    }
    if (-not $r.Response) { throw "Graph JSON failed: no response for $Uri" }
    $text = $r.Response.ContentText
    if ([string]::IsNullOrWhiteSpace($text)) { return $null }
    return $text | ConvertFrom-Json
}

# =========================
# MIME TYPE DETECTION
# =========================
function MimeToExt {
    param([string]$Mime)
    if ([string]::IsNullOrWhiteSpace($Mime)) { return $null }
    switch -Regex ($Mime.ToLowerInvariant()) {
        # Images
        '^image/jpeg' { ".jpg"; break }
        '^image/jpg'  { ".jpg"; break }
        '^image/png'  { ".png"; break }
        '^image/gif'  { ".gif"; break }
        '^image/bmp'  { ".bmp"; break }
        '^image/x-windows-bmp' { ".bmp"; break }
        '^image/svg\+xml' { ".svg"; break }
        '^image/webp' { ".webp"; break }
        '^image/tiff' { ".tiff"; break }
        
        # Documents
        '^application/pdf' { ".pdf"; break }
        '^text/plain' { ".txt"; break }
        '^text/html' { ".html"; break }
        '^text/xml' { ".xml"; break }
        '^application/xml' { ".xml"; break }
        '^application/json' { ".json"; break }
        
        # Microsoft Office - Modern (OpenXML)
        '^application/vnd\.openxmlformats-officedocument\.wordprocessingml\.document' { ".docx"; break }
        '^application/vnd\.openxmlformats-officedocument\.spreadsheetml\.sheet' { ".xlsx"; break }
        '^application/vnd\.openxmlformats-officedocument\.presentationml\.presentation' { ".pptx"; break }
        '^application/vnd\.ms-visio\.drawing\.main\+xml' { ".vsdx"; break }
        '^application/vnd\.ms-visio\.drawing' { ".vsdx"; break }
        
        # Microsoft Office - Legacy
        '^application/vnd\.ms-visio' { ".vsd"; break }
        '^application/vnd\.visio' { ".vsd"; break }
        '^application/msword' { ".doc"; break }
        '^application/vnd\.ms-excel' { ".xls"; break }
        '^application/vnd\.ms-powerpoint' { ".ppt"; break }
        '^application/vnd\.ms-outlook' { ".msg"; break }
        
        # Email
        '^message/rfc822' { ".eml"; break }
        
        # Archives
        '^application/zip' { ".zip"; break }
        '^application/x-zip' { ".zip"; break }
        '^application/x-zip-compressed' { ".zip"; break }
        '^application/x-rar' { ".rar"; break }
        '^application/x-rar-compressed' { ".rar"; break }
        '^application/x-7z-compressed' { ".7z"; break }
        '^application/x-gzip' { ".gz"; break }
        '^application/gzip' { ".gz"; break }
        
        # Other
        '^application/octet-stream' { $null; break }
        '^application/x-msdownload' { ".exe"; break }
        
        default { $null }
    }
}

function DetectExtFromMagicBytes {
    param([byte[]]$Bytes)
    if (-not $Bytes -or $Bytes.Length -lt 4) { return $null }
    
    # Images
    if ($Bytes[0] -eq 0xFF -and $Bytes[1] -eq 0xD8) { return ".jpg" }
    if ($Bytes[0] -eq 0x89 -and $Bytes[1] -eq 0x50 -and $Bytes[2] -eq 0x4E -and $Bytes[3] -eq 0x47) { return ".png" }
    if ($Bytes[0] -eq 0x47 -and $Bytes[1] -eq 0x49 -and $Bytes[2] -eq 0x46) { return ".gif" }
    if ($Bytes[0] -eq 0x42 -and $Bytes[1] -eq 0x4D) { return ".bmp" }
    
    # Documents
    if ($Bytes[0] -eq 0x25 -and $Bytes[1] -eq 0x50 -and $Bytes[2] -eq 0x44 -and $Bytes[3] -eq 0x46) { return ".pdf" }
    
    # Microsoft Office formats (ZIP-based: docx, xlsx, pptx, vsdx)
    if ($Bytes[0] -eq 0x50 -and $Bytes[1] -eq 0x4B -and $Bytes.Length -gt 30) {
        $content = [System.Text.Encoding]::ASCII.GetString($Bytes, 0, [Math]::Min(8192, $Bytes.Length))
        if ($content -match 'word/') { return ".docx" }
        if ($content -match 'xl/') { return ".xlsx" }
        if ($content -match 'ppt/') { return ".pptx" }
        if ($content -match 'visio/') { return ".vsdx" }
        return ".zip"
    }
    
    # Legacy Microsoft Office formats (OLE/CFB)
    if ($Bytes[0] -eq 0xD0 -and $Bytes[1] -eq 0xCF -and $Bytes[2] -eq 0x11 -and $Bytes[3] -eq 0xE0 -and $Bytes.Length -gt 2080) {
        $sample = [System.Text.Encoding]::ASCII.GetString($Bytes, 0, [Math]::Min(8192, $Bytes.Length))
        if ($sample -match 'Microsoft Excel') { return ".xls" }
        if ($sample -match 'Microsoft Word' -or $sample -match 'Word.Document') { return ".doc" }
        if ($sample -match 'Microsoft PowerPoint' -or $sample -match 'PowerPoint Document') { return ".ppt" }
        if ($sample -match 'Visio' -or $sample -match 'VisioDocument') { return ".vsd" }
        if ($sample -match 'Microsoft Outlook') { return ".msg" }
        return ".msg"
    }
    
    # Other common formats
    if ($Bytes[0] -eq 0x52 -and $Bytes[1] -eq 0x61 -and $Bytes[2] -eq 0x72 -and $Bytes[3] -eq 0x21) { return ".rar" }
    if ($Bytes[0] -eq 0x1F -and $Bytes[1] -eq 0x8B) { return ".gz" }
    if ($Bytes[0] -eq 0x49 -and $Bytes[1] -eq 0x44 -and $Bytes[2] -eq 0x33) { return ".mp3" }

    # EMF (Enhanced Metafile Format)
    if ($Bytes.Length -ge 44 -and
        $Bytes[0] -eq 0x01 -and $Bytes[1] -eq 0x00 -and $Bytes[2] -eq 0x00 -and $Bytes[3] -eq 0x00 -and
        $Bytes[40] -eq 0x20 -and $Bytes[41] -eq 0x45 -and $Bytes[42] -eq 0x4D -and $Bytes[43] -eq 0x46) {
        return ".emf"
    }

    return $null
}

# =========================
# EMF → PNG CONVERSIE
# =========================
function Convert-EmfToPng {
    param(
        [Parameter(Mandatory)][string]$EmfPath,
        [Parameter(Mandatory)][string]$PngPath
    )
    try {
        Add-Type -AssemblyName System.Drawing -ErrorAction SilentlyContinue
        $mf   = [System.Drawing.Imaging.Metafile]::new($EmfPath)
        $unit = [System.Drawing.GraphicsUnit]::Pixel
        $bounds = $mf.GetBounds([ref]$unit)
        $w = [Math]::Max(100, [int][Math]::Ceiling($bounds.Width))
        $h = [Math]::Max(100, [int][Math]::Ceiling($bounds.Height))
        if ($w -gt 4000 -or $h -gt 4000) {
            $scale = 4000.0 / [Math]::Max($w, $h)
            $w = [int]($w * $scale)
            $h = [int]($h * $scale)
        }
        $bmp = [System.Drawing.Bitmap]::new($w, $h)
        $g   = [System.Drawing.Graphics]::FromImage($bmp)
        $g.Clear([System.Drawing.Color]::White)
        $g.DrawImage($mf, 0, 0, $w, $h)
        $bmp.Save($PngPath, [System.Drawing.Imaging.ImageFormat]::Png)
        $g.Dispose(); $bmp.Dispose(); $mf.Dispose()
        return $true
    } catch {
        Write-Verbose "EMF→PNG mislukt voor ${EmfPath}: $_"
        return $false
    }
}

# =========================
# NAME/PATH UTILITIES
# =========================
function Sanitize-FileName {
    param([string]$Name)
    if ([string]::IsNullOrWhiteSpace($Name)) { return "Untitled" }
    $invalid = [System.IO.Path]::GetInvalidFileNameChars()
    foreach ($c in $invalid) { $Name = $Name.Replace($c, '_') }
    if ($Name.Length -gt 160) { $Name = $Name.Substring(0,160) }
    return $Name.Trim()
}

function Smart-Abbreviate {
    param([string]$Text)
    $Text = $Text -replace 'Shared with customer', 'SWC'
    $Text = $Text -replace 'shared with customer', 'SWC'
    $Text = $Text -replace 'MW documentation', 'MW doc'
    $Text = $Text -replace 'MW Documentation', 'MW doc'
    $Text = $Text -replace 'documentation', 'doc'
    $Text = $Text -replace 'Documentation', 'doc'
    return $Text
}

function Ensure-UniqueFolder {
    param([Parameter(Mandatory)][string]$Folder, [Parameter(Mandatory)][string]$Name)
    $Name = Sanitize-FileName $Name
    $full = Join-Path $Folder $Name
    if (-not (Test-Path $full)) { return $full }
    $i=2
    while ($true) {
        $cand = Join-Path $Folder ("{0} ({1})" -f $Name, $i)
        if (-not (Test-Path $cand)) { return $cand }
        $i++
    }
}

function Ensure-UniqueFile {
    param([Parameter(Mandatory)][string]$Folder, [Parameter(Mandatory)][string]$FileName)
    $FileName = Sanitize-FileName $FileName
    $full = Join-Path $Folder $FileName
    if (-not (Test-Path $full)) { return $full }
    $nameOnly = [System.IO.Path]::GetFileNameWithoutExtension($FileName)
    $ext = [System.IO.Path]::GetExtension($FileName)
    $i=2
    while ($true) {
        $cand = Join-Path $Folder ("{0} ({1}){2}" -f $nameOnly, $i, $ext)
        if (-not (Test-Path $cand)) { return $cand }
        $i++
    }
}

# =========================
# URL NORMALIZATION
# =========================
function Normalize-OneNoteResourceUrl {
    param([Parameter(Mandatory)][string]$Url)
    $u = $Url
    $u = $u -replace '(?i)^https://graph\.microsoft\.com/(v1\.0|beta)/siteCollections/', 'https://graph.microsoft.com/$1/sites/'
    return $u
}

function Prefer-ResourceContentEndpoint {
    param([Parameter(Mandatory)][string]$Url)
    if ($Url -match '/\`$value(\?.*)?$') {
        return ($Url -replace '/\`$value(\?.*)?$', '/content$1')
    }
    return $Url
}

# =========================
# CHECKBOXES
# =========================
function Render-NoteTagsToCheckboxes {
    param([string]$Html)
    if ([string]::IsNullOrWhiteSpace($Html)) { return $Html }

    $pattern = '(?is)\<(p|li)([^>]*?)\sdata-tag\s*=\s*["''](to-do(?::completed)?)["'']([^>]*)\>(.*?)\</\1\>'
    $Html = [regex]::Replace($Html, $pattern, {
        param($m)
        $tag = $m.Groups[1].Value
        $a1  = $m.Groups[2].Value
        $tagValue = $m.Groups[3].Value
        $a2  = $m.Groups[4].Value
        $inner = $m.Groups[5].Value

        $checked = if ($tagValue -eq 'to-do:completed') { 'checked="checked"' } else { '' }

        $attrs = ($a1 + " " + $a2)
        $attrs = [regex]::Replace($attrs, '(?is)\sdata-tag\s*=\s*["''][^"'']+["'']', '')

        "<$tag $attrs><input type=`"checkbox`" $checked disabled=`"disabled`" style=`"margin-right:6px;vertical-align:middle;`" />$inner</$tag>"
    })

    if ($Html -notmatch 'onenote-checkbox-style') {
        $css = @"
<style id="onenote-checkbox-style">
input[type=checkbox]{width:14px;height:14px;vertical-align:middle;opacity:1;visibility:visible;display:inline-block;}
</style>
"@
        if ($Html -match '(?is)<head[^>]*>') {
            $Html = [regex]::Replace($Html, '(?is)(<head[^>]*>)', "`$1`r`n$css", 1)
        } else {
            $Html = $css + "`r`n" + $Html
        }
    }
    return $Html
}

# =========================
# INLINE ATTACHMENTS
# =========================
function Replace-ObjectAttachmentsInline {
    param(
        [Parameter(Mandatory)][string]$Html,
        [Parameter(Mandatory)][hashtable]$AttachmentMap
    )
    # First pass: Replace object tags WITH data-attachment attribute
    $pattern = '(?is)\<object\b(?:[^>''"]|"[^"]*"|''[^'']*'')*?\bdata-attachment\s*=\s*["'']([^"'']+)["''](?:[^>''"]|"[^"]*"|''[^'']*'')*(?:/\>|\>.*?\</object\>)'
    $Html = [regex]::Replace($Html, $pattern, {
        param($m)
        $fileName = $m.Groups[1].Value
        $decodedName = [System.Net.WebUtility]::HtmlDecode($fileName)
        $safeName = [System.Web.HttpUtility]::HtmlEncode($decodedName)

        $tag = $m.Value
        $style = [regex]::Match($tag, '(?is)\bstyle\s*=\s*["'']([^"'']+)["'']').Groups[1].Value
        if ([string]::IsNullOrWhiteSpace($style)) { $style = "display:inline-block;" } else { $style = $style.Trim() }

        $rel = $null
        if ($AttachmentMap.ContainsKey($decodedName)) { $rel = $AttachmentMap[$decodedName] }
        if ([string]::IsNullOrWhiteSpace($rel)) {
            $rel = "attachments/" + (Sanitize-FileName $decodedName)
        }

        "<a href=`"$rel`" download style=`"$style`">📎 $safeName</a>"
    })
    
    # Second pass: Replace ALL remaining object tags (without data-attachment)
    $pattern2 = '(?is)\<object\b(?:[^>''"]|"[^"]*"|''[^'']*'')*(?:/\>|\>.*?\</object\>)'
    $Html = [regex]::Replace($Html, $pattern2, {
        param($m)
        $tag = $m.Value
        
        $dataUrl = [regex]::Match($tag, '(?is)\bdata\s*=\s*["'']([^"'']+)["'']').Groups[1].Value
        
        if ($dataUrl -like 'attachments/*') {
            $fileName = Split-Path $dataUrl -Leaf
            $safeName = [System.Web.HttpUtility]::HtmlEncode($fileName)
            $style = [regex]::Match($tag, '(?is)\bstyle\s*=\s*["'']([^"'']+)["'']').Groups[1].Value
            if ([string]::IsNullOrWhiteSpace($style)) { $style = "display:inline-block;" } else { $style = $style.Trim() }
            return "<a href=`"$dataUrl`" download style=`"$style`">📎 $safeName</a>"
        }
        
        return ""
    })
    
    return $Html
}

# =========================
# BOTTOM ATTACHMENTS
# =========================
function Inject-AttachmentsBlockBottom {
    param(
        [Parameter(Mandatory)][string]$Html,
        [Parameter(Mandatory)][string]$AttachmentsPath
    )

    if (-not (Test-Path $AttachmentsPath)) { return $Html }

    $files = Get-ChildItem $AttachmentsPath -File -ErrorAction SilentlyContinue |
        Where-Object { $_.Extension -notmatch '\.(png|jpg|jpeg|gif|bmp|svg|bin)$' }

    if (-not $files -or $files.Count -eq 0) { return $Html }

    $block = "<hr /><div style=`"margin-top:20px;clear:both;`"><h3>Bijlagen</h3><ul>"
    foreach ($f in $files) {
        $name = [System.Web.HttpUtility]::HtmlEncode($f.Name)
        $href = "attachments/" + $f.Name
        $block += "<li><a href=`"$href`" download>$name</a></li>"
    }
    $block += "</ul></div>"

    $bodyCloseIndex = $Html.LastIndexOf('</body>')
    if ($bodyCloseIndex -gt 0) {
        $lastDivIndex = $Html.LastIndexOf('</div>', $bodyCloseIndex - 1)
        if ($lastDivIndex -gt 0) {
            $Html = $Html.Substring(0, $lastDivIndex) + "`r`n" + $block + "`r`n" + $Html.Substring($lastDivIndex)
            return $Html
        }
        $Html = $Html.Substring(0, $bodyCloseIndex) + $block + "`r`n" + $Html.Substring($bodyCloseIndex)
        return $Html
    }
    
    return $Html + "`r`n" + $block
}

# =========================
# PAGES LIST
# =========================
function Get-SectionPagesRobust {
    param([Parameter(Mandatory)][string]$ResolvedSiteId, [Parameter(Mandatory)][string]$SectionId)

    $all = @()
    $skip = 0
    $base = "https://graph.microsoft.com/v1.0/sites/$ResolvedSiteId/onenote/sections/$SectionId/pages?pagelevel=true&`$select=id,title,level,order,lastModifiedDateTime&`$orderby=order&`$top=$TopPerRequest"

    $next = $base
    while ($true) {
        $resp = $null
        $lastError = $null
        $lastErrorReason = $null
        for ($attempt = 1; $attempt -le $RecoveryRounds; $attempt++) {
            try {
                $resp = Invoke-GraphJson -Uri $next
                $lastError = $null
                break
            } catch {
                    $ex = $_.Exception
                    $lastError = $ex.Message
                    $isRetryable = $false
                    $skipReason = $null
                    try {
                        if ($ex.Data -and $ex.Data.Contains('IsRetryable')) { $isRetryable = [bool]$ex.Data['IsRetryable'] }
                        if ($ex.Data -and $ex.Data.Contains('SkipReason')) { $skipReason = [string]$ex.Data['SkipReason'] }
                    } catch {}
                    $lastErrorReason = if ($isRetryable) { 'HTTP429/503/504' } elseif ($skipReason) { $skipReason } else { 'Permanent' }
                    
                    # Non-retryable errors (401, 404, 403, etc) should fail immediately
                    if (-not $isRetryable) {
                        Write-Warning ("PERMANENT ERROR in Get-SectionPagesRobust: $lastError. Not retrying.")
                        throw "Get-SectionPagesRobust permanent error: $lastError"
                    }
                    
                    if ($attempt -eq $RecoveryRounds) {
                        Write-Warning ("Section pages: final retry failed after $attempt attempts. Error: $lastError")
                        throw "Get-SectionPagesRobust failed after $RecoveryRounds herstelpogingen for $next :: $lastError"
                    }
                    
                    $sleepSec = [Math]::Min(180, ($RecoveryBaseSleepSec * $attempt))
                    Write-Warning ("Section pages throttle/herstel poging {0}/{1}. Wachten {2}s... ({3})" -f $attempt, $RecoveryRounds, $sleepSec, $lastErrorReason)
                    # Log this throttle/retry attempt for diagnostics
                    try {
                        $logEntry = @{ Function = 'Get-SectionPagesRobust'; SiteId = $ResolvedSiteId; SectionId = $SectionId; Attempt = $attempt; RecoveryRounds = $RecoveryRounds; SleepSec = $sleepSec; ErrorReason = $lastErrorReason; SkipReason = $skipReason; Error = $lastError; NextUri = $next }
                        $json = $logEntry | ConvertTo-Json -Depth 6
                        Add-Content -Path $script:GraphLogFile -Value ("==== " + (Get-Date).ToString("o") + " ====") -ErrorAction SilentlyContinue
                        Add-Content -Path $script:GraphLogFile -Value $json -ErrorAction SilentlyContinue
                        Add-Content -Path $script:GraphLogFile -Value "`n" -ErrorAction SilentlyContinue
                    } catch {}
                    Start-Sleep -Seconds $sleepSec
            }
        }

        if (-not $resp) {
            throw "Get-SectionPagesRobust failed after $RecoveryRounds herstelpogingen for $next :: $lastError"
        }

        $batch = @()
        if ($resp -and $resp.value) { $batch = $resp.value }
        $all += $batch

        if ($resp.'@odata.nextLink') { $next = $resp.'@odata.nextLink'; Start-Sleep -Milliseconds 1000; continue }

        if ($batch.Count -ge $TopPerRequest) {
            $skip += $batch.Count
            $next = $base + "&`$skip=$skip"
            continue
        }
        break
    }
    return $all
}

# =========================
# RESOURCES EXTRACT
# =========================
function Extract-OneNoteResources {
    param([string]$Html)
    if ([string]::IsNullOrWhiteSpace($Html)) { return @() }

    $list = New-Object System.Collections.Generic.List[object]

    function AddRes([string]$Type, [string]$Url, [string[]]$Aliases, [string]$PreferredName, [string]$MimeHint) {
        if ([string]::IsNullOrWhiteSpace($Url)) { return }
        if ($Url -notmatch '^https://graph\.microsoft\.com/.+?/onenote/resources/.+?/(?:\$value|content)(?:\?.*)?$' -and
            [System.Net.WebUtility]::HtmlDecode($Url) -notmatch '^https://graph\.microsoft\.com/.+?/onenote/resources/.+?/(?:\$value|content)(?:\?.*)?$') { return }
        $decodedUrl = [System.Net.WebUtility]::HtmlDecode($Url)
        $url1 = Normalize-OneNoteResourceUrl $decodedUrl
        $url2 = Normalize-OneNoteResourceUrl (Prefer-ResourceContentEndpoint $decodedUrl)
        $list.Add([pscustomobject]@{
            Type=$Type; Url=$Url; Url1=$url1; Url2=$url2;
            AliasUrls = ($Aliases | Where-Object { $_ } | Select-Object -Unique);
            PreferredName=$PreferredName; MimeHint=$MimeHint
        })
    }

    $imgTagPattern = '(?is)<img\b(?:[^>''"]|"[^"]*"|''[^'']*'')*>'
    foreach ($m in [regex]::Matches($Html, $imgTagPattern)) {
        $tag = $m.Value
        $full = [regex]::Match($tag,'(?is)\bdata-fullres-src\s*=\s*["'']([^"'']+)["'']').Groups[1].Value
        $dsrc = [regex]::Match($tag,'(?is)\bdata-src\s*=\s*["'']([^"'']+)["'']').Groups[1].Value
        $src  = [regex]::Match($tag,'(?is)\bsrc\s*=\s*["'']([^"'']+)["'']').Groups[1].Value
        $mime = [regex]::Match($tag,'(?is)\bdata-fullres-src-type\s*=\s*["'']([^"'']+)["'']').Groups[1].Value
        if ([string]::IsNullOrWhiteSpace($mime)) {
            $mime = [regex]::Match($tag,'(?is)\bdata-src-type\s*=\s*["'']([^"'']+)["'']').Groups[1].Value
        }
        $primary = @($full,$dsrc,$src) | Where-Object { $_ -and ($_ -match '/onenote/resources/') } | Select-Object -First 1
        if ($primary) {
            $isImageMime = [string]::IsNullOrWhiteSpace($mime) -or ($mime -match '^image/')
            if ($isImageMime) {
                AddRes "image" $primary @($full,$dsrc,$src) $null $mime
            } else {
                $attName = [regex]::Match($tag,'(?is)\bdata-attachment\s*=\s*["'']([^"'']+)["'']').Groups[1].Value
                AddRes "attachment" $primary @($full,$dsrc,$src) $attName $mime
            }
        }
    }

    $objTagPattern = '(?is)<object\b(?:[^>''"]|"[^"]*"|''[^'']*'')*>'
    foreach ($m in [regex]::Matches($Html, $objTagPattern)) {
        $tag = $m.Value
        $dataUrl = [regex]::Match($tag,'(?is)\bdata\s*=\s*["'']([^"'']+)["'']').Groups[1].Value
        $attach  = [regex]::Match($tag,'(?is)\bdata-attachment\s*=\s*["'']([^"'']+)["'']').Groups[1].Value
        $type    = [regex]::Match($tag,'(?is)\btype\s*=\s*["'']([^"'']+)["'']').Groups[1].Value
        if ($dataUrl -match '/onenote/resources/') { AddRes "attachment" $dataUrl @($dataUrl) $attach $type }
    }

    foreach ($m in [regex]::Matches($Html,'(?is)background-image\s*:\s*url\(([^)]+)\)')) {
        $raw = $m.Groups[1].Value.Trim()
        $url = $raw.Trim('"').Trim("'")
        if ($url -match '/onenote/resources/') { AddRes "image" $url @($url) $null $null }
    }

    $dedup=@{}
    foreach ($r in $list) { if (-not $dedup.ContainsKey($r.Url2)) { $dedup[$r.Url2]=$r } }
    return $dedup.Values
}

# =========================
# DETERMINISTIC FILENAMES
# =========================
function Get-Hash8 {
    param([string]$Text)
    $sha1 = [System.Security.Cryptography.SHA1]::Create()
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($Text)
    $hash = $sha1.ComputeHash($bytes)
    ($hash | ForEach-Object { $_.ToString("x2") }) -join '' | ForEach-Object { $_.Substring(0,4) }
}

function Get-TargetForResource {
    param(
        [Parameter(Mandatory)]$Resource,
        [Parameter(Mandatory)][string]$AttachmentsPath
    )

    $hintExt = MimeToExt $Resource.MimeHint
    if (-not $hintExt) { $hintExt = ".bin" }

    $hash = Get-Hash8 ($Resource.Url2 ?? $Resource.Url1 ?? $Resource.Url)

    if ($Resource.Type -eq "image") {
        $fileName = "img_$hash$hintExt"
    } else {
        $base = [System.Net.WebUtility]::HtmlDecode($Resource.PreferredName)
        if ([string]::IsNullOrWhiteSpace($base)) {
            $fileName = "file_$hash$hintExt"
        } else {
            $safe = Sanitize-FileName $base
            $ext = [System.IO.Path]::GetExtension($safe)
            if ([string]::IsNullOrWhiteSpace($ext)) { $safe = $safe + $hintExt }
            $nameOnly = [System.IO.Path]::GetFileNameWithoutExtension($safe)
            
            if ($nameOnly.Length -gt 80) {
                $nameOnly = $nameOnly.Substring(0,80)
            }
            
            $ext2 = [System.IO.Path]::GetExtension($safe)
            $fileName = "$nameOnly" + "_$hash" + "$ext2"
        }
    }

    $fullPath = Ensure-UniqueFile -Folder $AttachmentsPath -FileName $fileName
    $rel = "attachments/" + (Split-Path $fullPath -Leaf)

    return @{ FullPath=$fullPath; RelPath=$rel; Ext=$hintExt }
}

# =========================
# DOWNLOAD RESOURCE
# =========================
function Download-ResourceToPath {
    param(
        [Parameter(Mandatory)]$Resource,
        [Parameter(Mandatory)][string]$TargetFullPath
    )

    $tryUrls = @($Resource.Url1,$Resource.Url2) | Where-Object { $_ } | Select-Object -Unique
    foreach ($u in $tryUrls) {
        $r = Invoke-GraphHttp -Uri $u -ReturnBytes
        if ($r -and $r.Skipped) {
            return @{ Success=$false; Deferred=$true; Reason=$r.SkipReason; Uri=$u }
        }
        if ($r -and $r.Bytes) {
            [System.IO.File]::WriteAllBytes($TargetFullPath, $r.Bytes)
            try { Unblock-File -LiteralPath $TargetFullPath -ErrorAction SilentlyContinue } catch {}
            return @{ Success=$true; Deferred=$false; Uri=$u }
        }
    }
    return @{ Success=$false; Deferred=$true; Reason="NoBytes"; Uri=($tryUrls | Select-Object -First 1) }
}

# =========================
# SECTIONS (incl. section groups, recursive)
# =========================
function Get-AllNotebookSections {
    param(
        [Parameter(Mandatory)][string]$ResolvedSiteId,
        [Parameter(Mandatory)][string]$NotebookId,
        [string]$SectionGroupId = $null
    )

    $allSections = @()

    if ($SectionGroupId) {
        $uri = "https://graph.microsoft.com/v1.0/sites/$ResolvedSiteId/onenote/sectionGroups/$SectionGroupId/sections"
    } else {
        $uri = "https://graph.microsoft.com/v1.0/sites/$ResolvedSiteId/onenote/notebooks/$NotebookId/sections"
    }
    try {
        $resp = Invoke-GraphJson -Uri $uri
        if ($resp -and $resp.value) { 
            $allSections += $resp.value 
            
            # CRITICAL FIX: Microsoft Graph API does NOT return parentSectionGroup property
            # We must build a list of nested section IDs and filter by ID comparison
            if (-not $SectionGroupId) {
                $beforeFilter = $allSections.Count
                Write-Host "  Get-AllNotebookSections: Building nested section ID list..." -ForegroundColor Magenta
                
                # Get all section groups
                $groupsUri = "https://graph.microsoft.com/v1.0/sites/$ResolvedSiteId/onenote/notebooks/$NotebookId/sectionGroups"
                $nestedSectionIds = @{}
                
                try {
                    $grResp = Invoke-GraphJson -Uri $groupsUri
                    if ($grResp -and $grResp.value) {
                        foreach ($grp in $grResp.value) {
                            $grpSectionsUri = "https://graph.microsoft.com/v1.0/sites/$ResolvedSiteId/onenote/sectionGroups/$($grp.id)/sections"
                            try {
                                $grpSectResp = Invoke-GraphJson -Uri $grpSectionsUri
                                if ($grpSectResp -and $grpSectResp.value) {
                                    foreach ($nestedSec in $grpSectResp.value) {
                                        $nestedSectionIds[$nestedSec.id] = $nestedSec.displayName
                                    }
                                }
                            } catch {
                                Write-Warning "Could not fetch sections for group '$($grp.displayName)': $($_.Exception.Message)"
                            }
                        }
                    }
                } catch {
                    Write-Warning "Could not fetch section groups: $($_.Exception.Message)"
                }
                
                Write-Host "  Found $($nestedSectionIds.Count) nested section(s)" -ForegroundColor Yellow
                
                # Filter by ID
                $allSections = $allSections | Where-Object { -not $nestedSectionIds.ContainsKey($_.id) }
                Write-Host "  ✓ Filtered $($beforeFilter - $allSections.Count) nested sections, keeping $($allSections.Count)" -ForegroundColor Green
            }
        }
    } catch {
        Write-Warning "Could not fetch sections ($uri): $($_.Exception.Message)"
    }

    if ($SectionGroupId) {
        $groupsUri = "https://graph.microsoft.com/v1.0/sites/$ResolvedSiteId/onenote/sectionGroups/$SectionGroupId/sectionGroups"
    } else {
        $groupsUri = "https://graph.microsoft.com/v1.0/sites/$ResolvedSiteId/onenote/notebooks/$NotebookId/sectionGroups"
    }
    try {
        $grResp = Invoke-GraphJson -Uri $groupsUri
        if ($grResp -and $grResp.value) {
            foreach ($grp in $grResp.value) {
                $nested = Get-AllNotebookSections -ResolvedSiteId $ResolvedSiteId -NotebookId $NotebookId -SectionGroupId $grp.id
                $allSections += $nested
            }
        }
    } catch {
        Write-Warning "Could not fetch section groups ($groupsUri): $($_.Exception.Message)"
    }

    return $allSections
}

# =========================
# HIERARCHICAL EXPORT
# =========================
function Export-NotebookSectionsHierarchical {
    param(
        [Parameter(Mandatory)][string]$ResolvedSiteId,
        [Parameter(Mandatory)][string]$NotebookId,
        [Parameter(Mandatory)][string]$ParentFolder,
        [string]$SectionGroupId = $null,
        [Parameter(Mandatory)][hashtable]$NotebookInfo,
        [hashtable]$SelectedPageIds = $null
    )

    # Fetch direct sections of notebook or section group
    if ($SectionGroupId) {
        $uri = "https://graph.microsoft.com/v1.0/sites/$ResolvedSiteId/onenote/sectionGroups/$SectionGroupId/sections"
    } else {
        $uri = "https://graph.microsoft.com/v1.0/sites/$ResolvedSiteId/onenote/notebooks/$NotebookId/sections"
    }
    
    $sections = @()
    try {
        $resp = Invoke-GraphJson -Uri $uri
        if ($resp -and $resp.value) { $sections = $resp.value }
    } catch {
        Write-Warning "Could not fetch sections ($uri): $($_.Exception.Message)"
    }
    
    # CRITICAL FIX: The Microsoft Graph API does NOT return parentSectionGroup property!
    # Instead, we must:
    # 1. Get all section groups
    # 2. Get all sections under those groups (recursively)
    # 3. Build a list of "nested section IDs"
    # 4. Filter top-level sections by excluding IDs that are nested
    if (-not $SectionGroupId) {
        $originalCount = $sections.Count
        Write-Host "    FILTER CHECK: Building nested section ID list..." -ForegroundColor Magenta
        
        # Get all section groups at notebook level
        $groupsUri = "https://graph.microsoft.com/v1.0/sites/$ResolvedSiteId/onenote/notebooks/$NotebookId/sectionGroups"
        $nestedSectionIds = @{}
        
        try {
            $grResp = Invoke-GraphJson -Uri $groupsUri
            if ($grResp -and $grResp.value) {
                Write-Host "    Found $($grResp.value.Count) section group(s) - collecting nested sections..." -ForegroundColor Cyan
                
                foreach ($grp in $grResp.value) {
                    # Get sections under this group (recursively)
                    $grpSectionsUri = "https://graph.microsoft.com/v1.0/sites/$ResolvedSiteId/onenote/sectionGroups/$($grp.id)/sections"
                    try {
                        $grpSectResp = Invoke-GraphJson -Uri $grpSectionsUri
                        if ($grpSectResp -and $grpSectResp.value) {
                            foreach ($nestedSec in $grpSectResp.value) {
                                $nestedSectionIds[$nestedSec.id] = $nestedSec.displayName
                                Write-Host "      📦 Section '$($nestedSec.displayName)' under group '$($grp.displayName)'" -ForegroundColor DarkGray
                            }
                        }
                    } catch {
                        Write-Warning "Could not fetch sections for group '$($grp.displayName)': $($_.Exception.Message)"
                    }
                }
            }
        } catch {
            Write-Warning "Could not fetch section groups: $($_.Exception.Message)"
        }
        
        Write-Host "    Total nested sections found: $($nestedSectionIds.Count)" -ForegroundColor Yellow
        
        # Now filter: remove any section whose ID is in the nested list
        $sectionsBeforeFilter = $sections
        $sections = $sections | Where-Object { -not $nestedSectionIds.ContainsKey($_.id) }
        
        Write-Host "`n    FILTER RESULTS:" -ForegroundColor Magenta
        foreach ($sec in $sectionsBeforeFilter) {
            if ($nestedSectionIds.ContainsKey($sec.id)) {
                Write-Host "    🔴 FILTERED: '$($sec.displayName)' (belongs to section group)" -ForegroundColor Red
            } else {
                Write-Host "    🟢 KEPT: '$($sec.displayName)' (root level)" -ForegroundColor Green
            }
        }
        
        if ($originalCount -ne $sections.Count) {
            Write-Host "`n    ✓✓✓ FILTERED OUT $($originalCount - $sections.Count) sections that belong to section groups" -ForegroundColor Green
            Write-Host "    ✓✓✓ KEEPING $($sections.Count) sections at notebook root level" -ForegroundColor Green
        } else {
            Write-Host "`n    ✓ All $($sections.Count) sections are at root level (no section groups)" -ForegroundColor Cyan
        }
    }

    # Process each section at this level
    foreach ($section in $sections) {
        try {
            $sectionName = Sanitize-FileName $section.displayName
            $sectionName = Smart-Abbreviate $sectionName
            
            if ($sectionName.Length -gt 60) {
                $sectionName = $sectionName.Substring(0,60)
            }
            
            Write-Host "`n    == SECTION: $($section.displayName) ==" -ForegroundColor Cyan
            Write-Host ("       Governor: CurrentDelayMs={0}ms" -f $script:CurrentDelayMs) -ForegroundColor DarkGray
            
            $pages = Get-SectionPagesRobust -ResolvedSiteId $ResolvedSiteId -SectionId $section.id
            
            # DON'T filter pages here - we need ALL pages to maintain hierarchy
            # We'll check $SelectedPageIds per page to decide whether to export HTML
            
            $pagesToExport = 0
            if ($SelectedPageIds) {
                # Count how many pages will actually be exported
                $pagesToExport = ($pages | Where-Object { 
                    $key = "$ResolvedSiteId|$($section.id)|$($_.id)"
                    $SelectedPageIds.ContainsKey($key)
                }).Count
                Write-Host ("       Pages found: {0} total, {1} to export" -f $pages.Count, $pagesToExport) -ForegroundColor Yellow
                if ($pagesToExport -eq 0) {
                    Write-Host "       Section skipped (geen geselecteerde pagina's)" -ForegroundColor DarkGray
                    continue
                }
            } else {
                Write-Host ("       Pages found (incl. subpages): {0}" -f $pages.Count) -ForegroundColor Yellow
            }

            $sectionPath = Join-Path $ParentFolder $sectionName
            New-Item -ItemType Directory -Path $sectionPath -Force | Out-Null
            
            # DIAGNOSTIC: Track parent-child relationships for debugging
            $hierarchyDebug = @()
            
            # Track processed pages for parent lookup
            $processedPages = @()
            $pageIdToFolder = @{}  # Map page ID to its folder for explicit parent lookup
            $fallbackOrder = 0
            
            foreach ($page in $pages) {
                Start-Sleep -Milliseconds $ExtraDelayBetweenPagesMs
                
                $fallbackOrder++
                $level = if ($null -ne $page.level) { [int]$page.level } else { 0 }
                $order = if ($null -ne $page.order) { [int]$page.order } else { $fallbackOrder }
                $title = if ([string]::IsNullOrWhiteSpace($page.title)) { "Untitled" } else { $page.title }

                # Prefer title from dedup-selected metadata when filtering is active.
                # This avoids occasional malformed Graph page.title values in hierarchical listing calls.
                $pageKey = $null
                if ($SelectedPageIds) {
                    $pageKey = "$ResolvedSiteId|$($section.id)|$($page.id)"
                    if ($SelectedPageIds.ContainsKey($pageKey)) {
                        $selectedPage = $SelectedPageIds[$pageKey]
                        if ($selectedPage -and -not [string]::IsNullOrWhiteSpace([string]$selectedPage.PageTitle)) {
                            $title = [string]$selectedPage.PageTitle
                        }
                    }
                }
                
                if ($level -lt 0) { $level = 0 }
                
                $parent = $sectionPath
                $selectedParentLevel = -1
                $parentMethod = "section"
                
                # FIRST: Try explicit parent reference from Graph API
                if ($page.parentReference -and $page.parentReference.id) {
                    $parentId = $page.parentReference.id
                    if ($pageIdToFolder.ContainsKey($parentId)) {
                        $parent = $pageIdToFolder[$parentId]
                        $selectedParentLevel = "byId"
                        $parentMethod = "parentReference"
                    }
                }
                
                # FALLBACK: If no explicit parent, scan backwards for lower level
                if ($selectedParentLevel -eq -1 -and $level -gt 0) {
                    for ($i = $processedPages.Count - 1; $i -ge 0; $i--) {
                        $candidate = $processedPages[$i]
                        if ($candidate.Level -lt $level) {
                            $parent = $candidate.PageFolder
                            $selectedParentLevel = $candidate.Level
                            $parentMethod = "fallback-level"
                            break
                        }
                    }
                }
                
                # DIAGNOSTIC logging
                $hierarchyDebug += [PSCustomObject]@{
                    PageTitle = $title
                    Level = $level
                    Order = $order
                    ParentLevel = $selectedParentLevel
                    ParentMethod = $parentMethod
                }
                
                $sanitizedTitle = Sanitize-FileName $title
                $sanitizedTitle = Smart-Abbreviate $sanitizedTitle
                
                if ($sanitizedTitle.Length -gt 80) {
                    $sanitizedTitle = $sanitizedTitle.Substring(0,80)
                }
                
                $exactFolder    = Join-Path $parent $sanitizedTitle
                if (Test-Path $exactFolder) {
                    $pageFolder = $exactFolder
                } else {
                    $pageFolder = Ensure-UniqueFolder -Folder $parent -Name $sanitizedTitle
                    New-Item -ItemType Directory -Path $pageFolder -Force | Out-Null
                }
                
                # Track this page for potential children
                $processedPages += @{
                    Title = $title
                    Level = $level
                    Order = $order
                    PageFolder = $pageFolder
                }
                
                # Register page folder by ID for explicit parent lookup
                $pageIdToFolder[$page.id] = $pageFolder
                
                # Check if this page should be exported (when filtering is active)
                $shouldExport = $true
                if ($SelectedPageIds) {
                    $key = if ($pageKey) { $pageKey } else { "$ResolvedSiteId|$($section.id)|$($page.id)" }
                    $shouldExport = $SelectedPageIds.ContainsKey($key)
                    
                    if (-not $shouldExport) {
                        # Skip HTML export but keep folder for hierarchy (subpages may need it)
                        Write-Host ("      -> [{0}] (level {1}) {2} (hierarchy only - not selected)" -f $order,$level,$title) -ForegroundColor DarkGray
                        continue
                    }
                }
                
                $attachmentsPath = Join-Path $pageFolder "attachments"
                New-Item -ItemType Directory -Path $attachmentsPath -Force | Out-Null
                
                $pageHtmlPath = Join-Path $pageFolder "page.html"
                if (Test-Path $pageHtmlPath) {
                    $existingContent = Get-Content $pageHtmlPath -Raw -Encoding UTF8 -ErrorAction SilentlyContinue
                    $isEmptyFallback = [string]::IsNullOrWhiteSpace($existingContent) -or
                                       ($existingContent -match '(?is)<body[^>]*>\s*</body>')
                    $hasUnresolvedResources = (-not $isEmptyFallback) -and
                                              ($existingContent -match 'https://graph\.microsoft\.com/[^"''<>\s]+/onenote/resources/')
                    $hasNonImageRefs = (-not $isEmptyFallback) -and
                                       ($existingContent -match '(?is)<img\b[^>]+\bsrc\s*=\s*"attachments/[^"]+\.(bin|vsd|vsdx|doc|docx|xls|xlsx|ppt|pptx|pdf|zip|msg)"')
                    if (-not $isEmptyFallback -and -not $hasUnresolvedResources -and -not $hasNonImageRefs) {
                        Write-Host ("      -> [{0}] (level {1}) {2} (resume)" -f $order,$level,$title) -ForegroundColor DarkGray
                        continue
                    }
                    if ($isEmptyFallback) {
                        Write-Host ("      -> [{0}] (level {1}) {2} (retry: lege fallback)" -f $order,$level,$title) -ForegroundColor Yellow
                    } elseif ($hasNonImageRefs) {
                        Write-Host ("      -> [{0}] (level {1}) {2} (retry: non-image in <img> tag)" -f $order,$level,$title) -ForegroundColor Yellow
                    } else {
                        Write-Host ("      -> [{0}] (level {1}) {2} (retry: onopgeloste resource URLs)" -f $order,$level,$title) -ForegroundColor Yellow
                    }
                }

                Write-Host ("      -> [{0}] (level {1}) {2}" -f $order,$level,$title)

                # Reset per-page URI throttle counts
                $script:ThrottleCounts = @{}
                
                # Apply adaptive delay based on mode
                $currentPageDelay = if ($script:UltraConservativeMode) { $UltraDelayBetweenPagesMs } else { $ExtraDelayBetweenPagesMs }
                Start-Sleep -Milliseconds $currentPageDelay

                # Download HTML
                $contentUri = "https://graph.microsoft.com/v1.0/sites/$ResolvedSiteId/onenote/pages/$($page.id)/content"
                $html = $null
                for ($attempt = 1; $attempt -le 2; $attempt++) {
                    if ($attempt -gt 1) {
                        Write-Warning "      Page content leeg/gefaald — herpoging over 20s..."
                        Start-Sleep -Seconds 20
                    }
                    $tmp = [System.IO.Path]::GetTempFileName()
                    $dlResult = Invoke-GraphHttp -Uri $contentUri -OutFile $tmp
                    if (-not $dlResult.Skipped -and (Test-Path $tmp)) {
                        $html = Get-Content $tmp -Raw -Encoding UTF8
                    }
                    Remove-Item $tmp -Force -ErrorAction SilentlyContinue
                    if (-not [string]::IsNullOrWhiteSpace($html)) { break }
                }

                if ([string]::IsNullOrWhiteSpace($html)) {
                    Write-Warning ("      Toegevoegd aan Phase 2b herstel: {0}" -f $title)
                    $script:FailedPages.Add([pscustomobject]@{
                        SiteId          = $ResolvedSiteId
                        PageId          = $page.id
                        PageTitle       = $title
                        PageFolder      = $pageFolder
                        AttachmentsPath = $attachmentsPath
                    })
                    continue
                }
                
                $html = Render-NoteTagsToCheckboxes $html

                # Extract and download resources
                $resources = Extract-OneNoteResources $html
                $urlToLocal = @{}
                $attachmentMap = @{}
                
                foreach ($r in $resources) {
                    # Apply adaptive delay based on mode
                    $currentResourceDelay = if ($script:UltraConservativeMode) { $UltraDelayBetweenResourcesMs } else { $ExtraDelayBetweenResourcesMs }
                    Start-Sleep -Milliseconds $currentResourceDelay
                    
                    $target = Get-TargetForResource -Resource $r -AttachmentsPath $attachmentsPath
                    foreach ($u in $r.AliasUrls) { if ($u) { $urlToLocal[$u] = $target.RelPath } }
                    
                    if (-not (Test-Path $target.FullPath)) {
                        $dl = Download-ResourceToPath -Resource $r -TargetFullPath $target.FullPath
                        
                        # Magic bytes detection
                        if ($dl.Success -and $target.Ext -eq ".bin" -and (Test-Path $target.FullPath)) {
                            $dlBytes = [System.IO.File]::ReadAllBytes($target.FullPath)
                            $detectedExt = DetectExtFromMagicBytes $dlBytes
                            if ($detectedExt -and $detectedExt -ne ".bin") {
                                $newFullPath = [System.IO.Path]::ChangeExtension($target.FullPath, $detectedExt)
                                if (-not (Test-Path $newFullPath)) {
                                    Rename-Item -LiteralPath $target.FullPath -NewName (Split-Path $newFullPath -Leaf) -Force -ErrorAction SilentlyContinue
                                }
                                if (Test-Path $newFullPath) {
                                    $newRelPath = "attachments/" + (Split-Path $newFullPath -Leaf)
                                    foreach ($u in $r.AliasUrls) { if ($u) { $urlToLocal[$u] = $newRelPath } }
                                    if ($r.Type -eq "attachment" -and -not [string]::IsNullOrWhiteSpace($r.PreferredName)) {
                                        $decodedKey = [System.Net.WebUtility]::HtmlDecode($r.PreferredName)
                                        $attachmentMap[$decodedKey] = $newRelPath
                                    }
                                    # EMF → PNG conversion
                                    if ($newFullPath -like "*.emf") {
                                        $pngFull = [System.IO.Path]::ChangeExtension($newFullPath, ".png")
                                        if (-not (Test-Path $pngFull) -and (Convert-EmfToPng -EmfPath $newFullPath -PngPath $pngFull)) {
                                            $pngRel = "attachments/" + (Split-Path $pngFull -Leaf)
                                            foreach ($u in $r.AliasUrls) { if ($u) { $urlToLocal[$u] = $pngRel } }
                                            Write-Host "    EMF→PNG: $(Split-Path $pngFull -Leaf)" -ForegroundColor Green
                                        }
                                    }
                                }
                            }
                        }

                        # Set attachmentMap for successful downloads
                        if ($dl.Success -and $r.Type -eq "attachment" -and -not [string]::IsNullOrWhiteSpace($r.PreferredName)) {
                            $decodedKey = [System.Net.WebUtility]::HtmlDecode($r.PreferredName)
                            if (-not $attachmentMap.ContainsKey($decodedKey)) {
                                $attachmentMap[$decodedKey] = $target.RelPath
                            }
                        }
                        
                        if (-not $dl.Success) {
                            $script:MissingResources.Add([pscustomobject]@{
                                PageTitle = $title
                                AttachmentsPath = $attachmentsPath
                                TargetFullPath = $target.FullPath
                                ResourceUrl1 = $r.Url1
                                ResourceUrl2 = $r.Url2
                                ResourceType = $r.Type
                                PreferredName = $r.PreferredName
                                MimeHint = $r.MimeHint
                            })
                        }
                    }
                }
                
                # Rewrite URLs
                foreach ($kv in $urlToLocal.GetEnumerator()) {
                    $html = $html.Replace($kv.Key, $kv.Value)
                }

                # Convert non-image <img> tags to download links
                $imgTagPatternLocal = '(?is)<img\b(?:[^>''"]|"[^"]*"|''[^'']*'')*>'
                $html = [regex]::Replace($html, $imgTagPatternLocal, {
                    param($mImg)
                    $tag2 = $mImg.Value
                    $imgSrc = [regex]::Match($tag2,'(?is)\bsrc\s*=\s*["'']([^"'']+)["'']').Groups[1].Value
                    if ($imgSrc -match '^attachments/' -and $imgSrc -notmatch '(?i)\.(png|jpg|jpeg|gif|bmp|svg|webp)$') {
                        $attName2 = [regex]::Match($tag2,'(?is)\bdata-attachment\s*=\s*["'']([^"'']+)["'']').Groups[1].Value
                        if ([string]::IsNullOrWhiteSpace($attName2)) {
                            $attName2 = [System.IO.Path]::GetFileName($imgSrc)
                        }
                        $safeName2 = [System.Web.HttpUtility]::HtmlEncode([System.Net.WebUtility]::HtmlDecode($attName2))
                        return "<a href=`"$imgSrc`" download>📎 $safeName2</a>"
                    }
                    return $tag2
                })

                $html = Replace-ObjectAttachmentsInline -Html $html -AttachmentMap $attachmentMap
                $html = Inject-AttachmentsBlockBottom -Html $html -AttachmentsPath $attachmentsPath
                
                $html | Out-File $pageHtmlPath -Encoding UTF8
                $script:ExportedPageCount++
            }
            
            # DIAGNOSTIC OUTPUT: Print hierarchy summary for this section
            if ($hierarchyDebug.Count -gt 3) {
                Write-Host "`n      📊 HIERARCHY DIAGNOSTICS for section '$($section.displayName)':" -ForegroundColor Cyan
                foreach ($hd in $hierarchyDebug | Select-Object -First 10) {
                    $parentDesc = if ($hd.ParentLevel -ge 0) { "level[$($hd.ParentLevel)]" } else { "section" }
                    Write-Host "         [$($hd.Order)] L$($hd.Level) → parent:$parentDesc | '$($hd.PageTitle)'" -ForegroundColor Gray
                }
                if ($hierarchyDebug.Count -gt 10) { Write-Host "         ... ($($hierarchyDebug.Count - 10) more pages)" -ForegroundColor DarkGray }
            }
            
            # Section finished cooldown
            Write-Host "      Section finished. Cooling down..." -ForegroundColor Yellow
            Start-Sleep -Seconds 5
        } catch {
            Write-Host "    ✗ Fout bij sectie '$($section.displayName)': $($_.Exception.Message)" -ForegroundColor Red
        }
    }

    # Now fetch and process nested section groups
    if ($SectionGroupId) {
        $groupsUri = "https://graph.microsoft.com/v1.0/sites/$ResolvedSiteId/onenote/sectionGroups/$SectionGroupId/sectionGroups"
    } else {
        $groupsUri = "https://graph.microsoft.com/v1.0/sites/$ResolvedSiteId/onenote/notebooks/$NotebookId/sectionGroups"
    }
    
    $sectionGroups = @()
    try {
        $grResp = Invoke-GraphJson -Uri $groupsUri
        if ($grResp -and $grResp.value) { $sectionGroups = $grResp.value }
    } catch {
        Write-Warning "Could not fetch section groups ($groupsUri): $($_.Exception.Message)"
    }

    # Process each section group recursively
    foreach ($grp in $sectionGroups) {
        $groupName = Sanitize-FileName $grp.displayName
        $groupName = Smart-Abbreviate $groupName
        
        if ($groupName.Length -gt 60) {
            $groupName = $groupName.Substring(0,60)
        }
        
        $groupPath = Join-Path $ParentFolder $groupName
        New-Item -ItemType Directory -Path $groupPath -Force | Out-Null
        
        Write-Host "`n  ┌─ SECTION GROUP: $($grp.displayName)" -ForegroundColor Magenta
        
        # Recursively export this section group
        $callParams = @{
            ResolvedSiteId = $ResolvedSiteId
            NotebookId = $NotebookId
            ParentFolder = $groupPath
            SectionGroupId = $grp.id
            NotebookInfo = $NotebookInfo
        }
        if ($SelectedPageIds) {
            $callParams['SelectedPageIds'] = $SelectedPageIds
        }
        Export-NotebookSectionsHierarchical @callParams
        
        Write-Host "  └─ END SECTION GROUP: $($grp.displayName)" -ForegroundColor Magenta
    }
}

# =========================
# WARMUP
# =========================
function Warmup {
    param([string]$ResolvedSiteId)
    if ($InitialCooldownSec -gt 0) {
        Write-Host "`nInitial cooldown to reduce immediate OneNote throttling..." -ForegroundColor Yellow
        Start-Sleep -Seconds $InitialCooldownSec
    } else {
        Write-Host "`nInitial cooldown overgeslagen (disabled)." -ForegroundColor Gray
    }
    Write-Host "Warmup phase (light calls)..." -ForegroundColor Yellow
    try {
        Invoke-GraphJson -Uri "https://graph.microsoft.com/v1.0/sites/$ResolvedSiteId" | Out-Null
    } catch {}
    Start-Sleep -Seconds $WarmupGapSec
    try {
        Invoke-GraphJson -Uri "https://graph.microsoft.com/v1.0/sites/$ResolvedSiteId/onenote/notebooks" | Out-Null
    } catch {}
    Start-Sleep -Seconds $WarmupGapSec
    Write-Host "Warmup complete. Starting export with conservative pacing..." -ForegroundColor Green
}

Write-Verbose "Common-OneNoteExport.ps1 geladen"
