﻿<#
.SYNOPSIS
    Batch OneNote export met queue-management voor overnight runs
    
.DESCRIPTION
    Dit script laadt alle vaults uit RDM, laat gebruiker vaults selecteren,
    verzamelt VOORAF alle doelfolders, en exporteert vervolgens alle geselecteerde
    vaults achtereenvolgens zonder verdere user-interactie.
    
    Ideaal voor overnight bulk-exports met meerdere klanten.
    
.PARAMETER DataSourceName
    RDM DataSource naam (bijv. "E.S.C. Azure - backup")
    
.PARAMETER DefaultExportRoot
    Root directory voor exports (default: C:\Temp)
    
.PARAMETER SkipCleanup
    Skip het leegmaken van notebooks na export
    
.PARAMETER AutoConfirmQueue
    Skip de review prompt en start direct met export
    
.PARAMETER PostExportScript
    Optioneel: Script aan te roepen na export (bijv. voor import naar RDM)
    
.EXAMPLE
    .\Bulk-Export-OneNote-Queue.ps1 -DataSourceName "E.S.C. Azure - backup"
    
.EXAMPLE
    .\Bulk-Export-OneNote-Queue.ps1 -DataSourceName "E.S.C. Azure - backup" `
        -DefaultExportRoot "D:\OneNote-Exports" `
        -AutoConfirmQueue `
        -PostExportScript ".\Import-Client-ToRDM2.ps1"
#>

[CmdletBinding()]
param(
    [string]$DataSourceName,
    [switch]$UseRDM,
    [string]$DataSourceUsername,
    [securestring]$DataSourcePassword,
    [switch]$PromptForDataSourceCredential,
    [string]$DefaultExportRoot = "C:\Temp",
    [switch]$SkipCleanup,
    [switch]$AutoConfirmQueue,
    [string]$PostExportScript,
    [string]$CompletedCustomersFile = ".\logs\bulk-export-completed-customers.txt",
    [string]$VaultCacheFile = ".\cache\rdm-vaults.json",
    [string]$QueueConfigPath,
    [switch]$GenerateQueueConfigOnly
)

# =========================
# DISABLE QUICK EDIT MODE
# Prevents ConHost from pausing the process when user clicks the console window
# (default Windows behavior that breaks unattended overnight runs)
# =========================
try {
    $consoleHelperCode = @"
using System;
using System.Runtime.InteropServices;
public class ConsoleQuickEdit {
    const uint ENABLE_QUICK_EDIT = 0x0040;
    const uint ENABLE_EXTENDED_FLAGS = 0x0080;
    [DllImport("kernel32.dll", SetLastError = true)]
    static extern IntPtr GetStdHandle(int nStdHandle);
    [DllImport("kernel32.dll")]
    static extern bool GetConsoleMode(IntPtr handle, out uint mode);
    [DllImport("kernel32.dll")]
    static extern bool SetConsoleMode(IntPtr handle, uint mode);
    public static void Disable() {
        IntPtr handle = GetStdHandle(-10);
        uint mode;
        if (GetConsoleMode(handle, out mode)) {
            mode &= ~ENABLE_QUICK_EDIT;
            mode |= ENABLE_EXTENDED_FLAGS;
            SetConsoleMode(handle, mode);
        }
    }
}
"@
    if (-not ([System.Management.Automation.PSTypeName]'ConsoleQuickEdit').Type) {
        Add-Type -TypeDefinition $consoleHelperCode
    }
    [ConsoleQuickEdit]::Disable()
} catch {
    # Non-fatal: Quick Edit Mode stays on, but script continues
}

# =========================
# =========================
# LOGGING SETUP
# =========================
$script:LogDir = Join-Path $PSScriptRoot "logs"
New-Item -ItemType Directory -Path $script:LogDir -Force | Out-Null
$script:LogFile = Join-Path $script:LogDir "exportlog$(Get-Date -Format 'ddMMyyyyHHmmss').log"
$script:SelectedSitesFileName = "onenote-selected-sites.json"

function Write-Log {
    param(
        [string]$Message,
        [ValidateSet('INFO','WARN','ERROR','SUCCESS')][string]$Level = 'INFO'
    )
    $ts = Get-Date -Format 'dd/MM/yyyy HH:mm:ss'
    $line = "[$ts] [$Level] $Message"
    Add-Content -Path $script:LogFile -Value $line -Encoding UTF8
}

Write-Log "Logbestand aangemaakt: $script:LogFile"

# BANNER
# =========================
Write-Host "`n╔══════════════════════════════════════════════════════════════╗" -ForegroundColor Cyan
Write-Host "║  BULK ONENOTE EXPORT MET QUEUE MANAGEMENT                  ║" -ForegroundColor Cyan
Write-Host "║  Batch export overnight - geen user interactie nodig       ║" -ForegroundColor Cyan
Write-Host "╚══════════════════════════════════════════════════════════════╝`n" -ForegroundColor Cyan

# =========================
# LOAD RDMCLIENT
# =========================
try {
    Import-Module Devolutions.PowerShell -ErrorAction Stop
    $script:RdmModuleAvailable = $true
    Write-Host "✓ Devolutions.PowerShell geladen`n" -ForegroundColor Green
} catch {
    $script:RdmModuleAvailable = $false
    Write-Warning "Devolutions.PowerShell niet beschikbaar. RDM vault-selectie is niet mogelijk."
}

# =========================
# LOAD COMMON EXPORT FUNCTIONS
# =========================
$commonScript = Join-Path $PSScriptRoot "Common-OneNoteExport.ps1"
if (-not (Test-Path $commonScript)) {
    Write-Error "FOUT: Common-OneNoteExport.ps1 niet gevonden in $PSScriptRoot"
    exit 1
}

Write-Host "Loading Common-OneNoteExport.ps1..." -ForegroundColor Gray
. $commonScript
Write-Host "✓ Common export functions geladen`n" -ForegroundColor Green

function Start-QueueThrottleCooldown {
    param(
        [int]$Seconds = 1800,
        [string]$Reason = "HTTP 429 throttling"
    )

    Write-Host "`n⏸️  Queue cooldown gestart ($Reason)" -ForegroundColor Yellow
    Write-Log "Queue cooldown gestart: $Reason ($([math]::Round($Seconds / 60, 1)) min)" 'WARN'
    Write-Host "   Pauze: $([math]::Round($Seconds / 60, 1)) minuten" -ForegroundColor Yellow

    for ($remaining = $Seconds; $remaining -gt 0; $remaining--) {
        $ts = [timespan]::FromSeconds($remaining)
        $timerText = "{0:D2}:{1:D2}:{2:D2}" -f $ts.Hours, $ts.Minutes, $ts.Seconds
        $pct = [int](($Seconds - $remaining) / $Seconds * 100)
        Write-Progress -Activity "⏸️  Queue cooldown ($Reason)" -Status "Hervat over: $timerText" -PercentComplete $pct
        if (($Seconds - $remaining) % 300 -eq 0 -and $remaining -lt $Seconds) {
            $minLeft = [math]::Round($remaining / 60, 1)
            Write-Log "Cooldown actief - nog $minLeft minuten te wachten" 'INFO'
        }
        Start-Sleep -Seconds 1
    }
    Write-Progress -Activity "⏸️  Queue cooldown ($Reason)" -Completed

    Write-Host "✓ Queue cooldown voltooid, export wordt hervat`n" -ForegroundColor Green
    Write-Log "Queue cooldown voltooid" 'INFO'
}

function Parse-SelectionIndices {
    <#
    .SYNOPSIS
    Parse selectie input zoals: 0,2,5-8 of alle/all
    #>
    param(
        [Parameter(Mandatory)][string]$InputText,
        [Parameter(Mandatory)][int]$MaxCount,
        [switch]$AllowAll
    )

    $text = $InputText.Trim()
    if ($AllowAll -and ($text -eq 'alle' -or $text -eq 'all')) {
        return @(0..($MaxCount - 1))
    }

    $selected = New-Object System.Collections.Generic.List[int]
    $seen = @{}

    foreach ($rawPart in ($text -split ',')) {
        $part = $rawPart.Trim()
        if ([string]::IsNullOrWhiteSpace($part)) { continue }

        if ($part -match '^(\d+)\s*-\s*(\d+)$') {
            $start = [int]$matches[1]
            $end = [int]$matches[2]
            if ($start -gt $end) {
                $tmp = $start
                $start = $end
                $end = $tmp
            }

            for ($i = $start; $i -le $end; $i++) {
                if ($i -lt 0 -or $i -ge $MaxCount) {
                    throw "Index buiten bereik: $i (geldig: 0-$($MaxCount - 1))"
                }
                if (-not $seen.ContainsKey($i)) {
                    $seen[$i] = $true
                    $selected.Add($i)
                }
            }
            continue
        }

        if ($part -match '^\d+$') {
            $i = [int]$part
            if ($i -lt 0 -or $i -ge $MaxCount) {
                throw "Index buiten bereik: $i (geldig: 0-$($MaxCount - 1))"
            }
            if (-not $seen.ContainsKey($i)) {
                $seen[$i] = $true
                $selected.Add($i)
            }
            continue
        }

        throw "Ongeldig selectie-element: '$part'"
    }

    return @($selected)
}

function Save-CustomerSelectedSitesFile {
    <#
    .SYNOPSIS
    Bewaar geselecteerde SharePoint sites in de klantmap zodat opvolgscripts ze kunnen hergebruiken
    #>
    param(
        [Parameter(Mandatory)][string]$DestinationFolder,
        [Parameter(Mandatory)][string]$VaultName,
        [Parameter(Mandatory)][object[]]$SelectedSites
    )

    if ([string]::IsNullOrWhiteSpace($DestinationFolder)) { return }
    if (-not $SelectedSites -or $SelectedSites.Count -eq 0) { return }

    try {
        New-Item -ItemType Directory -Path $DestinationFolder -Force | Out-Null

        $sites = @()
        foreach ($site in @($SelectedSites)) {
            if (-not $site) { continue }
            $title = [string]($site.Title ?? "")
            $url = [string]($site.Url ?? "")
            if ([string]::IsNullOrWhiteSpace($title) -or [string]::IsNullOrWhiteSpace($url)) { continue }

            $sites += [pscustomobject]@{
                Title = $title
                Url = $url
                Score = if ($site.PSObject.Properties.Name -contains 'Score') { $site.Score } else { $null }
            }
        }

        if ($sites.Count -eq 0) { return }

        $payload = [pscustomobject]@{
            Version = 1
            SourceScript = 'Bulk-Export-OneNote-Queue.ps1'
            VaultName = [string]$VaultName
            SavedAt = (Get-Date).ToString('o')
            SelectedSites = $sites
        }

        $targetPath = Join-Path $DestinationFolder $script:SelectedSitesFileName
        $payload | ConvertTo-Json -Depth 8 | Set-Content -Path $targetPath -Encoding UTF8
        Write-Host "  ✓ Site-selectie opgeslagen: $targetPath" -ForegroundColor DarkGray
        Write-Log "Site-selectie opgeslagen: $targetPath (sites: $($sites.Count))" 'INFO'
    } catch {
        Write-Warning "Kon site-selectie niet opslaan in '$DestinationFolder': $($_.Exception.Message)"
        Write-Log "Kon site-selectie niet opslaan in '$DestinationFolder': $($_.Exception.Message)" 'WARN'
    }
}

# =========================
# HELPER FUNCTIONS
# =========================

function Get-RDMVaultList {
    <#
    .SYNOPSIS
    Laad alle beschikbare vaults uit RDM datasource
    #>
    param(
        [Parameter(Mandatory)][string]$DataSourceName,
        [string]$DataSourceUsername,
        [securestring]$DataSourcePassword,
        [switch]$PromptForDataSourceCredential
    )
    
    try {
        $ds = Get-RDMDataSource -Name $DataSourceName -ErrorAction Stop
        if (-not $ds) {
            throw "Data source '$DataSourceName' niet gevonden"
        }

        try {
            $currentDs = Get-RDMCurrentDataSource -ErrorAction Stop
            $isSameDataSource = $false
            if ($currentDs) {
                if ($currentDs.PSObject.Properties.Name -contains 'ID' -and $ds.PSObject.Properties.Name -contains 'ID' -and $currentDs.ID -eq $ds.ID) {
                    $isSameDataSource = $true
                } elseif (-not [string]::IsNullOrWhiteSpace($currentDs.Name) -and $currentDs.Name -ieq $DataSourceName) {
                    $isSameDataSource = $true
                }
            }

            if ($isSameDataSource -and ($currentDs.PSObject.Properties.Name -contains 'IsConnected') -and $currentDs.IsConnected) {
                Write-Host "✓ Bestaande RDM sessie gevonden voor datasource '$DataSourceName'" -ForegroundColor Green
                return @(Get-RDMRepository -ErrorAction Stop)
            }
        } catch {
            # Geen actieve/current datasource context beschikbaar; verder met normale connectieflow
        }

        $connectErrors = New-Object System.Collections.Generic.List[string]
        $connected = $false

        $credentialAttempted = $false

        $fallbackUsername = $DataSourceUsername
        $fallbackPassword = $DataSourcePassword

        if ([string]::IsNullOrWhiteSpace($fallbackUsername) -and -not [string]::IsNullOrWhiteSpace($env:RDM_DATASOURCE_USERNAME)) {
            $fallbackUsername = $env:RDM_DATASOURCE_USERNAME
        }

        if (-not $fallbackPassword -and -not [string]::IsNullOrWhiteSpace($env:RDM_DATASOURCE_PASSWORD)) {
            $fallbackPassword = ConvertTo-SecureString $env:RDM_DATASOURCE_PASSWORD -AsPlainText -Force
        }

        $isSqlDataSource = $false
        if ($ds.PSObject.Properties.Name -contains 'Type') {
            $isSqlDataSource = ([string]$ds.Type -ieq 'SQLServer')
        }

        if ($isSqlDataSource -and -not $fallbackPassword) {
            $currentForPreflight = $null
            try {
                $currentForPreflight = Get-RDMCurrentDataSource -ErrorAction Stop
            } catch {}

            $currentMatchesTarget = $false
            if ($currentForPreflight) {
                if ($currentForPreflight.PSObject.Properties.Name -contains 'ID' -and $ds.PSObject.Properties.Name -contains 'ID' -and $currentForPreflight.ID -eq $ds.ID) {
                    $currentMatchesTarget = $true
                } elseif (-not [string]::IsNullOrWhiteSpace($currentForPreflight.Name) -and $currentForPreflight.Name -ieq $DataSourceName) {
                    $currentMatchesTarget = $true
                }
            }

            $currentIsConnected = $false
            if ($currentMatchesTarget -and $currentForPreflight -and ($currentForPreflight.PSObject.Properties.Name -contains 'IsConnected') -and $currentForPreflight.IsConnected) {
                $currentIsConnected = $true
            }

            if (-not $currentIsConnected) {
                throw "SQL datasource '$DataSourceName' is niet verbonden in de huidige PowerShell-module context. Voor deze datasource werkt AAD Interactive uit de RDM UI niet automatisch in externe pwsh-sessies. Gebruik een reeds connected datasource in deze sessie, of geef -DataSourcePassword mee (of RDM_DATASOURCE_PASSWORD)."
            }
        }

        $oauthConnectionAttempted = $false

        if (-not $connected -and -not [string]::IsNullOrWhiteSpace($fallbackUsername) -and $fallbackPassword) {
            $credentialAttempted = $true
            try {
                Set-RDMCurrentDataSource -DataSource $ds -Username $fallbackUsername -Password $fallbackPassword -ErrorAction Stop | Out-Null
                $connected = $true
                Write-Host "✓ Datasource verbonden met expliciete inloggegevens ($fallbackUsername)" -ForegroundColor Green
            } catch {
                $connectErrors.Add("Datasource-login met expliciete inloggegevens mislukt: $($_.Exception.Message)")
            }
        }

        if (-not $connected -and -not $isSqlDataSource) {
            try {
                $setCmd = Get-Command Set-RDMCurrentDataSource -ErrorAction Stop
                $canUseOAuthToken = $setCmd.Parameters.ContainsKey('OAuthToken')
                if ($canUseOAuthToken -and (Get-Command Get-RDMOAuthToken -ErrorAction SilentlyContinue)) {
                    $oauthConnectionAttempted = $true
                    $oauthToken = Get-RDMOAuthToken -ErrorAction Stop

                    $tokenIsUsable = $false
                    if ($oauthToken -is [string]) {
                        $tokenIsUsable = -not [string]::IsNullOrWhiteSpace($oauthToken)
                    } elseif ($null -ne $oauthToken) {
                        $tokenString = [string]$oauthToken
                        $tokenIsUsable = -not [string]::IsNullOrWhiteSpace($tokenString)
                    }

                    if ($tokenIsUsable) {
                        Set-RDMCurrentDataSource -DataSource $ds -OAuthToken $oauthToken -ErrorAction Stop | Out-Null
                        $connected = $true
                        Write-Host "✓ Datasource verbonden via OAuth-token" -ForegroundColor Green
                    } else {
                        $connectErrors.Add("OAuth-token beschikbaarheid: lege of onbruikbare tokenwaarde")
                    }
                }
            } catch {
                $connectErrors.Add("Datasource-login met OAuth-token mislukt: $($_.Exception.Message)")
            }
        }

        if (-not $connected) {
            try {
                if ($isSqlDataSource) {
                    Set-RDMCurrentDataSource -DataSource $ds -ForcePromptAnswer ([System.Windows.Forms.DialogResult]::Yes) -ErrorAction Stop | Out-Null
                } else {
                    Set-RDMCurrentDataSource -DataSource $ds -ErrorAction Stop | Out-Null
                }
                $connected = $true
            } catch {
                $connectErrors.Add("Standaard datasource-login mislukt: $($_.Exception.Message)")
            }
        }

        if (-not $connected -and $isSqlDataSource -and -not [string]::IsNullOrWhiteSpace($fallbackUsername)) {
            $hasLoginError = $false
            foreach ($errText in $connectErrors) {
                if ($errText -match 'requested by the login|The login failed|Cannot open server') {
                    $hasLoginError = $true
                    break
                }
            }

            if ($hasLoginError -and (Get-Command Repair-RDMUserSqlLogin -ErrorAction SilentlyContinue) -and (Get-Command Get-RDMUser -ErrorAction SilentlyContinue)) {
                try {
                    Write-Host "↻ Poging SQL-login herstel voor gebruiker '$fallbackUsername'..." -ForegroundColor Yellow
                    $userInfo = Get-RDMUser -Name $fallbackUsername -ErrorAction Stop | Select-Object -First 1
                    if ($userInfo) {
                        Repair-RDMUserSqlLogin -InputObject $userInfo -ForcePromptAnswer ([System.Windows.Forms.DialogResult]::Yes) -ErrorAction Stop | Out-Null
                        Write-Host "✓ SQL-login herstel uitgevoerd, herprobeer datasource connectie..." -ForegroundColor Green

                        if (-not [string]::IsNullOrWhiteSpace($fallbackUsername) -and $fallbackPassword) {
                            Set-RDMCurrentDataSource -DataSource $ds -Username $fallbackUsername -Password $fallbackPassword -ErrorAction Stop | Out-Null
                        } else {
                            Set-RDMCurrentDataSource -DataSource $ds -ForcePromptAnswer ([System.Windows.Forms.DialogResult]::Yes) -ErrorAction Stop | Out-Null
                        }

                        $connected = $true
                    }
                } catch {
                    $connectErrors.Add("Automatisch SQL-login herstel mislukt: $($_.Exception.Message)")
                }
            }
        }

        if (-not $connected -and -not $credentialAttempted -and $PromptForDataSourceCredential) {
            try {
                $promptUser = if (-not [string]::IsNullOrWhiteSpace($fallbackUsername)) { $fallbackUsername } else { Read-Host "Datasource gebruikersnaam" }
                $promptPassword = Read-Host "Datasource wachtwoord" -AsSecureString
                if (-not [string]::IsNullOrWhiteSpace($promptUser) -and $promptPassword) {
                    Set-RDMCurrentDataSource -DataSource $ds -Username $promptUser -Password $promptPassword -ErrorAction Stop | Out-Null
                    $connected = $true
                    Write-Host "✓ Datasource verbonden met ingevoerde inloggegevens" -ForegroundColor Green
                }
            } catch {
                $connectErrors.Add("Datasource-login met ingevoerde inloggegevens mislukt: $($_.Exception.Message)")
            }
        }

        if (-not $connected) {
            $details = if ($connectErrors.Count -gt 0) { $connectErrors -join " | " } else { "Onbekende loginfout" }
            $oauthHint = if ($oauthConnectionAttempted) { "" } elseif ($isSqlDataSource) { " OAuth-tokenpad is niet van toepassing op SQLServer datasources." } else { " OAuth-pad niet beschikbaar in huidige module-context." }
            throw "Kon niet verbinden met datasource '$DataSourceName'. $details.$oauthHint Gebruik een reeds actieve/current RDM sessie voor deze datasource, of geef datasource credentials op met -DataSourceUsername/-DataSourcePassword (of RDM_DATASOURCE_USERNAME/RDM_DATASOURCE_PASSWORD)."
        }

        $vaults = @(Get-RDMRepository -ErrorAction Stop)
        
        return $vaults
    } catch {
        throw "Fout bij laden van vaults: $($_.Exception.Message)"
    }
}

function Find-SearchTermInCsv {
    <#
    .SYNOPSIS
    Smart matching: zoek vaultnaam in CSV op basis van fragmenten
    Retourneert ALLE matches als array met Title, Url, Score
    #>
    param(
        [Parameter(Mandatory)][string]$VaultName,
        [string]$CsvPath = ".\SharePoint-Projecten-VOLLEDIG.csv"
    )
    
    if (-not (Test-Path $CsvPath)) {
        Write-Warning "CSV niet gevonden: $CsvPath"
        return @()
    }
    
    try {
        $csv = @(Import-Csv $CsvPath -Encoding UTF8)
        if ($csv.Count -eq 0) { return @() }
    } catch {
        Write-Warning "Fout bij laden CSV: $_"
        return @()
    }
    
    # Split vault name in key fragments (minimize noise)
    $allFragments = @($VaultName -split '[\s\-_\(\)]+' | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
    
    # Numeric identifiers (strong signal, e.g. customer code 830796163)
    $numericFragments = @($allFragments | Where-Object { $_ -match '^\d{6,}$' })
    
    # Text fragments (remove generic noise terms)
    $noisePattern = '^(nv|ltd|bv|sa|sprl|org|com|net|it|group|shared|with|customer|mw|documentation|doc|site|project)$'
    $textFragments = @($allFragments | Where-Object { $_.Length -gt 1 -and $_ -notmatch $noisePattern -and $_ -notmatch '^\d+$' } | Select-Object -Unique)
    
    if ($textFragments.Count -eq 0 -and $numericFragments.Count -eq 0) { return @() }
    
    # Score each CSV row
    $scores = @()
    foreach ($row in $csv) {
        $title = [string]($row.Title ?? "")
        $url = [string]($row.Url ?? "")
        
        # Count matching text fragments in Title
        $titleMatches = ($textFragments | Where-Object { $title -match [regex]::Escape($_) }).Count
        $titleScore = $titleMatches * 120
        
        # Count matching text fragments in URL
        $urlMatches = ($textFragments | Where-Object { $url -match [regex]::Escape($_) }).Count
        $urlScore = $urlMatches * 40

        # Numeric matches are very strong indicator for correct customer
        $numberMatches = ($numericFragments | Where-Object { $title -match [regex]::Escape($_) -or $url -match [regex]::Escape($_) }).Count
        $numberScore = $numberMatches * 500
        
        $totalScore = $titleScore + $urlScore + $numberScore

        # Include only meaningful rows
        $includeRow = ($numberMatches -gt 0) -or ($titleMatches -ge 2) -or (($textFragments.Count -le 1) -and ($titleMatches -ge 1))
        
        if ($totalScore -gt 0 -and $includeRow) {
            $scores += [pscustomobject]@{
                Row = $row
                Title = $title
                Url = $url
                Score = $totalScore
                TitleMatches = $titleMatches
                UrlMatches = $urlMatches
                NumberMatches = $numberMatches
            }
        }
    }
    
    if ($scores.Count -eq 0) { return @() }

    # If numeric customer code exists and found, prefer numeric matches
    # but also keep rows with strong name match (2+ title fragments) even without the number
    if ($numericFragments.Count -gt 0) {
        $numericScores = @($scores | Where-Object { $_.NumberMatches -gt 0 })
        if ($numericScores.Count -gt 0) {
            $strongTextScores = @($scores | Where-Object { $_.NumberMatches -eq 0 -and $_.TitleMatches -ge 2 })
            $scores = @($numericScores) + @($strongTextScores)
        }
    }

    $sorted = @($scores | Sort-Object Score -Descending)
    $bestScore = $sorted[0].Score

    # Keep close-to-best results; avoid huge noisy lists
    $threshold = [Math]::Max(120, $bestScore - 250)
    $filtered = @($sorted | Where-Object { $_.Score -ge $threshold })

    # Always include strong text matches (2+ title fragments) even if below threshold
    # (numeric bonus can push bestScore up by 500, unfairly excluding valid sites without the number in their URL)
    $belowThresholdStrongMatches = @($sorted | Where-Object { $_.Score -lt $threshold -and $_.TitleMatches -ge 2 })
    if ($belowThresholdStrongMatches.Count -gt 0) {
        $filtered = @($filtered) + @($belowThresholdStrongMatches)
    }

    if ($filtered.Count -eq 0) {
        $filtered = @($sorted | Select-Object -First 50)
    }

    if ($filtered.Count -gt 50) {
        $filtered = @($filtered | Select-Object -First 50)
    }

    return $filtered
}

function Show-MultiSelectSites {
    <#
    .SYNOPSIS
    Interactieve multi-select voor sites
    #>
    param(
        [Parameter(Mandatory)][object[]]$Sites
    )

    if (-not $Sites -or $Sites.Count -eq 0) {
        return @()
    }

    $displaySites = $Sites

    for ($i = 0; $i -lt $displaySites.Count; $i++) {
        Write-Host "  [$i] $($displaySites[$i].Title) (Score: $($displaySites[$i].Score))" -ForegroundColor White
        Write-Host "      $($displaySites[$i].Url)" -ForegroundColor DarkGray
    }

    Write-Host ""
    Write-Host "Siteselectie:" -ForegroundColor Cyan
    Write-Host "  • Getallen: '0' of '0,2,4' om specifieke sites te kiezen" -ForegroundColor DarkGray
    Write-Host "  • Ranges: '0-5' voor sites 0 tot en met 5" -ForegroundColor DarkGray
    Write-Host "  • Alles: 'alle' of Enter om alle vermelde sites te selecteren" -ForegroundColor Yellow
    Write-Host "  • Skip: 's' om deze resultaten over te slaan en een andere zoekterm in te voeren" -ForegroundColor Yellow
    Write-Host ""
    $selectionInput = Read-Host "Jouw keuze"

    if ([string]::IsNullOrWhiteSpace($selectionInput)) {
        return @($displaySites)  # Enter = select all
    }

    if ($selectionInput.Trim() -ieq 's') {
        return $null  # 's' = skip this vault, continue to next
    }
    try {
        $indices = Parse-SelectionIndices -InputText $selectionInput -MaxCount $displaySites.Count -AllowAll
        $selected = @()
        foreach ($index in $indices) {
            if ($index -ge 0 -and $index -lt $displaySites.Count) {
                $selected += $displaySites[$index]
            }
        }
        return @($selected)
    } catch {
        Write-Warning "Ongeldige selectie, fallback naar beste match"
        return @($displaySites[0])
    }
}

function Show-VaultChecklist {
    <#
    .SYNOPSIS
    Toon interactieve checklist voor vault selectie
    #>
    param(
        [Parameter(Mandatory)][object[]]$Vaults
    )
    
    if ($Vaults.Count -eq 0) {
        Write-Warning "Geen vaults gevonden"
        return @()
    }
    
    Write-Host "╔════════════════════════════════════════════════════════════╗" -ForegroundColor Cyan
    Write-Host "║  STAP 1: VAULT SELECTIE                                  ║" -ForegroundColor Cyan
    Write-Host "╚════════════════════════════════════════════════════════════╝`n" -ForegroundColor Cyan
    
    Write-Host "Beschikbare vaults:" -ForegroundColor Yellow
    Write-Host ""
    
    for ($i = 0; $i -lt $Vaults.Count; $i++) {
        $vault = $Vaults[$i]
        Write-Host "  [$i] $($vault.Name)" -ForegroundColor White
    }
    
    Write-Host ""
    Write-Host "Voer nummers/ranges in om vaults te selecteren (bijv: '0,2,3', '30-40' of 'alle')" -ForegroundColor Cyan
    $selectionInput = Read-Host "Selectie"
    
    if ([string]::IsNullOrWhiteSpace($selectionInput)) {
        Write-Warning "Geen selectie gemaakt"
        return @()
    }
    
    try {
        $indices = Parse-SelectionIndices -InputText $selectionInput -MaxCount $Vaults.Count -AllowAll
        $selected = $indices | ForEach-Object {
            if ($_ -ge 0 -and $_ -lt $Vaults.Count) {
                $Vaults[$_]
            }
        }
        return @($selected)
    } catch {
        Write-Error "Ongeldige selectie: $_"
        return @()
    }
}

function Get-QueueDestinationFolders {
    <#
    .SYNOPSIS
    Vraag doelfolders en geselecteerde SharePoint sites VOORAF voor alle geselecteerde vaults
    Gebruikt smart matching op CSV en ondersteunt multi-site selectie
    #>
    param(
        [Parameter(Mandatory)][object[]]$SelectedVaults,
        [Parameter(Mandatory)][string]$DefaultExportRoot,
        [string]$CsvPath = ".\SharePoint-Projecten-VOLLEDIG.csv"
    )
    
    Write-Host "`n╔════════════════════════════════════════════════════════════╗" -ForegroundColor Cyan
    Write-Host "║  STAP 2: DOELFOLDERS & SITE SELECTIE                    ║" -ForegroundColor Cyan
    Write-Host "║          (multi-site support for deduplication)         ║" -ForegroundColor Cyan
    Write-Host "╚════════════════════════════════════════════════════════════╝`n" -ForegroundColor Cyan

    $queue = @()
    
    foreach ($vault in $SelectedVaults) {
        $vaultName = $vault.Name
        $safeVaultName = ($vaultName -replace '[\\/:*?"<>|]', '_').Trim()
        if ([string]::IsNullOrWhiteSpace($safeVaultName)) { $safeVaultName = 'Customer' }
        $defaultPath = Join-Path $DefaultExportRoot $safeVaultName
        
        Write-Host "Vault: $vaultName" -ForegroundColor White
        Write-Host "  Default folder: $defaultPath" -ForegroundColor Gray
        $destFolder = Read-Host "  Doelmap (Enter = default)"
        
        if ([string]::IsNullOrWhiteSpace($destFolder)) {
            $destFolder = $defaultPath
        }
        
        # Smart match: find all matching sites from CSV
        Write-Host "  Zoeken naar matching sites in SharePoint CSV..." -ForegroundColor Yellow
        $allMatches = Find-SearchTermInCsv -VaultName $vaultName -CsvPath $CsvPath
        $selectedSites = @()

        if ($allMatches -and $allMatches.Count -gt 0) {
            # Always show sites to user, even if only 1 match - allow manual confirmation/override
            Write-Host "  Gevonden $($allMatches.Count) matching site(s):" -ForegroundColor Cyan
            Write-Host ""

            $batch = Show-MultiSelectSites -Sites $allMatches

            if ($null -ne $batch -and $batch.Count -gt 0) {
                $selectedSites = @($batch)
            }
            # $null (s) of lege selectie: gewoon doorgaan naar zoekterm-prompt
        } else {
            Write-Warning "  Geen sites gevonden voor '$vaultName' in CSV"
        }

        # Altijd zoekterm-prompt tonen: Enter = klaar met deze vault, zoekterm = extra sites zoeken
        while ($true) {
            $moreSearchTerm = Read-Host "  Voer hier eventueel nog een zoekterm in. Druk Enter om door te gaan naar volgende vault"
            if ([string]::IsNullOrWhiteSpace($moreSearchTerm)) { break }
            $moreMatches = Find-SearchTermInCsv -VaultName $moreSearchTerm -CsvPath $CsvPath
            if ($moreMatches -and $moreMatches.Count -gt 0) {
                Write-Host "  Gevonden $($moreMatches.Count) site(s) voor '$moreSearchTerm':" -ForegroundColor Cyan
                Write-Host ""
                $batch = Show-MultiSelectSites -Sites $moreMatches
                if ($null -ne $batch -and $batch.Count -gt 0) {
                    $selectedSites = @($selectedSites) + @($batch)
                }
            } else {
                Write-Warning "  Geen resultaten voor '$moreSearchTerm' - probeer andere zoekterm"
            }
        }

        if ($selectedSites.Count -gt 0) {
            Write-Host ""
            Write-Host "  ✓ Geselecteerd ($($selectedSites.Count) site(s)):" -ForegroundColor Green
            foreach ($site in $selectedSites) {
                Write-Host "    • $($site.Title)" -ForegroundColor Green
            }
            Write-Host ""
        } else {
            Write-Warning "  Geen sites geselecteerd - vault wordt overgeslagen"
        }
        
        $queue += @{
            VaultName = $vaultName
            DestinationFolder = $destFolder
            SelectedSites = $selectedSites
            Status = "Wachtrij"
            StartTime = $null
            EndTime = $null
            Error = $null
        }
        
        Write-Host "  ✓ Folder: $destFolder" -ForegroundColor Green
        Write-Host "  ✓ Sites: $($selectedSites.Count) site(s) selected`n" -ForegroundColor Green
    }
    
    return $queue
}

function Get-QueueDestinationFoldersStandalone {
    <#
    .SYNOPSIS
    Standalone queue-opbouw zonder RDM: gebruiker geeft klant zoektermen in
    #>
    param(
        [Parameter(Mandatory)][string]$DefaultExportRoot,
        [string]$CsvPath = ".\SharePoint-Projecten-VOLLEDIG.csv"
    )

    Write-Host "`n╔════════════════════════════════════════════════════════════╗" -ForegroundColor Cyan
    Write-Host "║  STANDALONE MODE (zonder RDM datasource)                 ║" -ForegroundColor Cyan
    Write-Host "╚════════════════════════════════════════════════════════════╝`n" -ForegroundColor Cyan

    Write-Host "Geef klantnaam/zoekterm(en), komma-gescheiden." -ForegroundColor Yellow
    Write-Host "Voorbeeld: Acasa, Informatie Vlaanderen, Hydrex" -ForegroundColor Gray
    $rawTerms = Read-Host "Klant zoektermen"

    if ([string]::IsNullOrWhiteSpace($rawTerms)) {
        throw "Geen klant zoektermen ingegeven in standalone mode."
    }

    $terms = @($rawTerms -split ',' | ForEach-Object { $_.Trim() } | Where-Object { -not [string]::IsNullOrWhiteSpace($_) } | Select-Object -Unique)
    if ($terms.Count -eq 0) {
        throw "Geen geldige klant zoektermen gevonden."
    }

    $queue = @()
    foreach ($term in $terms) {
        $safeName = ($term -replace '[\\/:*?"<>|]', '_').Trim()
        if ([string]::IsNullOrWhiteSpace($safeName)) { $safeName = 'Customer' }
        $defaultPath = Join-Path $DefaultExportRoot $safeName

        Write-Host "Klant/zoekterm: $term" -ForegroundColor White
        Write-Host "  Default folder: $defaultPath" -ForegroundColor Gray
        $destFolder = Read-Host "  Doelmap (Enter = default)"
        if ([string]::IsNullOrWhiteSpace($destFolder)) { $destFolder = $defaultPath }

        Write-Host "  Zoeken naar matching sites in SharePoint CSV..." -ForegroundColor Yellow
        $allMatches = Find-SearchTermInCsv -VaultName $term -CsvPath $CsvPath
        $selectedSites = @()

        if ($allMatches -and $allMatches.Count -gt 0) {
            if ($allMatches.Count -eq 1) {
                Write-Host "  ✓ Automatisch geselecteerd: $($allMatches[0].Title)" -ForegroundColor Green
                $selectedSites = @($allMatches[0])
            } else {
                Write-Host "  Gevonden $($allMatches.Count) matching sites:" -ForegroundColor Cyan
                Write-Host ""
                $selectedSites = Show-MultiSelectSites -Sites $allMatches
                if ($selectedSites.Count -eq 0) {
                    Write-Warning "  Geen sites geselecteerd - klant wordt overgeslagen"
                    # (geen fallback naar beste match - klant wordt overgeslagen)
                }
            }
        } else {
            Write-Warning "  Geen CSV matches voor '$term'"
            $keepSearching = $true
            while ($keepSearching) {
                $manualSearchTerm = Read-Host "  Zoekterm voor CSV (of Enter om over te slaan)"
                if ([string]::IsNullOrWhiteSpace($manualSearchTerm)) {
                    $keepSearching = $false
                } else {
                    $manualMatches = Find-SearchTermInCsv -VaultName $manualSearchTerm -CsvPath $CsvPath
                    if ($manualMatches -and $manualMatches.Count -gt 0) {
                        Write-Host "  Gevonden $($manualMatches.Count) site(s) voor '$manualSearchTerm':" -ForegroundColor Cyan
                        Write-Host ""
                        $selectedSites = Show-MultiSelectSites -Sites $manualMatches
                        if ($selectedSites.Count -eq 0) {
                            Write-Warning "  Geen sites geselecteerd"
                        } else {
                            Write-Host ""
                            Write-Host "  ✓ Geselecteerd:" -ForegroundColor Green
                            foreach ($site in $selectedSites) {
                                Write-Host "    • $($site.Title)" -ForegroundColor Green
                            }
                            Write-Host ""
                        }
                        $keepSearching = $false
                    } else {
                        Write-Warning "  Geen resultaten voor '$manualSearchTerm' - probeer andere zoekterm"
                    }
                }
            }
        }

        if ($selectedSites.Count -eq 0) {
            Write-Warning "  Klant '$term' overgeslagen (geen site geselecteerd)."
            Write-Host ""
            continue
        }

        $queue += [pscustomobject]@{
            VaultName         = $term
            DestinationFolder = $destFolder
            SelectedSites     = @($selectedSites)
            Status            = "Wachtrij"
            StartTime         = $null
            EndTime           = $null
            Error             = $null
        }

        Write-Host "  ✓ Folder: $destFolder" -ForegroundColor Green
        Write-Host "  ✓ Sites: $($selectedSites.Count) site(s) selected`n" -ForegroundColor Green
    }

    if ($queue.Count -eq 0) {
        throw "Standalone queue is leeg (geen klanten met geselecteerde sites)."
    }

    return @($queue)
}

function Show-QueueReview {
    <#
    .SYNOPSIS
    Toon review van volledige export-queue
    #>
    param(
        [Parameter(Mandatory)][object[]]$Queue
    )
    
    Write-Host "`n╔════════════════════════════════════════════════════════════╗" -ForegroundColor Cyan
    Write-Host "║  STAP 3: QUEUE REVIEW (ready to export)                 ║" -ForegroundColor Cyan
    Write-Host "╚════════════════════════════════════════════════════════════╝`n" -ForegroundColor Cyan
    
    Write-Host "Export-queue details:" -ForegroundColor Yellow
    Write-Host ""
    
    $i = 1
    foreach ($item in $Queue) {
        Write-Host "  [$i] Vault: $($item.VaultName)" -ForegroundColor White
        Write-Host "      → Folder: $($item.DestinationFolder)" -ForegroundColor Gray
            Write-Host "      → Sites: $($item.SelectedSites.Count)" -ForegroundColor Gray
            foreach ($site in $item.SelectedSites) {
                Write-Host "         • $($site.Title)" -ForegroundColor DarkGray
            }
        Write-Host ""
        $i++
    }
    
    Write-Host "Totaal items in queue: $($Queue.Count)" -ForegroundColor Cyan
    Write-Host ""
    
    if (-not $AutoConfirmQueue) {
        $confirm = Read-Host "Start export now? (Ja/Nee)"
        return $confirm -eq "Ja" -or $confirm -eq "j"
    } else {
        Write-Host "AutoConfirmQueue = true, start direct..." -ForegroundColor Cyan
        return $true
    }
}

function Save-QueueConfig {
    <#
    .SYNOPSIS
    Sla queue op als JSON zodat export later zonder RDM-selectiestappen kan draaien
    #>
    param(
        [Parameter(Mandatory)][object[]]$Queue,
        [Parameter(Mandatory)][string]$Path
    )

    $resolvedPath = $Path
    if (-not [System.IO.Path]::IsPathRooted($resolvedPath)) {
        $resolvedPath = Join-Path $PSScriptRoot $resolvedPath
    }
    $resolvedPath = [System.IO.Path]::GetFullPath($resolvedPath)

    $dir = Split-Path -Path $resolvedPath -Parent
    if (-not [string]::IsNullOrWhiteSpace($dir)) {
        New-Item -ItemType Directory -Path $dir -Force | Out-Null
    }

    $serializableQueue = @()
    foreach ($item in $Queue) {
        $sites = @()
        foreach ($site in @($item.SelectedSites)) {
            $sites += [pscustomobject]@{
                Title = [string]$site.Title
                Url   = [string]$site.Url
                Score = if ($site.PSObject.Properties.Name -contains 'Score') { $site.Score } else { $null }
            }
        }

        $serializableQueue += [pscustomobject]@{
            VaultName         = [string]$item.VaultName
            DestinationFolder = [string]$item.DestinationFolder
            SelectedSites     = $sites
        }
    }

    $payload = [pscustomobject]@{
        Version     = 1
        CreatedAt   = (Get-Date).ToString('o')
        CreatedBy   = [Environment]::UserName
        MachineName = [Environment]::MachineName
        Queue       = $serializableQueue
    }

    $payload | ConvertTo-Json -Depth 8 | Set-Content -Path $resolvedPath -Encoding UTF8
    Write-Host "✓ Queue-config opgeslagen: $resolvedPath" -ForegroundColor Green
}

function Load-QueueConfig {
    <#
    .SYNOPSIS
    Laad queue uit JSON (zodat export kan draaien zonder RDM datasourceselectie)
    #>
    param([Parameter(Mandatory)][string]$Path)

    $resolvedPath = $Path
    if (-not [System.IO.Path]::IsPathRooted($resolvedPath)) {
        $resolvedPath = Join-Path $PSScriptRoot $resolvedPath
    }
    $resolvedPath = [System.IO.Path]::GetFullPath($resolvedPath)

    if (-not (Test-Path $resolvedPath)) {
        throw "Queue-config bestand niet gevonden: $resolvedPath"
    }

    $cfg = Get-Content -Path $resolvedPath -Raw -Encoding UTF8 | ConvertFrom-Json
    if (-not $cfg -or -not $cfg.Queue) {
        throw "Queue-config ongeldig: Queue ontbreekt in $resolvedPath"
    }

    $queue = @()
    foreach ($item in @($cfg.Queue)) {
        if ([string]::IsNullOrWhiteSpace([string]$item.VaultName)) { continue }
        if ([string]::IsNullOrWhiteSpace([string]$item.DestinationFolder)) { continue }

        $sites = @()
        foreach ($site in @($item.SelectedSites)) {
            if (-not $site) { continue }
            if ([string]::IsNullOrWhiteSpace([string]$site.Title) -or [string]::IsNullOrWhiteSpace([string]$site.Url)) { continue }
            $sites += [pscustomobject]@{
                Title = [string]$site.Title
                Url   = [string]$site.Url
                Score = if ($site.PSObject.Properties.Name -contains 'Score') { $site.Score } else { $null }
            }
        }

        $queue += [pscustomobject]@{
            VaultName         = [string]$item.VaultName
            DestinationFolder = [string]$item.DestinationFolder
            SelectedSites     = $sites
            Status            = "Wachtrij"
            StartTime         = $null
            EndTime           = $null
            Error             = $null
        }
    }

    if ($queue.Count -eq 0) {
        throw "Queue-config bevat geen bruikbare items: $resolvedPath"
    }

    Write-Host "✓ Queue-config geladen: $resolvedPath" -ForegroundColor Green
    Write-Host "  Items: $($queue.Count)" -ForegroundColor Gray
    return @($queue)
}

function Invoke-QueueExport {
    <#
    .SYNOPSIS
    Voer exports uit voor alle items in queue
    #>
    param(
        [Parameter(Mandatory)][object[]]$Queue,
        [switch]$SkipCleanup
    )
    
    Write-Host "`n╔════════════════════════════════════════════════════════════╗" -ForegroundColor Cyan
    Write-Host "║  STAP 4: EXPORT EXECUTION (in progress)                 ║" -ForegroundColor Cyan
    Write-Host "╚════════════════════════════════════════════════════════════╝`n" -ForegroundColor Cyan
    
    $results = @()
    Write-Log "=== EXPORT START: $($Queue.Count) items in queue ==="
    $totalCount = $Queue.Count
    $successCount = 0
    $errorCount = 0
    
    for ($i = 0; $i -lt $Queue.Count; $i++) {
        $item = $Queue[$i]
        $itemNum = $i + 1
        
        Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor Magenta
        Write-Host "[$itemNum/$totalCount] Export: $($item.VaultName)" -ForegroundColor Cyan
        Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor Magenta
        Write-Host ""
        
        Write-Log "[$itemNum/$totalCount] Start export: $($item.VaultName)"
        $item.Status = "In progress"
        $item.StartTime = Get-Date
        
        $maxAttempts = 2
        $attempt = 0
        $completed = $false

        while (-not $completed -and $attempt -lt $maxAttempts) {
            $attempt++

            try {
                # Use SelectedSites array from queue (pre-selected, all URLs available)
                $customerSites = $item.SelectedSites
                if (-not $customerSites -or $customerSites.Count -eq 0) {
                    throw "Geen sites geselecteerd voor vault '$($item.VaultName)'"
                }
                
                # Build export script path
                $exportScript = Join-Path $PSScriptRoot "Export-OneNote-Deduplicated-Queue.ps1"
                
                if (-not (Test-Path $exportScript)) {
                    throw "Export script niet gevonden: $exportScript"
                }
                
                # Ensure destination folder exists
                New-Item -ItemType Directory -Path $item.DestinationFolder -Force | Out-Null

                # Bewaar gekozen sites in de klantmap voor vervolgscripts (bv. Replace-OneNotePages-WithRDMNotice.ps1)
                Save-CustomerSelectedSitesFile -DestinationFolder $item.DestinationFolder `
                                               -VaultName $item.VaultName `
                                               -SelectedSites @($customerSites)
                
                # Build parameters for export script
                $exportParams = @{
                    CustomerSites   = $customerSites
                    ExportPath      = $item.DestinationFolder
                    SkipCleanup     = $SkipCleanup
                    ParentLogFile   = $script:LogFile
                }
                
                Write-Host "Invoking: Export-OneNote-Deduplicated-Queue.ps1 (attempt $attempt/$maxAttempts)" -ForegroundColor Yellow
                Write-Host "  Customer Sites: $($customerSites.Count)" -ForegroundColor Gray
                foreach ($site in $customerSites) {
                    Write-Host "    • $($site.Title)" -ForegroundColor Gray
                }
                Write-Host "  Destination: $($item.DestinationFolder)" -ForegroundColor Gray
                Write-Host ""
                
                # Invoke the export script with prepared parameters
                & $exportScript @exportParams
                
                $item.Status = "Success"
                $item.EndTime = Get-Date
                $successCount++
                $completed = $true
                
                Write-Log "[$itemNum/$totalCount] Export VOLTOOID: $($item.VaultName)" 'SUCCESS'
                Write-Host "`n✓ Export voltooid voor: $($item.VaultName)" -ForegroundColor Green

            } catch {
                $errorMessage = $_.Exception.Message
                $isThrottle = $errorMessage -match '429|Too Many Requests|throttle'

                if ($isThrottle -and $attempt -lt $maxAttempts) {
                    Write-Warning "HTTP 429/throttle gedetecteerd voor $($item.VaultName)."
                    Write-Log "[$itemNum/$totalCount] HTTP 429 throttle op $($item.VaultName), poging $attempt/$maxAttempts" 'WARN'
                    Start-QueueThrottleCooldown -Seconds 1800 -Reason "429 tijdens queue item '$($item.VaultName)'"
                    continue
                }

                $item.Status = "Error"
                $item.Error = $errorMessage
                $item.EndTime = Get-Date
                $errorCount++
                $completed = $true
                
                Write-Log "[$itemNum/$totalCount] Export MISLUKT: $($item.VaultName) | $errorMessage" 'ERROR'
                Write-Error "Export mislukt voor $($item.VaultName): $errorMessage"
            }
        }
        
        Write-Host ""
        
    }
    
    Write-Log "=== EXPORT KLAAR: $successCount succesvol, $errorCount mislukt van $totalCount ==="
    return @{
        Results = $Queue
        SuccessCount = $successCount
        ErrorCount = $errorCount
        TotalCount = $totalCount
    }
}

function Show-ExecutionSummary {
    <#
    .SYNOPSIS
    Toon samenvatting van export-resultaten
    #>
    param(
        [Parameter(Mandatory)][object]$ExecutionResult
    )
    
    $results = $ExecutionResult.Results
    $successCount = $ExecutionResult.SuccessCount
    $errorCount = $ExecutionResult.ErrorCount
    $totalCount = $ExecutionResult.TotalCount
    
    Write-Host "`n╔════════════════════════════════════════════════════════════╗" -ForegroundColor Cyan
    Write-Host "║  EXECUTION SUMMARY                                       ║" -ForegroundColor Cyan
    Write-Host "╚════════════════════════════════════════════════════════════╝`n" -ForegroundColor Cyan
    
    Write-Host "Totaal exports: $totalCount" -ForegroundColor White
    Write-Host "✓ Succesvol: $successCount" -ForegroundColor Green
    Write-Host "✗ Mislukt: $errorCount" -ForegroundColor $(if ($errorCount -gt 0) { "Red" } else { "Green" })
    Write-Host ""
    
    Write-Host "Detail per export:" -ForegroundColor Yellow
    Write-Host ""
    
    foreach ($item in $results) {
        $statusColor = switch ($item.Status) {
            "Success" { "Green" }
            "Error" { "Red" }
            "Wachtrij" { "Gray" }
            default { "Yellow" }
        }
        
        $statusSymbol = switch ($item.Status) {
            "Success" { "✓" }
            "Error" { "✗" }
            "Wachtrij" { "⏳" }
            default { "?" }
        }
        
        Write-Host "  $statusSymbol $($item.VaultName)" -ForegroundColor $statusColor
            Write-Host "    Selected Sites: $($item.SelectedSites.Count)" -ForegroundColor Gray
        
        if ($item.StartTime) {
            $duration = [math]::Round(($item.EndTime - $item.StartTime).TotalSeconds, 1)
            Write-Host "    Duration: ${duration}s" -ForegroundColor Gray
        }
        
        if ($item.Error) {
            Write-Host "    Error: $($item.Error)" -ForegroundColor Red
        }
        
        Write-Host ""
    }
    
    return $successCount -eq $totalCount
}

function Update-CompletedCustomersList {
    <#
    .SYNOPSIS
    Update persistent lijst met klanten waarvan export succesvol afgerond is
    #>
    param(
        [Parameter(Mandatory)][object]$ExecutionResult,
        [Parameter(Mandatory)][string]$FilePath
    )

    $successfulNames = @($ExecutionResult.Results |
        Where-Object { $_.Status -eq 'Success' } |
        ForEach-Object { [string]$_.VaultName } |
        Where-Object { -not [string]::IsNullOrWhiteSpace($_) } |
        Select-Object -Unique)

    if ($successfulNames.Count -eq 0) {
        Write-Host "Geen succesvolle exports om toe te voegen aan completed-lijst." -ForegroundColor DarkGray
        return
    }

    $resolvedPath = $FilePath
    if (-not [System.IO.Path]::IsPathRooted($resolvedPath)) {
        $resolvedPath = Join-Path $PSScriptRoot $resolvedPath
    }

    $resolvedPath = [System.IO.Path]::GetFullPath($resolvedPath)
    $targetDir = Split-Path -Path $resolvedPath -Parent
    if (-not [string]::IsNullOrWhiteSpace($targetDir)) {
        New-Item -ItemType Directory -Path $targetDir -Force | Out-Null
    }

    $existingNames = @()
    if (Test-Path $resolvedPath) {
        $existingNames = @(Get-Content -Path $resolvedPath -ErrorAction SilentlyContinue |
            Where-Object { -not [string]::IsNullOrWhiteSpace($_) } |
            ForEach-Object { $_.Trim() })
    }

    $nameMap = @{}
    foreach ($n in $existingNames) {
        if (-not $nameMap.ContainsKey($n)) { $nameMap[$n] = $true }
    }

    $newlyAdded = New-Object System.Collections.Generic.List[string]
    foreach ($name in $successfulNames) {
        $trimmed = $name.Trim()
        if (-not $nameMap.ContainsKey($trimmed)) {
            $nameMap[$trimmed] = $true
            $newlyAdded.Add($trimmed) | Out-Null
        }
    }

    $allNames = @($nameMap.Keys | Sort-Object)
    Set-Content -Path $resolvedPath -Value $allNames -Encoding UTF8

    Write-Host "`nCompleted-klantenlijst bijgewerkt:" -ForegroundColor Yellow
    Write-Host "  Bestand: $resolvedPath" -ForegroundColor Gray
    Write-Host "  Totaal uniek: $($allNames.Count)" -ForegroundColor Gray
    Write-Host "  Nieuw toegevoegd deze run: $($newlyAdded.Count)" -ForegroundColor Gray
}

function Save-VaultCache {
    param(
        [Parameter(Mandatory)][object[]]$Vaults,
        [Parameter(Mandatory)][string]$DataSourceName,
        [Parameter(Mandatory)][string]$FilePath
    )

    if (-not $Vaults -or $Vaults.Count -eq 0) { return }

    $resolvedPath = $FilePath
    if (-not [System.IO.Path]::IsPathRooted($resolvedPath)) {
        $resolvedPath = Join-Path $PSScriptRoot $resolvedPath
    }

    $resolvedPath = [System.IO.Path]::GetFullPath($resolvedPath)
    $targetDir = Split-Path -Path $resolvedPath -Parent
    if (-not [string]::IsNullOrWhiteSpace($targetDir)) {
        New-Item -ItemType Directory -Path $targetDir -Force | Out-Null
    }

    $cacheObject = [pscustomobject]@{
        DataSourceName = [string]$DataSourceName
        SavedAtUtc = [datetime]::UtcNow.ToString('o')
        Vaults = @($Vaults | ForEach-Object {
            [pscustomobject]@{
                Name = [string]$_.Name
                ID = if ($_.PSObject.Properties.Name -contains 'ID') { [string]$_.ID } else { $null }
            }
        } | Where-Object { -not [string]::IsNullOrWhiteSpace($_.Name) })
    }

    $cacheObject | ConvertTo-Json -Depth 6 | Set-Content -Path $resolvedPath -Encoding UTF8
    Write-Host "✓ Vault-cache opgeslagen: $resolvedPath" -ForegroundColor DarkGray
}

function Load-VaultCache {
    param(
        [Parameter(Mandatory)][string]$FilePath,
        [string]$DataSourceName
    )

    $resolvedPath = $FilePath
    if (-not [System.IO.Path]::IsPathRooted($resolvedPath)) {
        $resolvedPath = Join-Path $PSScriptRoot $resolvedPath
    }

    if (-not (Test-Path $resolvedPath)) {
        return @()
    }

    try {
        $raw = Get-Content -Path $resolvedPath -Raw -Encoding UTF8
        if ([string]::IsNullOrWhiteSpace($raw)) { return @() }

        $cache = $raw | ConvertFrom-Json
        $cachedDataSourceName = [string]($cache.DataSourceName ?? "")
        if (-not [string]::IsNullOrWhiteSpace($DataSourceName) -and -not [string]::IsNullOrWhiteSpace($cachedDataSourceName) -and $cachedDataSourceName -ine $DataSourceName) {
            Write-Warning "Vault-cache hoort bij datasource '$cachedDataSourceName' i.p.v. '$DataSourceName'. Cache wordt toch gebruikt als fallback."
        }

        $vaults = @($cache.Vaults | ForEach-Object {
            [pscustomobject]@{
                Name = [string]$_.Name
                ID = [string]$_.ID
            }
        } | Where-Object { -not [string]::IsNullOrWhiteSpace($_.Name) })

        return $vaults
    } catch {
        Write-Warning "Kon vault-cache niet laden ($resolvedPath): $($_.Exception.Message)"
        return @()
    }
}

# =========================
# MAIN EXECUTION
# =========================

try {
    $queue = $null
    Write-Log "=== SCRIPT GESTART | DataSourceName: $DataSourceName | DefaultExportRoot: $DefaultExportRoot | QueueConfigPath: $QueueConfigPath ==="

    if (-not [string]::IsNullOrWhiteSpace($QueueConfigPath) -and (Test-Path (if ([System.IO.Path]::IsPathRooted($QueueConfigPath)) { $QueueConfigPath } else { Join-Path $PSScriptRoot $QueueConfigPath }))) {
        Write-Host "╔════════════════════════════════════════════════════════════╗" -ForegroundColor Cyan
        Write-Host "║  QUEUE CONFIG MODE (zonder RDM vault selectie)            ║" -ForegroundColor Cyan
        Write-Host "╚════════════════════════════════════════════════════════════╝`n" -ForegroundColor Cyan

        $queue = Load-QueueConfig -Path $QueueConfigPath
    } else {
        # Step 1: Get DataSource (RDM-first workflow)
        if (-not $script:RdmModuleAvailable) {
            throw "Devolutions.PowerShell module is vereist voor vault-selectie. Installeer de module of gebruik -QueueConfigPath met bestaande queue-config."
        }

        $csvPath = Join-Path $PSScriptRoot "SharePoint-Projecten-VOLLEDIG.csv"

        if (-not $DataSourceName) {
        Write-Host "╔════════════════════════════════════════════════════════════╗" -ForegroundColor Cyan
        Write-Host "║  STAP 0: RDM DATASOURCE SELECTIE                         ║" -ForegroundColor Cyan
        Write-Host "╚════════════════════════════════════════════════════════════╝`n" -ForegroundColor Cyan
        
        Write-Host "Beschikbare datasources:" -ForegroundColor Yellow
        try {
            $allDatasources = Get-RDMDataSource -ErrorAction Stop
        } catch {
            throw "RDM datasources niet beschikbaar: $($_.Exception.Message)"
        }

        if (-not $allDatasources -or $allDatasources.Count -eq 0) {
            throw "Geen datasources gevonden in RDM"
        }

        Write-Host ""
        for ($i = 0; $i -lt $allDatasources.Count; $i++) {
            $ds = $allDatasources[$i]
            $readOnlyLabel = if ($ds.ReadOnly) { " [READ-ONLY]" } else { "" }
            $connectedLabel = ""
            if ($ds.PSObject.Properties.Name -contains 'IsConnected' -and $ds.IsConnected) {
                $connectedLabel = " [CONNECTED]"
            }
            Write-Host "  [$i] $($ds.Name)$readOnlyLabel$connectedLabel" -ForegroundColor White
        }

        Write-Host ""
        $selection = Read-Host "Kies datasource (nummering)"

        if ($selection -notmatch '^\d+$') {
            throw "Ongeldige selectie: voer een getal in"
        }

        $selectedIdx = [int]$selection
        if ($selectedIdx -lt 0 -or $selectedIdx -ge $allDatasources.Count) {
            throw "Geselecteerde datasource bestaat niet (index $selectedIdx)"
        }

        $DataSourceName = $allDatasources[$selectedIdx].Name
        Write-Host "`n✓ Gekozen: $DataSourceName`n" -ForegroundColor Green
        }

        Write-Host "Loading vaults from: $DataSourceName`n" -ForegroundColor Yellow

        # Step 2: Load vaults
        $vaults = $null
        $vaultLoadError = $null
        
        try {
            $vaults = Get-RDMVaultList -DataSourceName $DataSourceName -DataSourceUsername $DataSourceUsername -DataSourcePassword $DataSourcePassword -PromptForDataSourceCredential:$PromptForDataSourceCredential
            Save-VaultCache -Vaults $vaults -DataSourceName $DataSourceName -FilePath $VaultCacheFile
        } catch {
            $vaultLoadError = $_.Exception.Message
            Write-Warning "RDM vault-laden mislukt: $vaultLoadError"
            
            # ALLEEN cache-fallback voor niet-SQL datasources
            # Voor SQL datasources: moest connectie niet werken, dan credentials vragen
            $ds = $null
            try {
                $ds = Get-RDMDataSource -Name $DataSourceName -ErrorAction Stop
            } catch {}
            
            $isSqlDataSource = $ds -and $ds.PSObject.Properties.Name -contains 'Type' -and ([string]$ds.Type -ieq 'SQLServer')
            
            if ($isSqlDataSource) {
                Write-Host "⚠️  SQL datasource '$DataSourceName' is niet verbonden in deze PowerShell-sessie" -ForegroundColor Yellow
                Write-Host "    Interactief credentials invoeren..." -ForegroundColor Cyan
                Write-Host ""
                
                $SqlUsername = Read-Host "Voer username in (bijv. user@example.com)"
                $SqlPasswordSecure = Read-Host -AsSecureString "Voer password in"
                
                Write-Host "Probeer opnieuw met credentials..." -ForegroundColor Yellow
                try {
                    $vaults = Get-RDMVaultList -DataSourceName $DataSourceName -DataSourceUsername $SqlUsername -DataSourcePassword $SqlPasswordSecure
                    Save-VaultCache -Vaults $vaults -DataSourceName $DataSourceName -FilePath $VaultCacheFile
                    Write-Host "✓ Vaults succesvol geladen met ingevoerde credentials" -ForegroundColor Green
                } catch {
                    Write-Host "❌ Credentials waren onjuist of datasource fout: $($_.Exception.Message)" -ForegroundColor Red
                    throw "Kan vaults niet laden met ingevoerde credentials"
                }
            } else {
                # Non-SQL datasource: cache-fallback is OK
                Write-Host "Probeer vault-cache fallback..." -ForegroundColor Yellow
                $vaults = Load-VaultCache -FilePath $VaultCacheFile -DataSourceName $DataSourceName
                if ($vaults.Count -gt 0) {
                    Write-Host "✓ Vaults geladen vanuit cache ($($vaults.Count) items)" -ForegroundColor Green
                    Write-Host "⚠️  WAARSCHUWING: Cache kan incompleet zijn. Nieuwe vaults in datasource worden niet weergegeven." -ForegroundColor Yellow
                } else {
                    throw "Geen vaults beschikbaar via RDM of cache. Start het script eenmaal op een machine waar vaults wel laden zodat cachebestand '$VaultCacheFile' wordt opgebouwd."
                }
            }
        }

        if (-not $vaults -or $vaults.Count -eq 0) {
            throw "Geen bruikbare vaults gevonden in datasource '$DataSourceName'"
        }

        Write-Host "✓ Geladen: $($vaults.Count) vault(s)" -ForegroundColor Green
        Write-Host ""

        # Step 3: Show vault checklist
        $selectedVaults = Show-VaultChecklist -Vaults $vaults
        if ($selectedVaults.Count -eq 0) {
            throw "Geen vaults geselecteerd"
        }

        Write-Host "`n✓ Geselecteerd: $($selectedVaults.Count) vault(s)" -ForegroundColor Green

        # Step 4: Collect destination folders (with CSV for smart matching)
        $queue = Get-QueueDestinationFolders -SelectedVaults $selectedVaults -DefaultExportRoot $DefaultExportRoot -CsvPath $csvPath

        if (-not [string]::IsNullOrWhiteSpace($QueueConfigPath)) {
            Save-QueueConfig -Queue $queue -Path $QueueConfigPath
            if ($GenerateQueueConfigOnly) {
                Write-Host "Queue-config mode: alleen configuratie aangemaakt, export niet gestart." -ForegroundColor Yellow
                exit 0
            }
        }
    }
    
    # Step 5: Show queue review
    $confirmed = Show-QueueReview -Queue $queue
    if (-not $confirmed) {
        Write-Host "`nExport geannuleerd." -ForegroundColor Yellow
        exit 0
    }
    
    # Step 6: Execute exports
    $executionResult = Invoke-QueueExport -Queue $queue -SkipCleanup:$SkipCleanup
    
    # Step 7: Show summary
    $allSuccessful = Show-ExecutionSummary -ExecutionResult $executionResult

    # Step 7b: Persist succesvolle klanten in doorlopende lijst
    Update-CompletedCustomersList -ExecutionResult $executionResult -FilePath $CompletedCustomersFile
    
    # Optional: Trigger post-export script
    if ($PostExportScript -and (Test-Path $PostExportScript)) {
        Write-Host "`n╔════════════════════════════════════════════════════════════╗" -ForegroundColor Cyan
        Write-Host "║  POST-EXPORT: RUNNING NEXT SCRIPT                         ║" -ForegroundColor Cyan
        Write-Host "╚════════════════════════════════════════════════════════════╝`n" -ForegroundColor Cyan
        
        Write-Host "Invoking: $PostExportScript`n" -ForegroundColor Yellow
        
        try {
            & $PostExportScript
            Write-Host "`n✓ Post-export script completed" -ForegroundColor Green
        } catch {
            Write-Error "Post-export script failed: $_"
        }
    }
    
    # Final status
    Write-Host "`n╔════════════════════════════════════════════════════════════╗" -ForegroundColor Cyan
    if ($allSuccessful) {
        Write-Host "║  ✓ BULK EXPORT COMPLETED SUCCESSFULLY                    ║" -ForegroundColor Green
    } else {
        Write-Host "║  ⚠️  BULK EXPORT COMPLETED WITH ERRORS                    ║" -ForegroundColor Yellow
    }
    Write-Host "╚════════════════════════════════════════════════════════════╝`n" -ForegroundColor Cyan
    
    exit $($allSuccessful ? 0 : 1)
    
} catch {
    Write-Log "FATALE FOUT: $($_.Exception.Message)" 'ERROR'
    Write-Log "Stack: $($_.ScriptStackTrace)" 'ERROR'
    Write-Error "FATAL: $_"
    exit 1
} finally {
    Write-Log "=== SCRIPT GESTOPT ==="
}
